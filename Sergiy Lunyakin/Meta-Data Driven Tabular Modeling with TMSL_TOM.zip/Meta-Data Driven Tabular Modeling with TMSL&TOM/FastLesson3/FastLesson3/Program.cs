﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using SSAS = Microsoft.AnalysisServices;
using TOM = Microsoft.AnalysisServices.Tabular;
using XLS = Microsoft.Office.Interop.Excel;

namespace FastLesson3
{
    class Program
    {
        static void Main(string[] args)
        {
            string bimFile = @"C:\Users\sergiy.lunyakin\Desktop\Presentation\TMSL&TOM\AW Internet Sales Tabular Model\AW Internet Sales Tabular Model\Model.bim";
            string jsonMetadata = File.ReadAllText(bimFile);

            using (TOM.Server server = new TOM.Server())
            {
                server.Connect(@"Provider=MSOLAP.7;Integrated Security=SSPI;Persist Security Info=True;Data Source=ITM2042\LOCALTAB16");

                TOM.Database tabularDB = TOM.JsonSerializer.DeserializeDatabase(jsonMetadata);

                string orgDatabaseName = tabularDB.Name;
                string orgId = tabularDB.ID;

                tabularDB.Name = server.Databases.GetNewName(tabularDB.Name);
                tabularDB.ID = server.Databases.GetNewID(tabularDB.ID);

                server.Databases.Add(tabularDB);
                tabularDB.Update(SSAS.UpdateOptions.ExpandFull);

                XLS.Application xlApp = new XLS.Application();
                XLS.Workbook xlWb = xlApp.Workbooks.Open(@"C:\Users\Administrator\Desktop\NewColumnNames.xlsx");

                foreach (XLS.Worksheet xlSheet in xlWb.Worksheets)
                {
                    foreach (XLS.ListObject xlTable in xlSheet.ListObjects)
                    {
                        TOM.Table tbl = tabularDB.Model.Tables[xlTable.Name.Replace("_", " ")];
                        foreach (XLS.ListRow xlRow in xlTable.ListRows)
                        {
                            if (!tbl.Columns.Contains(xlRow.Range.Cells[1, 1].Value))
                                continue;

                            TOM.DataColumn column = tbl.Columns[xlRow.Range.Cells[1, 1].Value];
                            column.RequestRename(xlRow.Range.Cells[1, 2].Value);
                            tabularDB.Model.SaveChanges();
                        }
                    }
                }

                xlWb.Close();
                xlApp.Quit();

                // Clone the database to disconnect from the server
                TOM.Database offlineDB = tabularDB.Clone();

                offlineDB.Name = orgDatabaseName;
                offlineDB.ID = orgId;

                File.WriteAllText(bimFile, TOM.JsonSerializer.SerializeDatabase(offlineDB));

                tabularDB.Drop();
            }

            Console.Write("Done! Press any key to exit.");
            Console.ReadLine();
        }
    }
}
