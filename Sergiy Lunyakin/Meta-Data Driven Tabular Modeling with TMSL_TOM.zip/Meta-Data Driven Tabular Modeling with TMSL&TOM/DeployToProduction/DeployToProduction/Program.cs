﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SSAS = Microsoft.AnalysisServices;
using TOM = Microsoft.AnalysisServices.Tabular;
using System.IO;

namespace DeployToProduction
{
    class Program
    {
        static void Main(string[] args)
        {
            string newDatabaseName = "New AdventureWorksDW2014 Database2";
            string bimFile = @"C:\Users\sergiy.lunyakin\Desktop\Presentation\TMSL&TOM\AdventureWorksDW2014Limited\AdventureWorksDW2014Limited\Model.bim";
            string jsonMetadata = File.ReadAllText(bimFile);

            using (TOM.Server server = new TOM.Server())
            {
                server.Connect(@"Provider=MSOLAP.7;Integrated Security=SSPI;Persist Security Info=True;Data Source=ITM2042\LOCALTAB16");

                TOM.Database tabularDB = TOM.JsonSerializer.DeserializeDatabase(jsonMetadata);

                tabularDB.Name = server.Databases.GetNewName(newDatabaseName);
                (tabularDB.Model.DataSources[0] as TOM.ProviderDataSource).ConnectionString += ";";

                server.Databases.Add(tabularDB);

                foreach(TOM.Table tbl in tabularDB.Model.Tables)
                {
                    foreach(TOM.Partition part in tbl.Partitions)
                    {
                        if(part.SourceType == TOM.PartitionSourceType.Query)
                        {
                            (part.Source as TOM.QueryPartitionSource).Query =
                                (part.Source as TOM.QueryPartitionSource).Query.Replace("SELECT TOP 100", "SELECT");
                        }
                    }
                }
                tabularDB.Model.RequestRefresh(TOM.RefreshType.Full);
                tabularDB.Update(SSAS.UpdateOptions.ExpandFull);
            }
        }
    }
}
