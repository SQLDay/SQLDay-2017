﻿using Microsoft.AnalysisServices.Tabular;

namespace AddMeasure {
    class Program {
        static void Main(string[] args) {
            AddOrChangeMeasure();
        }
        public static void AddOrChangeMeasure() {
            string serverName = @"127.0.0.1:53683";
            string databaseName = "AdventureWorksISales";
            string tableName = "OlapQueryLog";
            string measureName = "Total_Duration";
            string measureExpression = "SUM ( OlapQueryLog[Duration] )";

            string serverConnectionString = string.Format("Provider=MSOLAP;Data Source={0}", serverName);

            Server server = new Server();
            server.Connect(serverConnectionString);

            Database db;

            if (server.ServerMode.ToString() == "SharePoint")
            {
               db = server.Databases[server.Databases[0].Name];
            }
            else
            {
               db = server.Databases[databaseName];
            }

            Model model = db.Model;
            Table table = model.Tables[tableName];
            Measure measure = table.Measures.Find(measureName);
            if (measure == null) {
                measure = new Measure() { Name = measureName };
                table.Measures.Add(measure);
            }
            measure.Expression = measureExpression;

            model.SaveChanges();

        }
        public static void AddMeasure() {
            string serverName = @"localhost\tabular";
            string databaseName = "Contoso";
            string tableName = "OlapQueryLog";
            string measureName = "TotalDuration";
            string measureExpression = "SUM(OlapQueryLog[Total_Duration])";

            string serverConnectionString = string.Format("Provider=MSOLAP;Data Source={0}", serverName);

            Server server = new Server();
            server.Connect(serverConnectionString);

            Database db = server.Databases[databaseName];
            Model model = db.Model;
            Table table = model.Tables[tableName];
            table.Measures.Add(new Measure() { Name = measureName, Expression = measureExpression });
            model.SaveChanges();
        }
    }
}
