﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using SSAS = Microsoft.AnalysisServices;
using TOM = Microsoft.AnalysisServices.Tabular;

namespace ReplaceDateTable
{
    class Program
    {
        static void Main(string[] args)
        {
            string bimFile = @"C:\Users\sergiy.lunyakin\Desktop\Presentation\TMSL&TOM\AW Internet Sales Tabular Model\AW Internet Sales Tabular Model\Model.bim";
            string jsonMetadata = File.ReadAllText(bimFile);
            string jsonCalcTable = File.ReadAllText(@"C:\Users\sergiy.lunyakin\Desktop\Presentation\TMSL&TOM\Calendar.json");

            TOM.Database tabularDB = TOM.JsonSerializer.DeserializeDatabase(jsonMetadata);

            tabularDB.Model.Tables.Remove("Date");

            TOM.Table dateTable = TOM.JsonSerializer.DeserializeObject<TOM.Table>(jsonCalcTable);
            tabularDB.Model.Tables.Add(dateTable);

            File.WriteAllText(bimFile, TOM.JsonSerializer.SerializeDatabase(tabularDB));

            Console.Write("Done! Press any key to exit.");
            Console.ReadLine();
        }
    }
}
