﻿using System;
using System.Linq;
using System.Data;
using System.Data.OleDb;
using System.Collections.Generic;
using System.Data.SqlClient;
using SSAS = Microsoft.AnalysisServices;
using TOM = Microsoft.AnalysisServices.Tabular;
using System.IO;

namespace CreateTabularModelBim
{
    class Program
    {
        static void Main(string[] args)
        {
            string dataSourceConnectionString = "Data Source = ITM2042\\LOCALSQLDEV; Initial Catalog = AdventureWorksDW14; Persist Security Info = true; Integrated Security = SSPI";

            string bimFile = @"C:\Users\sergiy.lunyakin\Desktop\Presentation\TMSL&TOM\AdventureWorksDW2014Limited\AdventureWorksDW2014Limited\Model.bim";
            string newDatabaseName = "New AdventureWorksDW2014 Database";

            var dbWithTables = new TOM.Database()
            {
                Name = newDatabaseName,
                ID = newDatabaseName,
                CompatibilityLevel = 1200,
                StorageEngineUsed = SSAS.StorageEngineUsed.TabularMetadata,
            };

            //
            // Add a Microsoft.AnalysisServices.Tabular.Model object to the
            // database, which acts as a root for all other Tabular metadata objects.
            //
            dbWithTables.Model = new TOM.Model()
            {
                Name = "Model",
                Description = "A Tabular data model at the 1200 compatibility level."
            };

            //
            // Add a Microsoft.AnalysisServices.Tabular.ProviderDataSource object
            // to the data Model object created in the previous step. The connection
            // string of the data source object in this example 
            // points to an instance of the WideWorldImportersDW SQL Server database.
            //
            string dataSourceName = "Azure SQL DB AdventureWorksDW2014";
            var sqlDataSource = new TOM.ProviderDataSource()
            {
                Name = dataSourceName,
                Description = "A data source definition that uses explicit " +
                              "SQL credentials for authentication " +
                              "against Azure SQL Server.",
                Provider = "System.Data.SqlClient",
                ConnectionString = dataSourceConnectionString,
                ImpersonationMode = TOM.ImpersonationMode.ImpersonateServiceAccount,
            };

            TOM.Annotation ssdtAnnotation = new TOM.Annotation()
            {
                Name = "ConnectionEditUISource",
                Value = "SqlServer",
            };
            sqlDataSource.Annotations.Add(ssdtAnnotation);

            dbWithTables.Model.DataSources.Add(sqlDataSource);

            using (SqlConnection sqlConnection = new SqlConnection(sqlDataSource.ConnectionString))
            {
                sqlConnection.Open();

                //
                //Get the list of tables from the database and add corresponding references to the data model.
                //
                foreach (TOM.Table table in GetTables(sqlConnection, sqlDataSource))
                {
                    dbWithTables.Model.Tables.Add(table);
                }

                //
                // Detect the table relationships and add them to the model as well.
                //
                foreach (TOM.Relationship rel in GetRelationships(sqlConnection, dbWithTables.Model.Tables))
                {
                    dbWithTables.Model.Relationships.Add(rel);
                }
            }

            File.WriteAllText(bimFile, TOM.JsonSerializer.SerializeDatabase(dbWithTables));

            Console.WriteLine("Press Enter to close this console window.");
            Console.ReadLine();
        }

        static List<TOM.Table> GetTables(SqlConnection sqlConnection, TOM.ProviderDataSource ds)
        {
            List<TOM.Table> tables = new List<TOM.Table>();

            SqlCommand sqlCmd = sqlConnection.CreateCommand();
            sqlCmd.CommandText = @"SELECT sysobjects.name, syscolumns.name, systypes.name
                                FROM sysobjects
                                INNER JOIN syscolumns ON sysobjects.id = syscolumns.id
                                INNER
                                JOIN systypes ON syscolumns.xtype = systypes.xtype
                                WHERE sysobjects.xtype = 'U' AND systypes.name != 'sysname' and systypes.uid!=11
                                ORDER BY sysobjects.name, syscolumns.colid";

            using (SqlDataReader oledbReader = sqlCmd.ExecuteReader())
            {
                while (oledbReader.Read())
                {
                    string table_name = oledbReader.GetString(0);
                    string column_name = oledbReader.GetString(1);
                    string datatype = oledbReader.GetString(2);


                    if (!tables.Any(tbl => tbl.Name == table_name))
                    {
                        tables.Add(new TOM.Table()
                        {
                            Name = table_name,
                            Partitions = {
                                //
                                // Create a single partition with a QueryPartitionSource for a query
                                // that imports all rows from the underlying data source.
                                //
                                new TOM.Partition()
                                {
                                    Name = "All Rows",
                                    Source = new TOM.QueryPartitionSource()
                                    {
                                        DataSource = ds,
                                        Query = string.Format("SELECT TOP 100 * FROM [{0}]", table_name),
                                    }
                                }
                            }
                        });
                    }

                    var newColumn = new TOM.DataColumn()
                    {
                        Name = column_name,
                        SourceColumn = column_name,
                    };

                    switch (datatype)
                    {
                        case "bit":
                            newColumn.DataType = TOM.DataType.Boolean;
                            break;
                        case "date":
                            newColumn.DataType = TOM.DataType.DateTime;
                            break;
                        case "datetime":
                            newColumn.DataType = TOM.DataType.DateTime;
                            break;
                        case "float":
                            newColumn.DataType = TOM.DataType.Double;
                            break;
                        case "money":
                            newColumn.DataType = TOM.DataType.Decimal;
                            break;
                        case "real":
                            newColumn.DataType = TOM.DataType.Decimal;
                            break;
                        case "int":
                            newColumn.DataType = TOM.DataType.Int64;
                            break;
                        case "varbinary":
                            newColumn.DataType = TOM.DataType.Binary;
                            break;
                        case "smallint":
                            newColumn.DataType = TOM.DataType.Int64;
                            break;
                        case "tinyint":
                            newColumn.DataType = TOM.DataType.Int64;
                            break;
                        default:
                            newColumn.DataType = TOM.DataType.String;
                            break;
                    }

                    TOM.Table currentTable = tables.First(tbl => tbl.Name == table_name);
                    currentTable.Columns.Add(newColumn);
                }
            }

            return tables;
        }
        static List<TOM.Relationship> GetRelationships(SqlConnection sqlConnection, TOM.TableCollection tc)
        {
            List<TOM.Relationship> relationShips = new List<TOM.Relationship>();
            List<TOM.Table> tables = new List<TOM.Table>();

            SqlCommand sqlCmd = sqlConnection.CreateCommand();
            sqlCmd.CommandText = @"SELECT  tp.name, cp.name
            	                         , tr.name, cr.name
                                    FROM
                                        sys.foreign_keys fk
                                    INNER JOIN
                                        sys.tables tp ON fk.parent_object_id = tp.object_id
                                    INNER JOIN
                                        sys.tables tr ON fk.referenced_object_id = tr.object_id
                                    INNER JOIN
                                        sys.foreign_key_columns fkc ON fkc.constraint_object_id = fk.object_id
                                    INNER JOIN
                                        sys.columns cp ON fkc.parent_column_id = cp.column_id AND fkc.parent_object_id = cp.object_id
                                    INNER JOIN
                                        sys.columns cr ON fkc.referenced_column_id = cr.column_id AND fkc.referenced_object_id = cr.object_id
                                    WHERE tp.name NOT LIKE tr.name AND tp.name Like 'Fact%' AND tr.name Like 'Dim%'
                                    ORDER BY
                                        tp.name, cp.column_id";

            using (SqlDataReader oledbReader = sqlCmd.ExecuteReader())
            {
                while (oledbReader.Read())
                {
                    string primary_table = oledbReader.GetString(0);
                    string primary_column = oledbReader.GetString(1);
                    string referenced_table = oledbReader.GetString(2);
                    string referenced_column = oledbReader.GetString(3);

                    TOM.Table tp = tc.First(tbl => tbl.Name == primary_table);
                    TOM.Table tr = tc.First(tbl => tbl.Name == referenced_table);

                    TOM.SingleColumnRelationship newRelationship = new TOM.SingleColumnRelationship()
                    {
                        FromColumn = tp.Columns[primary_column],
                        ToColumn = tr.Columns[referenced_column],
                        FromCardinality = TOM.RelationshipEndCardinality.Many,
                        ToCardinality = TOM.RelationshipEndCardinality.One,
                        IsActive = (relationShips.Any(rel => rel.FromTable == tp && rel.ToTable == tr)) ? false : true,
                    };

                    relationShips.Add(newRelationship);
                }
            }

            return relationShips;
        }
    }
}
