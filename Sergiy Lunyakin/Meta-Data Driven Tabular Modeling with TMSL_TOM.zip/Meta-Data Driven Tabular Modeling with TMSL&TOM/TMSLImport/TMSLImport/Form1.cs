﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;
using SSAS = Microsoft.AnalysisServices;
using TOM = Microsoft.AnalysisServices.Tabular;

namespace TMSLImport
{
    public partial class Form1 : Form
    {
        TOM.Database tabularDB = null;
        string jsonTemplate = string.Empty;
        string[] comboOptions = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openBimFile = new OpenFileDialog();

            openBimFile.InitialDirectory = @"C:\Users\Administrator\Documents\Visual Studio 2015\Projects";
            openBimFile.Title = "Open Bim File";

            openBimFile.CheckFileExists = true;
            openBimFile.CheckPathExists = true;

            openBimFile.DefaultExt = "bim";
            openBimFile.Filter = "Bim files (*.bim)|*.bim|All files (*.*)|*.*";
            openBimFile.FilterIndex = 1;

            if (openBimFile.ShowDialog() == DialogResult.OK)
            {
                txtBimFilePath.Text = openBimFile.FileName;
            }

        }

        private void btnBrowseTemplate_Click(object sender, EventArgs e)
        {
            OpenFileDialog openJsonFile = new OpenFileDialog();

            openJsonFile.InitialDirectory = @"C:\Users\Administrator\Desktop";
            openJsonFile.Title = "Open JSON File";

            openJsonFile.CheckFileExists = true;
            openJsonFile.CheckPathExists = true;

            openJsonFile.DefaultExt = "json";
            openJsonFile.Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*";
            openJsonFile.FilterIndex = 1;

            if (openJsonFile.ShowDialog() == DialogResult.OK)
            {
                txtTemplateFilePath.Text = openJsonFile.FileName;
            }
        }

        private void txtBimFilePath_TextChanged(object sender, EventArgs e)
        {
            try
            {
                comboOptions = null;
                cboTargetTable.Items.Clear();

                using (StreamReader reader = File.OpenText(txtBimFilePath.Text))
                {
                    string jsonMetadata = reader.ReadToEnd();
                    tabularDB = TOM.JsonSerializer.DeserializeDatabase(jsonMetadata);

                    List<string> resourceNames = new List<string>();
                    foreach (TOM.Table tbl in tabularDB.Model.Tables)
                    {
                        resourceNames.Add(tbl.Name);
                        cboTargetTable.Items.Add(tbl.Name);
                        foreach (TOM.Column col in tbl.Columns)
                        {
                            resourceNames.Add(
                                string.Format("{0}[{1}]", tbl.Name, col.Name));
                        }
                    }
                    comboOptions = resourceNames.ToArray();
                }
            }
            catch
            {
                tabularDB = null;
                comboOptions = null;
                cboTargetTable.Items.Clear();
            }
        }

        private void txtTemplateFilePath_TextChanged(object sender, EventArgs e)
        {
            try
            {
                List<string> lstParams = new List<string>();

                using (StreamReader reader = File.OpenText(txtTemplateFilePath.Text))
                {
                    jsonTemplate = reader.ReadToEnd();

                    string pattern = @"@\w+@";
                    Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
                    MatchCollection matches = rgx.Matches(jsonTemplate);
                    foreach (Match match in matches)
                    {
                        if (!lstParams.Exists(element => element == match.Value))
                            lstParams.Add(match.Value);
                    }

                    foreach(string param in lstParams)
                    {
                        object[] row = new object[] { param, null };
                        dataGridView1.Rows.Add(row);
                    }

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        DataGridViewComboBoxCell cell = (DataGridViewComboBoxCell)(row.Cells["Value"]);
                        cell.DataSource = comboOptions;
                    }
                }
            }
            catch
            {
                jsonTemplate = string.Empty;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                DataGridViewTextBoxCell paramCell = (DataGridViewTextBoxCell)(row.Cells["Parameter"]);
                DataGridViewComboBoxCell valueCell = (DataGridViewComboBoxCell)(row.Cells["Value"]);

                if (paramCell.Value == null || valueCell.Value == null) continue;

                string pattern = @"\[.*?\]";
                Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
                MatchCollection matches = rgx.Matches(valueCell.Value.ToString());

                if (matches.Count == 1)
                {
                    jsonTemplate = jsonTemplate.Replace(paramCell.Value.ToString(),
                        matches[0].ToString().Replace("[", "").Replace("]", ""));
                }
                else
                {
                    jsonTemplate = jsonTemplate.Replace(paramCell.Value.ToString(),
                       valueCell.Value.ToString());
                }
            }

            string targetTable = cboTargetTable.SelectedItem.ToString();

            JObject jsonObj = JObject.Parse(jsonTemplate);
            foreach (var node in jsonObj)
            {
                var key = node.Key;
                if (key == "measures")
                {
                    JToken jtoken = node.Value;
                    foreach (var token in jtoken.Children())
                    {
                        string json = token.ToString();
                        TOM.Measure mc = TOM.JsonSerializer.DeserializeObject<TOM.Measure>(json);

                        if(tabularDB.Model.Tables[targetTable].Measures.Contains(mc.Name))
                        {
                            tabularDB.Model.Tables[targetTable].Measures.Remove(mc.Name);
                        }

                        tabularDB.Model.Tables[targetTable].Measures.Add(mc);
                    }
                }
            }

            // Save the bim
            File.WriteAllText(
                txtBimFilePath.Text,
                TOM.JsonSerializer.SerializeDatabase(tabularDB));

            Cursor.Current = Cursors.Default;
        }
    }
}
