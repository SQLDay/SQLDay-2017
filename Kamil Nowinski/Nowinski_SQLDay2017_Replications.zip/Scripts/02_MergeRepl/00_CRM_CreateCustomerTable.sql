CREATE DATABASE [CRM]
GO
CREATE DATABASE [CRM_USA]
GO


USE [CRM_USA]
GO
USE [CRM]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--DROP TABLE [dbo].[Customer]

CREATE TABLE [dbo].[Customer](
	[CustomerId] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[RegionCode] [char](5) NULL,
	[Title] [varchar](10) NULL,
	[SSN] [varchar](20) NULL,
	[Login] [varchar](128) NULL,
	[CountryCode] [varchar](5) NULL,
	[FirstName] [varchar](100) NULL,
	[Surname] [varchar](100) NULL,
	[isActive] [bit] NULL,
	[InactiveDate] [datetime] NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [varchar](50) NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [varchar](50) NULL,
	[CustomerTypeCode] [varchar](5) NULL,
	[Twitter] [varchar](100) NULL,
 CONSTRAINT [PK_Customer_CustomerId] PRIMARY KEY CLUSTERED 
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX [IX_SSN] ON [dbo].[Customer] ([SSN] ASC) WITH (FILLFACTOR = 90)
GO

