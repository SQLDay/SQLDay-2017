USE [CRM]
GO

CREATE TABLE [dbo].[Action] (
    [ActionId]		TINYINT		IDENTITY (1, 1) NOT NULL,
    [ActionName]	VARCHAR (50) NULL,
    [UpdatedOn]		DATETIME     NULL,
    [UpdatedBy]		VARCHAR (50) NULL,
    CONSTRAINT [PK_Action] PRIMARY KEY CLUSTERED ([ActionId] ASC)
);
GO


CREATE PROCEDURE dbo.PopulateAction
AS
/*
	Scripted data for table: [dbo].[Action]
*/
SET IDENTITY_INSERT [dbo].[Action] ON;

;WITH cte_data 
as (SELECT [ActionId], [ActionName], [UpdatedOn], [UpdatedBy] FROM 
(VALUES
	  (1,	'View',		null,	null)
	, (2,	'Add',		null,	null)
	, (3,	'Edit',		null,	null)
	, (4,	'Delete',	null,	null)
) as v ([ActionId], [ActionName], [UpdatedOn], [UpdatedBy]) )

MERGE [dbo].[Action] as t
using cte_data as s
	ON t.[ActionId] = s.[ActionId]
WHEN NOT MATCHED BY target THEN
	INSERT ([ActionId], [ActionName], [UpdatedOn], [UpdatedBy])
	VALUES (s.[ActionId], s.[ActionName], s.[UpdatedOn], s.[UpdatedBy])
WHEN MATCHED THEN 
	UPDATE SET 
	[ActionName] = s.[ActionName], [UpdatedOn] = s.[UpdatedOn], [UpdatedBy] = s.[UpdatedBy]
WHEN NOT MATCHED BY source THEN
	DELETE
;

SET IDENTITY_INSERT [dbo].[Action] OFF;
GO
----------------------------------------------------------------



--Last LSN
DECLARE @LSN NVARCHAR(50)
SELECT TOP 1 @LSN = [Current LSN] FROM fn_dblog (null,null) ORDER BY [Current LSN] DESC;
PRINT @LSN

--Update dictionary
EXEC dbo.PopulateAction;

--Let's check what SQL Server does...
SELECT [Current LSN], [Operation], [Context], [Page ID], [Slot ID], [Num Elements], [Begin Time], [Transaction Name] --AllocUnitId, AllocUnitName, 
FROM fn_dblog (null,null)  
WHERE [Context] <> 'LCX_NULL'
AND [Current LSN] > @LSN ;
GO
--WHY?



CREATE PROCEDURE dbo.PopulateAction_v2
AS
/*
	Scripted data for table: [dbo].[Action]
*/
SET IDENTITY_INSERT [dbo].[Action] ON;

;WITH cte_data 
as (SELECT CAST([ActionId] as tinyint) as [ActionId], [ActionName], [UpdatedOn], [UpdatedBy] FROM 
(VALUES
	  (1,	'View',		GETDATE(),	null)
	, (2,	'Add',		GETDATE(),	null)
	, (3,	'Edit',		GETDATE(),	null)
	, (4,	'Delete',	GETDATE(),	null)
) as v ([ActionId], [ActionName], [UpdatedOn], [UpdatedBy]) )

MERGE [dbo].[Action] as t
using cte_data as s
	ON t.[ActionId] = s.[ActionId]
WHEN NOT MATCHED BY target THEN
	INSERT ([ActionId], [ActionName], [UpdatedOn], [UpdatedBy])
	VALUES (s.[ActionId], s.[ActionName], s.[UpdatedOn], s.[UpdatedBy])
WHEN MATCHED THEN 
	UPDATE SET 
	[ActionName] = s.[ActionName], [UpdatedOn] = s.[UpdatedOn], [UpdatedBy] = s.[UpdatedBy]
WHEN NOT MATCHED BY source THEN
	DELETE
;

SET IDENTITY_INSERT [dbo].[Action] OFF;
GO
----------------------------------------------------------------

/*
	Attempt No 2
*/

--Last LSN
DECLARE @LSN NVARCHAR(50)
SELECT TOP 1 @LSN = [Current LSN] FROM fn_dblog (null,null) ORDER BY [Current LSN] DESC;
PRINT @LSN

--Update dictionary - ver.2
EXEC dbo.PopulateAction_v2;

--Let's check what SQL Server does...
SELECT [Current LSN], [Operation], [Context], [Page ID], [Slot ID], [Num Elements], [Begin Time], [Transaction Name] --AllocUnitId, AllocUnitName, 
FROM fn_dblog (null,null)  
WHERE [Context] <> 'LCX_NULL'
AND [Current LSN] > @LSN ;
GO

--Great right now!
