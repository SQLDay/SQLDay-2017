/*
	Update both sites - different columns, with NO intervals of time
*/

SELECT CustomerId, Title, FirstName, Surname, UpdatedOn, UpdatedBy FROM CRM.dbo.Customer WHERE SSN = '043-04-7121'
SELECT CustomerId, Title, FirstName, Surname, UpdatedOn, UpdatedBy FROM CRM_USA.dbo.Customer WHERE SSN = '043-04-7121'

UPDATE CRM_USA.dbo.Customer
SET Title='MGR.' 
WHERE SSN = '043-04-7121'

UPDATE CRM.dbo.Customer
SET Surname = 'Nowak.' 
WHERE SSN = '043-04-7121'
GO

SELECT CustomerId, Title, FirstName, Surname, UpdatedOn, UpdatedBy FROM CRM.dbo.Customer WHERE SSN = '043-04-7121'
SELECT CustomerId, Title, FirstName, Surname, UpdatedOn, UpdatedBy FROM CRM_USA.dbo.Customer WHERE SSN = '043-04-7121'
--What is the result?






--Last (publisher) won


--SHOW: 
--How to resolve the conflict manually


