/*
	UPDATE WITH CONFLICTS
*/



/*
	USA
*/
SELECT * FROM CRM.dbo.Customer WHERE SSN = '806-56-4928'
SELECT * FROM CRM_USA.dbo.Customer WHERE SSN = '806-56-4928'

--Update second site:
UPDATE CRM_USA.dbo.Customer
SET CountryCode='PL1', UpdatedOn = GETDATE(), UpdatedBy = CURRENT_USER
WHERE SSN = '806-56-4928'


/*
	Update both sites
*/
UPDATE CRM.dbo.Customer
SET CountryCode='PL2' 
WHERE SSN = '806-56-4928'

UPDATE CRM_USA.dbo.Customer
SET CountryCode='PL3' 
WHERE SSN = '806-56-4928'

SELECT * FROM CRM.dbo.Customer WHERE SSN = '806-56-4928'
SELECT * FROM CRM_USA.dbo.Customer WHERE SSN = '806-56-4928'
--Q: Who will win? 
--A: PL2
--Q: And why?
--Q: First win or publisher win?

--SHOW CONFLICT







/*
	Update both sites - in revert order
*/
UPDATE CRM_USA.dbo.Customer
SET CountryCode='PL4' 
WHERE SSN = '806-56-4928'

UPDATE CRM.dbo.Customer
SET CountryCode='PL5' 
WHERE SSN = '806-56-4928'
GO

SELECT * FROM CRM.dbo.Customer WHERE SSN = '806-56-4928'
SELECT * FROM CRM_USA.dbo.Customer WHERE SSN = '806-56-4928'
--Who win?




--PL5 won
--Does publisher always win?


/*
	Update both sites - in revert order, with intervals of time
*/
UPDATE CRM_USA.dbo.Customer
SET CountryCode='Frst0' 
WHERE SSN = '806-56-4928'
GO

WAITFOR DELAY '00:00:02';
GO

UPDATE CRM.dbo.Customer
SET CountryCode='Sec0' 
WHERE SSN = '806-56-4928'
GO

SELECT * FROM CRM.dbo.Customer WHERE SSN = '806-56-4928'
SELECT * FROM CRM_USA.dbo.Customer WHERE SSN = '806-56-4928'
--Sec0 won (publisher)




