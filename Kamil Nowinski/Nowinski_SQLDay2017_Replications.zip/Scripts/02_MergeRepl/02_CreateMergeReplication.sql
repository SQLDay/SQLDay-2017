--Now 
--1. CREATE MERGE REPLICATION from CRM database
--2. Check new column

--Check the jobs
SELECT j.job_id, j.date_created, j.name, j.enabled, l.[name] AS owner_name, j.owner_sid 
FROM msdb.dbo.sysjobs AS j
LEFT JOIN sys.syslogins AS l ON l.sid = j.owner_sid
ORDER BY j.date_created DESC

--Change the owner for the job [KNMSI10\SQL2016-CRM-MERGE-3] if needed
--NT SERVICE\SQLAgent$SQL2016

--Snapshot folder:
--M:\MSSQL\MSSQL13.SQL2016\MSSQL\ReplData

--Create a snapshot again (manually)

SELECT TOP 100 * FROM CRM.dbo.Customer
GO

--1. Show new triggers


--2. There is no data in target db
SELECT TOP 100 * FROM CRM_USA.dbo.Customer

--3. Create SUBSCRIBER for [CRM_USA]

--3a. change owner for job [KNMSI10\SQL2016-CRM-MERGE-KNMSI10\SQL2016-3]
--NT SERVICE\SQLAgent$SQL2016

--4. Check data for both: source and destination
SELECT TOP 100 * FROM CRM.dbo.Customer
SELECT TOP 100 * FROM CRM_USA.dbo.Customer

SELECT COUNT(*) FROM CRM_USA.dbo.Customer


--5. Show new index
USE CRM_USA
GO
SELECT OBJECT_NAME(object_id), * FROM sys.indexes
WHERE OBJECT_NAME(object_id) = 'Customer'





