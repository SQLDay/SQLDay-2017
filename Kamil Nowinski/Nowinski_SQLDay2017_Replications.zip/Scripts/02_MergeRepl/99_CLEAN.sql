USE [CRM_USA]
GO
USE [CRM]
GO

TRUNCATE TABLE [dbo].[Customer]

DROP TABLE [dbo].[Customer]

--drop publication & subscription
