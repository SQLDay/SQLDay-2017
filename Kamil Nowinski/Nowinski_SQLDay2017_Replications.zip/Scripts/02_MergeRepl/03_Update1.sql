--1.Check data
SELECT TOP 100 * FROM CRM.dbo.Customer
SELECT TOP 100 * FROM CRM_USA.dbo.Customer

SELECT * FROM CRM.dbo.Customer WHERE SSN = '148-58-5495'

--Update first site:
UPDATE CRM.dbo.Customer
SET isActive = 0, InactiveDate = GETDATE(), UpdatedOn = GETDATE(), UpdatedBy = CURRENT_USER
WHERE SSN = '148-58-5495'

SELECT CustomerId, RegionCode, Title, FirstName, Surname, isActive, InactiveDate, UpdatedOn 
FROM CRM.dbo.Customer WHERE SSN = '148-58-5495'
SELECT CustomerId, RegionCode, Title, FirstName, Surname, isActive, InactiveDate, UpdatedOn 
FROM CRM_USA.dbo.Customer WHERE SSN = '148-58-5495'

