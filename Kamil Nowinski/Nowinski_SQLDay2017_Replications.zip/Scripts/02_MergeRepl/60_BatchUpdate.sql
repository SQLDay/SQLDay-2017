--10k update
SET ROWCOUNT 10000
update CRM.dbo.Customer
set UpdatedBy = 'kamiln', UpdatedOn = GETDATE()
SET ROWCOUNT 0

select distinct UpdatedOn from CRM_USA.dbo.Customer
GO



--10k update
SET ROWCOUNT 20000
update CRM_USA.dbo.Customer
set UpdatedBy = 'kamiln', UpdatedOn = GETDATE()
SET ROWCOUNT 0

SELECT DISTINCT UpdatedOn, GETDATE() as [now] from CRM.dbo.Customer



--TRUNCATE?
TRUNCATE TABLE CRM.dbo.Customer


--500k update
update CRM.dbo.Customer
set UpdatedBy = 'kamiln', UpdatedOn = GETDATE()
