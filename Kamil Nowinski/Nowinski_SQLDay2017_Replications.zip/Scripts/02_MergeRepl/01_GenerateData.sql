/*
	GENERATE THE DATA:
	1) Run Redgate SQL Generator, open "Customer.sqlgen" file and generate the data
	OR
	2) Execute script "01a_Data.sql"
*/


