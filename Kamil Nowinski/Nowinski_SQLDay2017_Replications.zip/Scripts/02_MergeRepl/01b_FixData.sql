USE [CRM]
GO

SELECT TOP 1000 * FROM dbo.Customer
SELECT COUNT(*) FROM dbo.Customer
GO


--Tidy random data
UPDATE dbo.Customer
set InactiveDate = null
where isActive = 1

UPDATE dbo.Customer
set UpdatedOn = null
where UpdatedBy is null

UPDATE dbo.Customer
set InactiveDate = CreatedOn, CreatedOn = InactiveDate
where InactiveDate < CreatedOn
GO

