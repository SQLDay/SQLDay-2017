USE PLSSUG;
GO

CREATE OR ALTER PROC dbo.Step01_Show_Data
AS
SET NOCOUNT ON;
SELECT * FROM dbo.CommunityMember;
GO

Step01_Show_Data
GO

CREATE OR ALTER PROC dbo.Step02_Normalize_Data
AS
SET NOCOUNT ON;
DROP TABLE IF EXISTS dbo.CommunityMember_Normalized;
SELECT 
  MemberKey,
  Age,
  CASE MaritalStatus WHEN 'S' THEN 0 ELSE 1 END AS MaritalStatus,
  CASE Gender WHEN 'M' THEN 0 ELSE 1 END AS Gender,
  YearlyIncome,
  Children,
  HasHouse,
  HasCar,
  CASE PLSSUGChapter 
    WHEN 'Wroclaw' THEN 0
    WHEN 'Katowice' THEN 170
    WHEN 'Cracow' THEN 240
    WHEN 'Lublin' THEN 390
    WHEN 'Warsaw' THEN 300
    WHEN 'Poznan' THEN 145
    WHEN 'Lodz' THEN 185
    WHEN 'Tricity' THEN 380
    WHEN 'Bydgoszcz & Torun' THEN 230
    ELSE 500
  END AS Distance,
  Attendee
INTO dbo.CommunityMember_Normalized
FROM dbo.CommunityMember;

SELECT * FROM dbo.CommunityMember_Normalized;
GO

Step02_Normalize_Data
GO

CREATE OR ALTER PROCEDURE dbo.Step03_Select_Features  
AS  
BEGIN  
SET NOCOUNT ON;
EXECUTE sp_execute_external_script  
@language = N'R',
@script = N'  
library("reshape2")
library("ggplot2")

# creating output directory
mainDir <- ''C:\\temp''  
dir.create(mainDir, recursive = TRUE, showWarnings = FALSE)  
setwd(mainDir);  

# Open a jpeg file and output ggplot in that file.  
dest_filename = file.path(mainDir, ''features.jpg'')  
jpeg(filename=dest_filename, height = 768, width = 1024, res=150); 

#filtering numeric columns
numeric_cols <- sapply(members, is.numeric)

#turn the data into long format (key->value)
members.lng <- melt(members[,numeric_cols], id="Attendee")

#plot the distribution for Attendee={0/1} for each numeric column
print(ggplot(aes(x=value, group=Attendee, colour=factor(Attendee)), data=members.lng) + geom_density() + facet_wrap(~variable, scales="free"))

dev.off()
',  
@input_data_1 = N'SELECT * FROM dbo.CommunityMember_Normalized',
@input_data_1_name = N'members'; 
END;
GO

Step03_Select_Features
GO

!!"C:\temp\features.jpg"
GO

CREATE OR ALTER PROCEDURE dbo.Step04_Split_Data  
AS  
BEGIN  
  SET NOCOUNT ON;  
  -- 75% Training data 
  DROP TABLE IF EXISTS [dbo].[CommunityMemberTrain];
  SELECT * INTO [dbo].[CommunityMemberTrain] 
  FROM (SELECT * FROM [dbo].[CommunityMember_Normalized] WHERE (ABS(CAST((BINARY_CHECKSUM(MemberKey, NEWID())) as int)) % 100) < 75) a;
  -- 25% Test data
  DROP TABLE IF EXISTS [dbo].[CommunityMemberTest];
  SELECT * INTO [dbo].[CommunityMemberTest] 
  FROM (SELECT * FROM [dbo].[CommunityMember_Normalized] WHERE [MemberKey] NOT IN (SELECT [MemberKey] FROM [dbo].[CommunityMemberTrain])) a;
  SELECT * FROM dbo.CommunityMemberTrain;
  SELECT * FROM dbo.CommunityMemberTest;
END;
GO

Step04_Split_Data
GO

CREATE OR ALTER PROCEDURE dbo.Step05_Build_Trained_Model  
AS  
BEGIN  
  DECLARE @inquery nvarchar(max) = N'SELECT * FROM [dbo].[CommunityMemberTrain]';
  
  DROP TABLE IF EXISTS [dbo].[Models];
  CREATE TABLE [dbo].[Models]([Model] [varbinary](max) NOT NULL);

  INSERT INTO [dbo].[Models]
  EXEC sp_execute_external_script 
  @language = N'R',  
  @script = N'  
  randomForestObj <- rxDForest(Attendee ~ Age + Children + YearlyIncome + HasCar + Distance + MaritalStatus, InputDataSet)
  model <- data.frame(payload = as.raw(serialize(randomForestObj, connection=NULL)))
  ',
  @input_data_1 = @inquery,  
  @output_data_1_name = N'model'; 
  
  SELECT * FROM [dbo].[Models];
END;
GO

Step05_Build_Trained_Model
GO

CREATE OR ALTER PROCEDURE dbo.Step06_Score_Model
AS  
BEGIN  
  DECLARE @inquery nvarchar(max) = N'SELECT * FROM [dbo].[CommunityMemberTest]'; 
  DECLARE @model varbinary(max) = (SELECT TOP 1 Model FROM dbo.Models);
  
  DROP TABLE IF EXISTS [dbo].[AttendeePredictions];
  CREATE TABLE [dbo].[AttendeePredictions]([AttendeePrediction] [float] NULL, [MemberKey] [int] NULL);

  INSERT INTO [dbo].[AttendeePredictions]   
  EXEC sp_execute_external_script 
  @language = N'R',
  @script = N'  
  rfModel <- unserialize(as.raw(model));  
  OutputDataSet<-rxPredict(rfModel, data = InputDataSet, extraVarsToWrite = c("MemberKey"))
  ',
  @input_data_1 = @inquery,
  @params = N'@model varbinary(max)',
  @model = @model;
  
  SELECT * FROM [dbo].[AttendeePredictions];
END;
GO

Step06_Score_Model
GO

CREATE OR ALTER PROCEDURE dbo.Step07_Evaluate_Model
AS  
BEGIN  
  EXEC sp_execute_external_script
  @language = N'R',
  @script = N'  
  suppressMessages(library("ROCR"))
  
  # create output directory
  mainDir <- ''C:\\temp''  
  dir.create(mainDir, recursive = TRUE, showWarnings = FALSE)  
  setwd(mainDir);  
  
  # Open a jpeg file and output ROC Curve in that file
  dest_filename = file.path(mainDir, ''ROC.jpg'')  
  jpeg(filename=dest_filename, height=1800, width = 1800, res = 300); 
  
  # Plot ROC Curve
  pred <- prediction(AttendeePredictions$AttendeePrediction, AttendeePredictions$Attendee)
  perf <- performance(pred,"tpr","fpr")
  plot(perf)
  abline(a=0,b=1)
  dev.off()
  
  # Print Area under the Curve
  auc <- performance(pred, "auc")
  print(paste0("Area under ROC Curve : ", as.numeric(auc@y.values)))
',  
@input_data_1 = N'SELECT b.AttendeePrediction, a.Attendee FROM [dbo].[CommunityMemberTest] a INNER JOIN [dbo].[AttendeePredictions] b ON a.MemberKey = b.MemberKey',  
@input_data_1_name = N'AttendeePredictions';

SELECT b.AttendeePrediction, a.Attendee FROM [dbo].[CommunityMemberTest] a 
INNER JOIN [dbo].[AttendeePredictions] b ON a.MemberKey = b.MemberKey
ORDER BY 1 DESC;

END;
GO

Step07_Evaluate_Model
GO

!!"C:\temp\ROC.jpg"
GO

CREATE OR ALTER PROCEDURE Step08_Use_Model_For_Prediction
AS  
BEGIN  
  DECLARE @inquery nvarchar(max) = N'SELECT * FROM [dbo].[CommunityMemberNew_Normalized]'; 
  DECLARE @model varbinary(max) = (SELECT TOP 1 Model FROM dbo.Models);

  DROP TABLE IF EXISTS [dbo].[AttendeePredictionsNew];
  CREATE TABLE [dbo].[AttendeePredictionsNew]([AttendeePrediction] [float] NULL, [MemberKey] [int] NULL);

  INSERT INTO [dbo].[AttendeePredictionsNew]   
  EXEC sp_execute_external_script 
  @language = N'R',
  @script = N'  
  rfModel <- unserialize(as.raw(model));  
  OutputDataSet<-rxPredict(rfModel, data = InputDataSet, extraVarsToWrite = c("MemberKey"))
  ',
  @input_data_1 = @inquery,
  @params = N'@model varbinary(max)',
  @model = @model;

  SELECT * FROM dbo.view_CommunityMemberNew_Attendee;
  
END;
GO

Step08_Use_Model_For_Prediction
GO