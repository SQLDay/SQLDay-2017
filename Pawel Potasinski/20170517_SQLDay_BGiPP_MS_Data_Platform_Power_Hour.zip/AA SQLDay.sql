USE PLSSUG;
GO

-----------------------------------------
-- The Process
-----------------------------------------

Step01_Show_Data
GO
Step02_Normalize_Data
GO
Step03_Select_Features
!!"C:\temp\features.jpg"
GO
Step04_Split_Data
GO
Step05_Build_Trained_Model
GO
Step06_Score_Model
GO
Step07_Evaluate_Model
!!"C:\temp\ROC.jpg"
GO
Step08_Use_Model_For_Prediction
GO

-----------------------------------------

SELECT * FROM dbo.CommunityMember;
GO

-----------------------------------------
-- Normalization
-----------------------------------------

DROP TABLE IF EXISTS dbo.CommunityMember_Normalized;
GO

SELECT 
  MemberKey,
  Age,
  CASE MaritalStatus WHEN 'S' THEN 0 ELSE 1 END AS MaritalStatus,
  CASE Gender WHEN 'M' THEN 0 ELSE 1 END AS Gender,
  YearlyIncome,
  Children,
  HasHouse,
  HasCar,
  CASE PLSSUGChapter 
    WHEN 'Wroclaw' THEN 0
    WHEN 'Katowice' THEN 170
    WHEN 'Cracow' THEN 240
    WHEN 'Lublin' THEN 390
    WHEN 'Warsaw' THEN 300
    WHEN 'Poznan' THEN 145
    WHEN 'Lodz' THEN 185
    WHEN 'Tricity' THEN 380
    WHEN 'Bydgoszcz & Torun' THEN 230
    ELSE 500
  END AS Distance,
  Attendee
INTO dbo.CommunityMember_Normalized
FROM dbo.CommunityMember;
GO

SELECT * FROM dbo.CommunityMember_Normalized;
GO

-----------------------------------------
-- Feature selection
-----------------------------------------

CREATE OR ALTER PROCEDURE [dbo].[proc_PlotDistribution]  
AS  
BEGIN  
SET NOCOUNT ON;
EXECUTE sp_execute_external_script  
@language = N'R',
@script = N'  
library("reshape2")
library("ggplot2")

# creating output directory
mainDir <- ''C:\\temp''  
dir.create(mainDir, recursive = TRUE, showWarnings = FALSE)  
setwd(mainDir);  
print("Creating output plot files:", quote=FALSE)  

# Open a jpeg file and output ggplot in that file.  
dest_filename = tempfile(pattern = ''ggplot_'', tmpdir = mainDir)  
dest_filename = paste(dest_filename, ''.jpg'',sep="")  
print(dest_filename, quote=FALSE);
jpeg(filename=dest_filename, height = 768, width = 1024, res=150); 

#filtering numeric columns
numeric_cols <- sapply(members, is.numeric)
print(numeric_cols)

#turn the data into long format (key->value)
members.lng <- melt(members[,numeric_cols], id="Attendee")

#plot the distribution for Attendee={0/1} for each numeric column
print(ggplot(aes(x=value, group=Attendee, colour=factor(Attendee)), data=members.lng) + geom_density() + facet_wrap(~variable, scales="free"))

dev.off()
',  
@input_data_1 = N'SELECT * FROM dbo.CommunityMember_Normalized',
@input_data_1_name = N'members';
END;
GO

EXEC dbo.proc_PlotDistribution;
GO

!!"C:\temp\ggplot_12b8650e4e6d.jpg"
GO

--------------------------------------------
-- Split data (train & test)
--------------------------------------------

CREATE OR ALTER PROCEDURE [dbo].[proc_SplitData]  
AS  
BEGIN  
  SET NOCOUNT ON;  
  -- 75% Training data 
  DROP TABLE IF EXISTS [dbo].[CommunityMemberTrain];
  SELECT * INTO [dbo].[CommunityMemberTrain] 
  FROM (SELECT * FROM [dbo].[CommunityMember_Normalized] WHERE (ABS(CAST((BINARY_CHECKSUM(MemberKey, NEWID())) as int)) % 100) < 75) a;
  -- 25% Test data
  DROP TABLE IF EXISTS [dbo].[CommunityMemberTest];
  SELECT * INTO [dbo].[CommunityMemberTest] 
  FROM (SELECT * FROM [dbo].[CommunityMember_Normalized] WHERE [MemberKey] NOT IN (SELECT [MemberKey] FROM [dbo].[CommunityMemberTrain])) a;
END;
GO

EXEC [dbo].[proc_SplitData];
GO

SELECT * FROM dbo.CommunityMemberTrain;
SELECT * FROM dbo.CommunityMemberTest;
GO

------------------------------------------
-- Build predictive model
------------------------------------------

CREATE OR ALTER PROCEDURE [dbo].[proc_BuildModel]  
AS  
BEGIN  
  DECLARE @inquery nvarchar(max) = N'SELECT * FROM [dbo].[CommunityMemberTrain]';
  
  DROP TABLE IF EXISTS [dbo].[Models];
  CREATE TABLE [dbo].[Models]([Model] [varbinary](max) NOT NULL);

  INSERT INTO [dbo].[Models]
  EXEC sp_execute_external_script 
  @language = N'R',  
  @script = N'  
  randomForestObj <- rxDForest(Attendee ~ Age + Children + YearlyIncome + HasCar + Distance + MaritalStatus, InputDataSet)
  model <- data.frame(payload = as.raw(serialize(randomForestObj, connection=NULL)))
  ',
  @input_data_1 = @inquery,  
  @output_data_1_name = N'model'; 
 
END;
GO

EXEC [dbo].[proc_BuildModel];
GO

SELECT * FROM [dbo].[Models];
GO

-----------------------------------------
-- Score model
-----------------------------------------

CREATE OR ALTER PROCEDURE [dbo].[proc_ScoreModel] 
AS  
BEGIN  
  DECLARE @inquery nvarchar(max) = N'SELECT * FROM [dbo].[CommunityMemberTest]'; 
  DECLARE @model varbinary(max) = (SELECT TOP 1 Model FROM dbo.Models);
  
  DROP TABLE IF EXISTS [dbo].[AttendeePredictions];
  CREATE TABLE [dbo].[AttendeePredictions]([AttendeePrediction] [float] NULL, [MemberKey] [int] NULL);

  INSERT INTO [dbo].[AttendeePredictions]   
  EXEC sp_execute_external_script 
  @language = N'R',
  @script = N'  
  rfModel <- unserialize(as.raw(model));  
  OutputDataSet<-rxPredict(rfModel, data = InputDataSet, extraVarsToWrite = c("MemberKey"))
  ',
  @input_data_1 = @inquery,
  @params = N'@model varbinary(max)',
  @model = @model;
  
END;
GO

EXEC [dbo].[proc_ScoreModel];
GO

SELECT TOP 10 * FROM [dbo].[AttendeePredictions];
GO

-----------------------------------------------
-- Evaluate model
-----------------------------------------------

CREATE OR ALTER PROCEDURE [dbo].[proc_PlotROCCurve]  
AS  
BEGIN  
  EXEC sp_execute_external_script
  @language = N'R',
  @script = N'  
  suppressMessages(library("ROCR"))
  
  # create output directory
  mainDir <- ''C:\\temp''  
  dir.create(mainDir, recursive = TRUE, showWarnings = FALSE)  
  setwd(mainDir);  
  print("Creating output plot files:", quote=FALSE)  
  
  # Open a jpeg file and output ROC Curve in that file
  dest_filename = tempfile(pattern = ''rocCurve_'', tmpdir = mainDir)  
  dest_filename = paste(dest_filename, ''.jpg'',sep="")  
  print(dest_filename, quote=FALSE);
  jpeg(filename=dest_filename, height=1800, width = 1800, res = 300); 
  
  # Plot ROC Curve
  pred <- prediction(AttendeePredictions$AttendeePrediction, AttendeePredictions$Attendee)
  perf <- performance(pred,"tpr","fpr")
  plot(perf)
  abline(a=0,b=1)
  dev.off()
  
  # Print Area under the Curve
  auc <- performance(pred, "auc")
  print(paste0("Area under ROC Curve : ", as.numeric(auc@y.values)))
',  
@input_data_1 = N'SELECT b.AttendeePrediction, a.Attendee FROM [dbo].[CommunityMemberTest] a INNER JOIN [dbo].[AttendeePredictions] b ON a.MemberKey = b.MemberKey',  
@input_data_1_name = N'AttendeePredictions';

END;
GO

EXEC [dbo].[proc_PlotROCCurve];
GO

!!"C:\\temp\\rocCurve_39983be1107d.jpg"
GO

SELECT b.AttendeePrediction, a.Attendee FROM [dbo].[CommunityMemberTest] a 
INNER JOIN [dbo].[AttendeePredictions] b ON a.MemberKey = b.MemberKey
ORDER BY 1 DESC;
GO

-----------------------------------------
-- Let's predict!
-----------------------------------------

CREATE OR ALTER PROCEDURE dbo.proc_PredictAttendee
  @age int, @children int, @yearlyincome money, @hascar int, @distance int, @maritalstatus int
AS 
	DECLARE @model varbinary(max) = (SELECT TOP 1 Model FROM dbo.Models);
BEGIN
	EXEC sp_execute_external_script
		@language = N'R',
		@script = N'df <- InputDataSet
					model <- unserialize(model)
					df$prediction <- rxPredict(model, data = df)
					df$prediction <- as.numeric(df$prediction)
					OutputDataSet <- df',
		@input_data_1 = N'SELECT @age AS Age, @children AS Children, @yearlyincome AS YearlyIncome, @hascar AS HasCar, @distance AS Distance, @maritalstatus AS MaritalStatus;',
		@params = N'@model varbinary(max), @age int, @children int, @yearlyincome money, @hascar int, @distance int, @maritalstatus int',
		@model = @model,
		@age = @age,
		@children = @children,
		@yearlyincome = @yearlyincome,
		@hascar = @hascar,
    @distance = @distance,
    @maritalstatus = @maritalstatus
		WITH RESULT SETS ((Age int, Children int, YearlyIncome money, HasCar int, Distance int, MaritalStatus int, PredictedAttendeeProb float));
END;
GO

DECLARE	@return_value int;
EXEC @return_value = dbo.proc_PredictAttendee
  @age = 40,
  @children = 3,
  @yearlyincome = 300000,
  @hascar = 1,
  @distance = 300,
  @maritalstatus = 1;
GO

-------------------------------------------
-- Let's predict on 1000 new members
-------------------------------------------

SELECT * FROM dbo.CommunityMemberNew;
GO

-- Normalization

DROP TABLE IF EXISTS dbo.CommunityMemberNew_Normalized;
GO

SELECT 
  MemberKey,
  Age,
  CASE MaritalStatus WHEN 'S' THEN 0 ELSE 1 END AS MaritalStatus,
  CASE Gender WHEN 'M' THEN 0 ELSE 1 END AS Gender,
  YearlyIncome,
  Children,
  HasHouse,
  HasCar,
  CASE PLSSUGChapter 
    WHEN 'Wroclaw' THEN 0
    WHEN 'Katowice' THEN 170
    WHEN 'Cracow' THEN 240
    WHEN 'Lublin' THEN 390
    WHEN 'Warsaw' THEN 300
    WHEN 'Poznan' THEN 145
    WHEN 'Lodz' THEN 185
    WHEN 'Tricity' THEN 380
    WHEN 'Bydgoszcz & Torun' THEN 230
    ELSE 500
  END AS Distance
INTO dbo.CommunityMemberNew_Normalized
FROM dbo.CommunityMemberNew;
GO

SELECT * FROM dbo.CommunityMemberNew_Normalized;
GO

CREATE OR ALTER PROCEDURE [dbo].[proc_PredictAttendeesNew] 
AS  
BEGIN  
  DECLARE @inquery nvarchar(max) = N'SELECT * FROM [dbo].[CommunityMemberNew_Normalized]'; 
  DECLARE @model varbinary(max) = (SELECT TOP 1 Model FROM dbo.Models);
  
  DROP TABLE IF EXISTS [dbo].[AttendeePredictionsNew];
  CREATE TABLE [dbo].[AttendeePredictionsNew]([AttendeePrediction] [float] NULL, [MemberKey] [int] NULL);

  INSERT INTO [dbo].[AttendeePredictionsNew]   
  EXEC sp_execute_external_script 
  @language = N'R',
  @script = N'  
  rfModel <- unserialize(as.raw(model));  
  OutputDataSet<-rxPredict(rfModel, data = InputDataSet, extraVarsToWrite = c("MemberKey"))
  ',
  @input_data_1 = @inquery,
  @params = N'@model varbinary(max)',
  @model = @model;
  
END;
GO

EXEC [dbo].[proc_PredictAttendeesNew];
GO

SELECT TOP 10 * FROM [dbo].[AttendeePredictionsNew];
GO

CREATE OR ALTER VIEW dbo.view_CommunityMemberNew_Attendee
AS
SELECT
  c.MemberKey,
  c.Age,
  c.MaritalStatus,
  c.Gender,
  c.YearlyIncome,
  c.Children,
  c.HasHouse,
  c.HasCar,
  c.PLSSUGChapter,
  a.AttendeePrediction
FROM dbo.CommunityMemberNew AS c
LEFT JOIN dbo.AttendeePredictionsNew AS a
ON c.MemberKey = a.MemberKey;
GO

SELECT * FROM dbo.view_CommunityMemberNew_Attendee;
GO