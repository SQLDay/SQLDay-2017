use master;
GO
select * from string_split('To jest tekst w jednej linii',' ')
select * from string_split('1,2,32,231,1232,393833',',')



GO
select * from string_split('To
jest tekst
w wielu
linijkach',nchar(13)+nchar(10))
GO
-- UPS! tylko jeden znak na separator!



-- prawie dobrze
select * from string_split('To
jest tekst
w wielu
linijkach',nchar(13))
GO


--obje�cie: REPLACE separatora z wielu znak�w na jeden nie wyst�puj�cy w tek�cie ;)
declare @Text nvarchar(max) = N'To
jest tekst
w wielu
linijkach';
select * from string_split(replace(@Text,nchar(13)+nchar(10),nchar(1)),nchar(1));
GO

-- Zastosowanie

select OBJECT_DEFINITION(object_id('sp_helptext')) Ucina

-- naprawiamy: 

sp_helptext sp_helptext
GO

-- teraz po nowemu: Tools->Options->Query results->SQL Server->Results to text
GO
create or alter function dbo.fn_helptext(@name sysname)
returns table 
as
return (
select value as line 
  from string_split(replace(object_definition(object_id(@name)),nchar(13)+nchar(10),nchar(13)),nchar(13))
);
GO

select t.line from dbo.fn_helptext ('sp_helptext') t


-- czy to jest szybkie?
select o.name, t.line from sys.all_objects o cross apply dbo.fn_helptext (o.name) t
GO


-- problem: Brak sterowania kolejno�ci� zwracania wierszy (brak numer�w wierszy w rezultacie funkcji!)
GO

-- domy�lnie  dzia�a
select o.name, t.line, 
ROW_NUMBER() over(partition by o.name order by o.name) rn 
from sys.all_objects o cross apply fn_helptext (o.name) t
GO


-- robimy ma�� demolk� wymuszaj�c z�y sort
select o.name, t.line, 
ROW_NUMBER() over(partition by o.name order by o.name) rn, 
ROW_NUMBER() OVER(order by newid()) mieszacz
from sys.all_objects o cross apply fn_helptext (o.name) t
GO
drop table if exists #t
GO
select o.name, t.line, 
ROW_NUMBER() over(partition by o.name order by o.name) rn, 
ROW_NUMBER() OVER(order by newid()) mieszacz into #t
from sys.all_objects o cross apply fn_helptext (o.name) t
GO
select * from #t t order by t.name, t.rn;
GO