alter database [WWI_DW] set compatibility_level = 130;
GO

use WWI_DW;
GO
if not exists (select 1 from sys.filegroups where name = 'ARCHIVE')
  alter database [WWI_DW] add filegroup [ARCHIVE];
GO

select * into Fact.SaleArchive on ARCHIVE from Fact.Sale;

select * from Fact.SaleArchive
GO

set identity_insert Fact.SaleArchive on;
insert into Fact.SaleArchive ([Sale Key],[City Key],[Customer Key],[Bill To Customer Key],[Stock Item Key],[Invoice Date Key],[Delivery Date Key],[Salesperson Key],[WWI Invoice ID],[Description],[Package],[Quantity],[Unit Price],[Tax Rate],[Total Excluding Tax],[Tax Amount],[Profit],[Total Including Tax],[Total Dry Items],[Total Chiller Items],[Lineage Key])
select top 10 [Sale Key],[City Key],[Customer Key],[Bill To Customer Key],[Stock Item Key],[Invoice Date Key],[Delivery Date Key],[Salesperson Key],[WWI Invoice ID],[Description],[Package],[Quantity],[Unit Price],[Tax Rate],[Total Excluding Tax],[Tax Amount],[Profit],[Total Including Tax],[Total Dry Items],[Total Chiller Items],[Lineage Key] from Fact.Sale;
set identity_insert Fact.SaleArchive off;
GO

if not exists (select * from sys.database_files where name = N'WWI_Archive')
alter database [WWI_DW] add file ( 
	NAME = N'WWI_Archive', 
	FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.VNXEXT\MSSQL\DATA\WWI_Archive.ndf'
) to filegroup [ARCHIVE];
GO

set identity_insert Fact.SaleArchive on;
insert into Fact.SaleArchive ([Sale Key],[City Key],[Customer Key],[Bill To Customer Key],[Stock Item Key],[Invoice Date Key],[Delivery Date Key],[Salesperson Key],[WWI Invoice ID],[Description],[Package],[Quantity],[Unit Price],[Tax Rate],[Total Excluding Tax],[Tax Amount],[Profit],[Total Including Tax],[Total Dry Items],[Total Chiller Items],[Lineage Key])
select top 10 [Sale Key],[City Key],[Customer Key],[Bill To Customer Key],[Stock Item Key],[Invoice Date Key],[Delivery Date Key],[Salesperson Key],[WWI Invoice ID],[Description],[Package],[Quantity],[Unit Price],[Tax Rate],[Total Excluding Tax],[Tax Amount],[Profit],[Total Including Tax],[Total Dry Items],[Total Chiller Items],[Lineage Key] from Fact.Sale;
set identity_insert Fact.SaleArchive off;
GO

select * into Fact.SaleArchive1 on PS_Date([Invoice Date Key]) from Fact.Sale;
GO


drop table Fact.SaleArchive;
