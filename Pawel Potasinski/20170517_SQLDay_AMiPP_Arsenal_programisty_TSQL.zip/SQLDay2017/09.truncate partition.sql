/*

SQL Server 2016 Demos
T-SQL Enhancements

*/

--Setup database

USE master;
GO

IF DB_ID('Test') IS NOT NULL BEGIN
  ALTER DATABASE Test SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
  DROP DATABASE Test;
END;
GO

CREATE DATABASE Test;
GO

USE Test;
GO

CREATE PARTITION FUNCTION pfTest (int)
AS RANGE LEFT FOR VALUES (1, 100, 1000);
GO

CREATE PARTITION SCHEME psTest
AS PARTITION pfTest
ALL TO ([PRIMARY]);
GO

CREATE TABLE dbo.Test1 (
	id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	name varchar(20) NOT NULL
) ON psTest(id);
GO

INSERT INTO dbo.Test1 (name)
SELECT LEFT(name, 20) FROM sys.all_columns;
GO

SELECT $partition.pfTest(id) AS partition, COUNT(id) AS cnt
FROM dbo.Test1
GROUP BY $partition.pfTest(id);
GO

-- chcemy pozby� si� danych z partycji 1, 3, 4

-- bez min. SQL Server 2016

if object_id('test1_tmp') is not null drop table test1_tmp;
 
create table test1_tmp (
	id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	name varchar(20) NOT NULL
) ON psTest(id);
GO
truncate table test1_tmp;
alter table test1 switch partition 1 to test1_tmp partition 1;
alter table test1 switch partition 3 to test1_tmp partition 3;
alter table test1 switch partition 4 to test1_tmp partition 4;
GO

-- a teraz...

truncate table dbo.Test1;

insert into dbo.Test1 (name)
select left(name, 20) from sys.all_columns;

SELECT $partition.pfTest(id) AS partition, COUNT(id) AS cnt
FROM dbo.Test1
GROUP BY $partition.pfTest(id);


TRUNCATE TABLE dbo.Test1
WITH (PARTITIONS (1, 3 TO 4));
GO

SELECT $partition.pfTest(id) AS partition, COUNT(id) AS cnt
FROM dbo.Test1
GROUP BY $partition.pfTest(id);
GO
