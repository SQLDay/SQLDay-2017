-- drop if exists, create or alter
use tempdb;

-- jak kiedy� chcieli�my skrypt uruchamialny wielokrotnie...
if object_id('dbo.my_tables') is not null drop view dbo.my_tables;
GO
create view dbo.my_tables
as
select * from sys.tables;
GO

-- wady:
-- 1. Du�o pisania
-- 2. Drop usuwa nie tylko obiekt ale i uprawnienia, indexy, triggery...
-- 3. Jak napiszemy co� co nie dzia�a (sk�adniowo), tracimy poprzedni� wersj� obiektu
GO




GO
create or alter view dbo.my_tables
as
select * from sys.tables;
GO 2

create or alter procedure dbo.do_nothing
as;
GO

-- czy to ju� nowa operacja DDL?

-- zobaczmy

create or alter trigger ddl_show_whats_on 
on database
for ddl_database_level_events
as
select EVENTDATA();
GO
-- uwaga na SQL 2016 SP1!! 




drop view if exists dbo.my_tables;
GO
drop view if exists dbo.my_tables;
GO
drop procedure if exists dbo.do_nothing;
GO
drop procedure if exists dbo.do_nothing;
GO

-- czego nie wolno?


-- tego co normalnie przy alter, np. zmiany typu obiektu
GO
create or alter function dbo.fn_test()
returns table as return (select 1 a);
GO
create or alter function dbo.fn_test()
returns table as return (select 1 b);
GO
create or alter function dbo.fn_test()
returns @t table (a int) as 
begin
  return;
end;
GO
-- a co mamy w object_definition? (CREATE? CREATE OR ALTER?)
sp_helptext 'fn_test';
GO
create 
or -- komentarz 
alter -- i jeszcze jeden
function dbo.fn_test()
returns table as return (select 1 b);
GO

sp_helptext 'fn_test';

GO

drop function if exists dbo.fn_test;
GO 2

drop trigger if exists ddl_show_whats_on on database;
GO
drop trigger if exists ddl_show_whats_on on database;
GO


-- tak si� jeszcze nie da :(
create table if not exists dbo.tab_1 (a int);
GO


-- tak, rzecz jasna, tym bardziej ;)
create or alter table dbo.tab_a(a int, b int, c int);
GO

