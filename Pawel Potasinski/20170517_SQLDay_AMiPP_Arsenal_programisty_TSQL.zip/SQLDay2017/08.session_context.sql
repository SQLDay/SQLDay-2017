-- context
-- w czasach aplikacji klient serwer...
use tempdb;
GO
drop table if exists dbo.EventLog;
GO
CREATE TABLE  dbo.EventLog(
	Id int identity (1,1),
	EventMessage nvarchar(200),
	Date datetime default getdate(),
	UserName sysname default suser_sname()
	)
GO
insert into dbo.EventLog (EventMessage) select 'Co� posz�o nie tak';
GO
select * from EventLog;
GO

-- teraz suser_sname() zwraca konto serwera aplikacyjnego



-- Do 2016 jak chcieli�my ustawi� co� globalnie dost�pnego dla po��czenia...

declare @context varbinary(128) = convert(varbinary(128),'SQL Day 2017')
set context_info @context;
GO
select convert(varchar(100),CONTEXT_INFO())
GO


-- Problemy: 
-- 1. Tylko jedna warto�� na po��czenie
-- 2. Ka�dy mo�e j� nadpisa�
-- 3. Brzydkie varbinary(128)

-- rozwi�zanie: Na pocz�tek ka�dego connection ustawiamy kontekst u�ytkownika (aplikacyjnego)
EXEC sp_set_session_context 'app_user', 'Marek';  
GO
select SESSION_CONTEXT('app_user') as ApplicationUser;
GO

select SESSION_CONTEXT(N'app_user') as ApplicationUser;
GO

drop table if exists dbo.EventLog2;

GO
CREATE TABLE  dbo.EventLog2(
	Id int identity (1,1),
	EventMessage nvarchar(200),
	Date datetime default getdate(),
	UserName sysname null default SESSION_CONTEXT(N'app_user')
	);
GO


CREATE TABLE  dbo.EventLog2(
	Id int identity (1,1),
	EventMessage nvarchar(200),
	Date datetime default getdate(),
	UserName sysname null default convert(nvarchar(128),SESSION_CONTEXT(N'app_user'))
	);
GO

insert into dbo.EventLog2(EventMessage) select 'Co� posz�o nie tak';
GO
select * from EventLog2;
GO

-- nie ma czyszczenia. Mo�na tylko ustawi� null
EXEC sp_set_session_context 'app_user', NULL;  
GO
create or alter procedure dbo.set_user_name @new_name sysname
as
begin
  -- kontekst jest globalny
  EXEC sp_set_session_context 'app_user', @new_name;  
end;
GO
exec dbo.set_user_name 'Heniek'
GO
insert into dbo.EventLog2(EventMessage) select 'Co� posz�o nie tak';
GO
select * from dbo.EventLog2
GO


-- ile mo�na takich parametr�w zdefiniowa�? Do limitu 1 MB per sesja
declare @i int = 1, @name nvarchar(10),@Value nvarchar(255);
set @value = replicate('x',1024)
while @i < 10000 begin
  set @name = @i;
  exec sp_set_session_context @name, @value
  --select @i;
  set @i = @i + 1;
end;
GO
select * from sys.dm_os_memory_objects where type = 'MEMOBJ_SESSION_CONTEXT'
GO

--!RECONNECT!!!
use tempdb;

select * from sys.dm_os_memory_objects where type = 'MEMOBJ_SESSION_CONTEXT'


insert into dbo.EventLog2(EventMessage) select 'Co� posz�o nie tak';
GO
select * from EventLog2;
GO

exec set_user_name 'Krzychu'
GO
insert into dbo.EventLog2(EventMessage) select 'Co� posz�o nie tak';
GO
select * from EventLog2;
GO

-- chcemy jeszcze jeden parametr. Dat�, z kt�r� pracuje aplikacja
GO
declare @date date = getdate();
exec sp_set_session_context N'business_day',@date;
select SESSION_CONTEXT(N'business_day');
GO
alter table EventLog2 add business_day date not null default convert(date,SESSION_CONTEXT(N'business_day'))
GO
insert into dbo.EventLog2(EventMessage) select 'Nowy komunikat';
GO
select * from dbo.EventLog2;
GO
exec sp_set_session_context N'business_day',null;
GO
insert into dbo.EventLog2(EventMessage) select 'Nie uda si�';
GO



-- parametr, kt�rego nie wolno nadpisywa�
EXEC sp_set_session_context 'application_key', 0xdeadbeef, @read_only = 1;


select SESSION_CONTEXT(N'application_key')


EXEC sp_set_session_context 'application_key', 0xfffff;
GO
EXEC sp_set_session_context 'application_key', null;
GO
