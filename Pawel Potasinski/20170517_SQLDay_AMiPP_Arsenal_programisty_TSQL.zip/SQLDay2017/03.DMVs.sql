-- SQL Server 2016

select es.session_id, ib.event_info   
from sys.dm_exec_sessions as es  
cross apply sys.dm_exec_input_buffer(es.session_id, NULL) AS ib  
where es.session_id > 50;
GO

use AdventureWorks2014;

drop table if exists #stats_before;
select wait_type, wait_time_ms, signal_wait_time_ms into #stats_before 
from sys.dm_exec_session_wait_stats where session_id = @@SPID;

SELECT *
FROM Sales.SalesOrderDetail sod
INNER JOIN Production.Product p ON sod.ProductID = p.ProductID
ORDER BY Style;

select 
  s.wait_type,
  s.wait_time_ms - isnull(b.wait_time_ms, 0) as wait_time_ms,
  s.signal_wait_time_ms - isnull(b.signal_wait_time_ms, 0) as signal_wait_time_ms
from sys.dm_exec_session_wait_stats as s
left join #stats_before as b
on s.wait_type = b.wait_type 
where s.session_id = @@SPID and (s.wait_time_ms - isnull(b.wait_time_ms, 0)) > 0
order by wait_time_ms desc;
GO

DROP FUNCTION IF EXISTS Sales.fn_QuantitySold;
GO
CREATE OR ALTER FUNCTION Sales.fn_QuantitySold(@ProductID int) 
RETURNS int
AS
BEGIN
	DECLARE @Res int;
	
	SELECT @Res = SUM(OrderQty)
	FROM Sales.SalesOrderDetail 
	WHERE ProductID = @ProductID;
	
	IF (@Res IS NULL)
		SET @Res = 0;
	
	RETURN @Res;
END;
GO

SELECT 
  ProductID, 
  Name, 
  Sales.fn_QuantitySold(ProductID) AS QuantitySold
FROM Production.Product;

select * from sys.dm_exec_function_stats 
where object_id = object_id('Sales.fn_QuantitySold');
GO

SELECT counter_name, counter_value   
FROM sys.dm_external_script_execution_stats   
WHERE language = 'R';
GO

-- SQL Server 2016 SP1

select * from sys.dm_exec_valid_use_hints;
select sql_memory_model, sql_memory_model_desc from sys.dm_os_sys_info;
select servicename, instant_file_initialization_enabled from sys.dm_server_services

-- SQL Server 2017

select * from sys.dm_db_log_info(db_id());

SELECT name,count(l.database_id) as 'vlf_count' from sys.databases s
cross apply sys.dm_db_log_info(s.database_id) l
group by name
having count(l.database_id)> 100;

USE AdventureWorks2014;
GO

SELECT top 1 DB_NAME(database_id) as "Database Name",file_id,vlf_size_mb,vlf_sequence_number, vlf_active, vlf_status
from sys.dm_db_log_info(DEFAULT)
order by vlf_sequence_number desc;




