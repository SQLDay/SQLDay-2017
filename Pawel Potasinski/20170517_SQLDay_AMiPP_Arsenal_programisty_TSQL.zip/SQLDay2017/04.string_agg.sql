-- STRING_AGG() SQL Server 2017


select * from master.dbo.spt_values; 

-- chcemy mie� listy warto�ci po �redniku dla ka�dego typu


-- jak si� kiedy� chcia�o z�o�y� pojedynczy string z listy, to trzeba by�o tak:
select distinct type,
(select ';'+name from master.dbo.spt_values l where l.type = v.type for xml path (''))
as value_list
from master.dbo.spt_values v;

-- problem: separator z przodu
select distinct type,
stuff(
(select ';'+name from master.dbo.spt_values l where l.type = v.type for xml path ('')),
1,1,'') -- wycinamy pierwszy separator
as value_list
from master.dbo.spt_values v;
GO

-- problem: znaki specjalne xml'a
drop table if exists #x;
create table #x (txt nvarchar(10));
insert into #x (txt) values ('<'),('>'),('&');
select txt+';' from #x for xml path (''), type;
GO
-- mo�na by�o te� napisa� funkcj� agreguj�c� w CLR




-- teraz robimy to tak:
select type, string_agg(name,';') value_list from master.dbo.spt_values 
group by type;
GO
select string_agg(txt,';') from #x 


-- sort wewn�trzny
select string_agg (v.name,',') as languages from master.dbo.spt_values v where v.type = 'LNG'

select string_agg (convert(nvarchar(max),v.name),',') within group (order by v.name) as languages 
from master.dbo.spt_values v where v.type = 'LNG'
GO
--co z nullami, duplikatami i pustymi ci�gami?
--
drop table if exists #t;
GO
create table #t (id int identity primary key, letter varchar(10))
GO
set nocount on;
GO
insert into #t (letter) values (null);
GO
insert into #t (letter) values ('A'),('B')
GO
insert into #t (letter) values (null);
GO
insert into #t (letter) values ('');
GO
insert into #t (letter) values ('C'),('D')
GO
insert into #t (letter) values ('A'),('B')
GO
select * from #t;
GO

select string_agg(letter,'->') what_with_nulls from #t;
GO
select string_agg(letter,'->') empty_resultset from #t where 1 = 0; 
GO
select string_agg(letter,'->') only_nulls from #t where letter is null;
GO
select string_agg(letter,'->') one_element from #t where letter = 'C';
GO

-- co z duplikatami?



select distinct string_agg(letter,'->') from #t;
GO
select string_agg(distinct  letter,'->') one_element from #t;
GO

select count(number) numbers_cnt, count(distinct  number) distinct_numbers_cnt 
from master.dbo.spt_values
GO


with cte as (select distinct letter from #t) select string_agg(letter,'->') from cte;
GO
-- wersja okienkowa?
select *, count(*) over() from master.dbo.spt_values;

select *, string_agg(name,';') over() from master.dbo.spt_values;
GO


-- suma globalna?
select string_agg(name,';') from master.dbo.spt_values 
GO

sp_help 'dbo.spt_values'

select string_agg(convert(nvarchar(max),name),';') from master.dbo.spt_values 
GO
select string_agg(convert(varchar(8000),name),';') from master.dbo.spt_values 
GO
select string_agg(convert(varchar(100),name),';') from master.dbo.spt_values 
GO
-- zastosowanie: attach wszystkich baz u�ytkownika;
select concat('exec sys.sp_attach_db ',quotename(db_name(f.database_id),''''),',',
              string_agg(quotename(physical_name,''''),',') 
			  within group (order by f.file_id, f.type, f.name),';','
GO')
from sys.master_files f
where f.database_id > 4
group by f.database_id;
GO
-- zastosowanie: eksport danych do czystej bazy
declare @RemoteDb sysname = 'remote_db';
with cols as (
select object_id, string_agg(quotename(c.name),',') within group (order by c.column_id) names 
from sys.columns c 
where columnproperty(c.object_id,c.Name,'IsComputed') = 0 
group by c.object_id
)
select concat(
'insert into ',concat_ws('.',+@remoteDb,object_schema_name(t.object_id),t.name), -- UWAGA! CONCAT_WS
'(',cols.names,')','
select ',cols.names,' from '+concat_ws('.',object_schema_name(t.object_id),t.name),';
GO'
)
from sys.tables t join cols on t.object_id = cols.object_id;
GO

