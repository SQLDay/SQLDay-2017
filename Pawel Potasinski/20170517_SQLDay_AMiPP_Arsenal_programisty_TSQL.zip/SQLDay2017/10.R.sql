exec sp_configure 'external scripts enabled', 1;
reconfigure;
GO

-- wymaga restartu serwera!
SELECT * FROM sys.configurations WHERE name = 'external scripts enabled';
GO

use AdventureWorksDW2014;
GO
exec sp_execute_external_script
  @language = N'R',
  @script = N'
    png(filename="C:\\Temp\\Histogram.png");
    hist(ds$YearlyIncome);
    dev.off();',
  @input_data_1 = N'SELECT YearlyIncome FROM dbo.DimCustomer;',
  @input_data_1_name = N'ds';
GO
-- Query->SQLCMD Mode

!! "C:\Temp\Histogram.png"
GO

exec sp_execute_external_script
  @language = N'R',
  @script = N'
    print(summary(ds))',
  @input_data_1 = N'SELECT SalesAmount, OrderQuantity FROM dbo.FactInternetSales;',
  @input_data_1_name = N'ds';
GO