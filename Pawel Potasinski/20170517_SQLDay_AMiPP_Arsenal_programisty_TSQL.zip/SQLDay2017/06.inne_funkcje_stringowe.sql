--translate()

drop table if exists #t;
GO
-- lista obiekt�w z <kolumnami>,... 
select object_name(c.object_id) table_name, 
string_agg(quotename(c.name,'<'),',') within group (order by c.column_id) cols
into #t
from sys.columns c
group by object_name(object_id);
GO
select * from #t;

-- zamiana nawias�w ostrych na kwadratowe lub cudzys�owy
select *,
  translate(cols,'<>','[]'),
  translate(cols,'<>','""')
From #t;
GO

-- w drug� stron� - ju� jest problem :(
select *,
  translate(translate(cols,'<>','""'),'""','[]')
From #t;
GO

-- TRIM() = LTRIM(RTRIM())
select '|'+trim('   1 2 3  4         ')+'|';
GO

-- string_escape (tylko json)
select 
STRING_ESCAPE('"','json') as '"',
STRING_ESCAPE('/','json') as '/',
STRING_ESCAPE('\','json') as '\',
STRING_ESCAPE(char(13),'json') as '<CR>',
STRING_ESCAPE(char(10),'json') as '<LF>',
STRING_ESCAPE('	','json') as '<TAB>';
GO
-- przypomnienie CONCAT_WS
select CONCAT_WS('|',1,2,3,4,5,6,7,8,9) separator_tylko_raz;