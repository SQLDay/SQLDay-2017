USE tempdb;
GO

-- https://blogs.msdn.microsoft.com/sqlserverstorageengine/2016/01/05/returning-spatial-data-in-geojson-format-part-1/

drop function if exists dbo.asgeojson;
GO
create or alter function dbo.AsGeoJson( @geo geography)
returns nvarchar(max) as
begin
return (
  '{' +
  (CASE @geo.STGeometryType()
  WHEN 'POINT' THEN
  '"type": "Point","coordinates":' +
  REPLACE(REPLACE(REPLACE(REPLACE(@geo.ToString(),'POINT ',''),'(','['),')',']'),' ',',')
  WHEN 'POLYGON' THEN 
  '"type": "Polygon","coordinates":' +
  '[' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@geo.ToString(),'POLYGON ',''),'(','['),')',']'),'], ',']],['),', ','],['),' ',',') + ']'
  WHEN 'MULTIPOLYGON' THEN 
  '"type": "MultiPolygon","coordinates":' +
  '[' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@geo.ToString(),'MULTIPOLYGON ',''),'(','['),')',']'),'], ',']],['),', ','],['),' ',',') + ']'
  WHEN 'MULTIPOINT' THEN
  '"type": "MultiPoint","coordinates":' +
  '[' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@geo.ToString(),'MULTIPOINT ',''),'(','['),')',']'),'], ',']],['),', ','],['),' ',',') + ']'
  WHEN 'LINESTRING' THEN
  '"type": "LineString","coordinates":' +
  '[' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@geo.ToString(),'LINESTRING ',''),'(','['),')',']'),'], ',']],['),', ','],['),' ',',') + ']'
  ELSE NULL
  END)
  +'}'
);
END;
GO

-- http://geojson.io

declare @locations table (name varchar(20), location geography);
insert @locations 
select 
  'SQLDay 2017', 
  geography::STGeomFromText('POINT(17.077356576919556 51.10694410983586)', 4326);

select 
 'Feature' AS type,
 'Point' as [geometry.type],
 JSON_QUERY
 ( 
 FORMATMESSAGE('[%s,%s]',
 FORMAT(location.Long, N'0.##################################################'),
 FORMAT(location.Lat, N'0.##################################################'))
 ) as [geometry.coordinates],
 name as [properties.name]
 from @locations
 for json path, without_array_wrapper;
 GO

 