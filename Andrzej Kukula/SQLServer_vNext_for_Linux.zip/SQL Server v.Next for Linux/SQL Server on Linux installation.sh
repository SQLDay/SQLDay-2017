# SQL Server on Linux installation

sudo echo  # enter sudo password


# add Microsoft's package signing key
curl https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add -


# add repository for SQL Server
curl https://packages.microsoft.com/config/ubuntu/16.04/mssql-server.list | sudo tee /etc/apt/sources.list.d/mssql-server.list


# add repository for SQL Server tools
curl https://packages.microsoft.com/config/ubuntu/16.04/prod.list | sudo tee /etc/apt/sources.list.d/msprod.list


# install SQL Server
sudo apt update
sudo apt install mssql-server -y
# (the download step is skipped, I've downloaded the packages earlier)
# it's installed but not running yet

# let's install additional components (if required)
# SQL Agent, Full Text Search service, HA component
sudo apt install mssql-server-agent mssql-server-fts mssql-server-ha -y

# let's configure SQL Server
sudo /opt/mssql/bin/mssql-conf setup

# it's configured and now running
sudo systemctl status mssql-server --no-pager


# so now let's check if it's working - execute some SQL statements


# collation change


# first stop SQL Server
sudo systemctl stop mssql-server

sudo /opt/mssql/bin/mssql-conf set-collation

# and restart SQL Server
sudo systemctl start mssql-server

# and now check the collation in the other window


# and that's how to deinstall SQL Server and it's components
sudo apt remove mssql-server -y
sudo rm -rf /var/opt/mssql  # remove databases, logs etc.
