
# add my user to 'docker' group
# so I don't have to do everything with 'sudo'
sudo gpasswd -a andrzej docker; newgrp
sudo systemctl restart docker

# remove any existing containers
docker ps --format '{{.Names}}' | xargs -n1 -r docker rm -f >/dev/null



# pull the image from Docker Hub
docker pull microsoft/mssql-server-linux:latest



# list images available on this host
docker images



# list containers
docker ps -a



# create a SQL Server container
# first create a directory for data and log files
sudo rm -rf /var/opt/mssql_1  # remove old demos
sudo mkdir /var/opt/mssql_1

docker run -d -e 'ACCEPT_EULA=y' -e SA_PASSWORD='P@ssw0rd' \
    -p 1433:1433 -v /var/opt/mssql_1:/var/opt/mssql \
    --name mssql1 microsoft/mssql-server-linux

# in this scenario data and log files are stored outside of the container
# (but they're visible inside it)
# however it's easy to have fully contained solution,
# just omit the -v argument


# check if it's working
docker ps


# now try to execute some SQL statements in the other editor


# we can connect to the container with the shell
# (however normally there's no reason to)
docker exec -it mssql1 bash


# now let's attempt to create another instance, this time
# the older version

# first download the image from the Docker Hub
# (I did it earlier, obviously)
docker pull microsoft/mssql-server-linux:ctp1-4

# I'm cleaning up because there may be upgraded databases and it'll not start
sudo rm -rf /var/opt/mssql_2
sudo mkdir /var/opt/mssql_2

docker run -d -e 'ACCEPT_EULA=y' -e SA_PASSWORD='P@ssw0rd' \
    -p 1435:1433 -v /var/opt/mssql_2:/var/opt/mssql \
    --name mssql2 microsoft/mssql-server-linux:ctp1-4

# check what's shown by SELECT @@VERSION
# notice the CTP number

# create an empty database so we can confirm later 
# it's the same container

# now let's show how to upgrade a container to a newer version
# IRL we would create backup of all databases first

# create a container without running it
# map the same TCP port and same directory

docker create -e 'ACCEPT_EULA=y' -e SA_PASSWORD='P@ssw0rd' \
    -p 1435:1433 -v /var/opt/mssql_2:/var/opt/mssql \
    --name mssql2upgraded microsoft/mssql-server-linux:latest


# check it
docker ps -a


# stop the old container
docker stop mssql2


# start the new one
docker start mssql2upgraded

# check @@VERSION and if the database is still present


# check SQL Server logs for upgrade info
docker logs mssql2upgraded


# remove the old container (no need to stop it)
docker rm mssql2


# rename the upgraded one to original name
# (so that maintenance scripts continue to work)
docker rename mssql2upgraded mssql2

# that's it!
