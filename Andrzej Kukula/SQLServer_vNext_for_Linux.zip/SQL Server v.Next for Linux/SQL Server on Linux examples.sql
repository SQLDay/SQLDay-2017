print @@version;

print @@servername;

-- let's check the collation of the server
-- (it was not specified during the setup)
print convert(varchar, serverproperty('collation'));
-- for SQL Server on Windows it could mean reinstallation
-- let's check what we can do on Linux

-- DISCONNECT first (CTRL+SHIFT+D)


select name, collation_name, * from sys.databases;


create database MyDB;
