--RESET...

USE [master]
GO
ALTER DATABASE [SQLSat] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
DROP DATABASE [SQLSat]
GO
CREATE DATABASE [SQLSat]
ON PRIMARY
( NAME = N'SQLSat', FILENAME = N'C:\SQLServer\DATA\SQLSat.mdf' , SIZE = 8192KB , FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'SQLSat_log', FILENAME = N'C:\SQLServer\DATA\SQLSat_log.ldf' , SIZE = 4096KB , FILEGROWTH = 1024KB)
GO



USE SQLSat
GO

--Developer buddy wants my database
BACKUP DATABASE SQLSat TO DISK = 'C:\SQLServer\Backup\demo3.bak'
GO
--Log is "reset".
--This is the start of something new :)

SELECT database_id, name, create_date, recovery_model_desc, log_reuse_wait_desc
FROM sys.databases 
WHERE name = 'SQLSat'



--CLEARING THE LOG - the right way
BACKUP LOG [SQLSat] TO DISK = 'C:\SQLServer\Backup\demo3.bak'




--CLEARING THE LOG - the other way
ALTER DATABASE [SQLSat] SET RECOVERY SIMPLE WITH NO_WAIT




--BUT The log can still grow!
BEGIN TRAN
UPDATE SQLSat.dbo.loadtest SET added = GETDATE()

DELETE FROM SQLSat.dbo.loadtest
ROLLBACK TRAN



ALTER DATABASE [SQLSat] SET RECOVERY FULL WITH NO_WAIT
--The flipping voids the backup!!!

UPDATE SQLSat.dbo.loadtest SET added = GETDATE()
DELETE FROM SQLSat.dbo.loadtest
