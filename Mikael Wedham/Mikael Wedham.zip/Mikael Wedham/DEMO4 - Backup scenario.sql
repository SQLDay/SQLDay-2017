ALTER DATABASE [SQLSat] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
DROP DATABASE [SQLSat]
GO
CREATE DATABASE [SQLSat]
ON PRIMARY
( NAME = N'SQLSat', FILENAME = N'C:\SQLServer\DATA\SQLSat.mdf' , SIZE = 16384KB , FILEGROWTH = 16384KB )
 LOG ON 
( NAME = N'SQLSat_log', FILENAME = N'C:\SQLServer\DATA\SQLSat_log.ldf' , SIZE = 8192KB , FILEGROWTH = 4096KB)
GO


ALTER DATABASE [SQLSat] SET RECOVERY FULL 
GO


--RESET APPLICATION


EXEC msdb..sp_delete_backuphistory '20500101' --ridiculous large date...

BACKUP DATABASE [SQLSat] TO DISK = 'C:\SQLServer\Backup\MyFullBackup.bak'
WITH DESCRIPTION = 'This is my full backup', NAME = 'BACKUPSET1', INIT, MEDIADESCRIPTION = 'The full device', MEDIANAME = 'THEMEDIANAME'  


BACKUP LOG [SQLSat] TO DISK = 'C:\SQLServer\Backup\MyLogBackups.bak'
WITH DESCRIPTION = 'This is my log backup', NAME = 'LOGSET1', INIT, MEDIADESCRIPTION = 'The log device', MEDIANAME = 'THEMEDIANAME_LOG'  

CHECKPOINT

BACKUP LOG [SQLSat] TO DISK = 'C:\SQLServer\Backup\MyLogBackups.bak'
WITH DESCRIPTION = 'This is my second log backup', NAME = 'LOGSET2', INIT, MEDIADESCRIPTION = 'The log device', MEDIANAME = 'THEMEDIANAME_LOG'  


SELECT backup_set_id, name, description, type, physical_device_name 
FROM msdb..backupset s INNER JOIN msdb..backupmediafamily f
ON s.media_set_id = f.media_set_id


RESTORE DATABASE [SQLSat] FROM DISK = 'C:\SQLServer\Backup\MyFullBackup.bak' WITH REPLACE, NORECOVERY
RESTORE LOG [SQLSat] FROM DISK = 'C:\SQLServer\Backup\MyLogBackups.bak'

--Get LSN from error...

SELECT backup_set_id, media_set_id, first_lsn, last_lsn 
FROM msdb..backupset

RESTORE HEADERONLY FROM DISK = 'C:\SQLServer\Backup\MyFullBackup.bak'

RESTORE HEADERONLY FROM DISK = 'C:\SQLServer\Backup\MyLogBackups.bak'
