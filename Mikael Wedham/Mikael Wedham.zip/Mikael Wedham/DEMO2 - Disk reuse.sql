/*
USE [master]
GO
ALTER DATABASE [SQLSat] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
DROP DATABASE [SQLSat]
GO
CREATE DATABASE [SQLSat]
ON PRIMARY
( NAME = N'SQLSat', FILENAME = N'C:\SQLServer\DATA\SQLSat.mdf' , SIZE = 8192KB , FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'SQLSat_log', FILENAME = N'C:\SQLServer\DATA\SQLSat_log.ldf' , SIZE = 4096KB , FILEGROWTH = 1024KB)

GO
*/

USE SQLSat
GO

SELECT * FROM sys.sysfiles
--No size change, log usage changes.
SELECT * FROM SQLSat.sys.dm_db_log_space_usage


DBCC LOGINFO('SQLSat')

--A checkpoint CAN truncate some of the log.
CHECKPOINT

