/*
ALTER DATABASE [SQLSat] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
DROP DATABASE [SQLSat]
GO
CREATE DATABASE [SQLSat]
ON PRIMARY
( NAME = N'SQLSat', FILENAME = N'D:\SQLSat.mdf' , SIZE = 32768KB , FILEGROWTH = 16384KB )
 LOG ON 
( NAME = N'SQLSat_log', FILENAME = N'C:\SQL Server\DATA\SQLSat_log.ldf' , SIZE = 32768KB , FILEGROWTH = 16384KB)
GO
*/
/*
ALTER DATABASE SQLSat SET RECOVERY FULL 
GO

BACKUP DATABASE SQLSat TO DISK = 'C:\SQL Server\Backup\DefaultBackup_EmptyDatabase.bak' WITH INIT
GO
*/

--Start the loader...



--LOOP OF DAILY TASKS !!!!!!!!

SELECT MAX(added)
 FROM SQLSat.dbo.loadtest

CHECKPOINT

 
DBCC CHECKDB ('SQLSat') WITH NO_INFOMSGS

--LOOP OF DAILY TASKS !!!!!!!!





BACKUP LOG SQLSat TO DISK = 'C:\SQL Server\Backup\CrashLog.bak' WITH DESCRIPTION = 'This is my log backup', NAME = 'FAILED LOG',INIT
GO
--BACKUP LOG SQLSat TO DISK = 'C:\SQL Server\Backup\CrashLog.bak' WITH NORECOVERY
--GO




ALTER DATABASE SqlSat SET EMERGENCY

BACKUP LOG SQLSat TO DISK = 'C:\SQL Server\Backup\CrashLog.bak' 
WITH DESCRIPTION = 'This is my log tail'
, NAME = 'TAIL-BACKUP'
, NO_TRUNCATE
, CONTINUE_AFTER_ERROR 
, NORECOVERY












--AND NOW...
/*
USE [master]
RESTORE DATABASE [SQLSat] FROM  DISK = N'C:\SQL Server\Backup\DefaultBackup_EmptyDatabase.bak' 
WITH  FILE = 1,  MOVE N'SQLSat' TO N'C:\SQL Server\DATA\SQLSat.mdf'
,  NORECOVERY

RESTORE HEADERONLY  FROM  DISK = N'C:\SQL Server\Backup\CrashLog.bak'

RESTORE LOG [SQLSat] FROM  DISK = N'C:\SQL Server\Backup\CrashLog.bak' 
WITH  FILE = 1, NORECOVERY

RESTORE LOG [SQLSat] FROM  DISK = N'C:\SQL Server\Backup\CrashLog.bak' 
WITH  FILE = 2, RECOVERY
GO

SELECT MAX(added)
 FROM SQLSat.dbo.loadtest
*/
