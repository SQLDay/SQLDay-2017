----------------------------------------------------------------------------------------------
CREATE SCHEMA HistoryData;   
GO   

ALTER TABLE FestivalsAssistents   
   ADD   
      SysStartTime datetime2(0) GENERATED ALWAYS AS ROW START HIDDEN    
           CONSTRAINT DF_SystemStartDate DEFAULT SYSUTCDATETIME()  
      ,SysEndTime datetime2(0) GENERATED ALWAYS AS ROW END HIDDEN    
           CONSTRAINT DF_SystemEndTime DEFAULT CONVERT(datetime2 (0), '9999-12-31 23:59:59'),   
      PERIOD FOR SYSTEM_TIME (SysStartTime, SysEndTime);   
GO   

ALTER TABLE FestivalsAssistents   
   SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = HistoryData.FestivalsAssistents))  
