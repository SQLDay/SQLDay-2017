select * from FestivalsAssistents
update FestivalsAssistents set Ambit = 'M�sica' where IdFestival = 2
update FestivalsAssistents set Assistents = 500 where IdFestival = 2

select * from HistoryData.FestivalsAssistents 

SELECT	*
FROM	dbo.FestivalsAssistents
FOR SYSTEM_TIME ALL
WHERE	IdFestival = 2 