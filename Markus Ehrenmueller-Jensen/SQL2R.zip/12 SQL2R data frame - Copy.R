# data frame
# (c) Markus Ehrenmüller-Jensen

### DATA FRAMES

# 3 vectors
col1 <- c(11, 21, 31, 41)
col2 <- c(12, 22, 32, 42)
col3 <- c(13, 23, 33, 43)
df <- data.frame(col1, col2, col3)
df



# select one cell
df[3, 2]

# select second row
df[3,]

# select second column
df[,2]
df$col2

attach(df)
col2
detach(df)

with(df, col2)

# Add a column to data frame
col4 <- c(99, 98, 97, 96)
df <- cbind(df, col4)
df

# Add a row to data frame
df <- rbind(df, c(51, 52, 53, 54))
df



### LOADING DATA INTO DATAFRAME VIA CSV
setwd("C:\\Users\\Markus\\Dropbox\\SQL2R\\Data")
#write.csv(FactResellerSales, "FactResellerSalesByMonth.csv")
FactResellerSales <- read.csv("FactResellerSales.csv")
FactResellerSalesByDateSubCat <- read.csv("FactResellerSalesByDateSubCat.csv")

### ACCESS SQL SERVER VIA ODBC
#install.packages("RODBC")
library(RODBC)
MyConnection <- odbcDriverConnect('driver={SQL Server};server=localhost;database=AdventureWorksDW2014;trusted_connection=true')
MyConnection <- odbcConnect("AdventureWorksDW2014", uid="user", pwd="password")
DimProductCategory    <- sqlQuery(MyConnection, 'SELECT * FROM dbo.DimProductCategory')
DimProductSubCategory <- sqlQuery(MyConnection, 'SELECT * FROM dbo.DimProductSubCategory')
#FactResellerSales     <- sqlQuery(MyConnection, 'SELECT dp.EnglishProductName	,dps.EnglishProductSubcategoryName	,dpc.EnglishProductCategoryName	,dr.ResellerName	,dr.NumberEmployees	,dr.OrderFrequency	,dr.OrderMonth	,dr.FirstOrderYear	,dr.LastOrderYear	,dr.AnnualSales	,dr.BankName	,dr.MinPaymentType	,dr.MinPaymentAmount	,dr.AnnualRevenue	,dr.YearOpened	,dg.City	,dg.StateProvinceCode	,dg.StateProvinceName	,dg.CountryRegionCode	,dg.EnglishCountryRegionName	,dg.PostalCode	,dg.IpAddressLocator	,dst.SalesTerritoryRegion	,dst.SalesTerritoryCountry	,dst.SalesTerritoryGroup	,[SalesOrderNumber]	,[SalesOrderLineNumber]	,[RevisionNumber]	,[OrderQuantity]	,[UnitPrice]	,[ExtendedAmount]	,[UnitPriceDiscountPct]	,[DiscountAmount]	,[ProductStandardCost]	,[TotalProductCost]	,[SalesAmount]	,[TaxAmt]	,[Freight]	,[CarrierTrackingNumber]	,[CustomerPONumber]	,[OrderDate]	,[DueDate]	,[ShipDate] FROM 	[dbo].[FactResellerSales] frs	INNER JOIN dbo.DimProduct dp on		dp.ProductKey = frs.ProductKey	INNER JOIN dbo.DimProductSubcategory dps on		dps.ProductSubcategoryKey = dp.ProductSubcategoryKey	INNER JOIN dbo.DimProductCategory dpc on		dpc.ProductCategoryKey = dps.ProductCategoryKey	INNER JOIN dbo.DimReseller dr on		dr.ResellerKey = frs.ResellerKey	INNER JOIN dbo.DimGeography dg on		dg.GeographyKey = dr.GeographyKey	INNER JOIN dbo.DimSalesTerritory dst on		dst.SalesTerritoryKey = frs.SalesTerritoryKey		')
FactResellerSales     <- sqlQuery(MyConnection, 'SELECT [OrderDate], sum([SalesAmount]) SalesAmount  FROM[dbo] .[FactResellerSales] frs GROUP BY OrderDate')
close(MyConnection)


### TOP
#FactResellerSalesByDateSubCat
head(FactResellerSalesByDateSubCat)      #Returns the first or last parts of a vector, matrix, table, data frame or function
head(FactResellerSalesByDateSubCat, 1)
tail(FactResellerSalesByDateSubCat, 1)


### PROJECTION
FactResellerSalesByDateSubCat[,c("OrderDate", "EnglishProductSubcategoryName", "SalesAmount")]

#install.packages("dplyr")
require(dplyr)    
FactResellerSalesByDateSubCat %>% 
  select(OrderDate, EnglishProductSubcategoryName, SalesAmount)

### ORDERING
FactResellerSalesByDateSubCat[order(FactResellerSalesByDateSubCat$SalesAmount),]
FactResellerSalesByDateSubCat %>% 
  select(OrderDate, EnglishProductSubcategoryName, SalesAmount) %>% 
  arrange(SalesAmount) 
  

### WHERE
FactResellerSalesByDateSubCat[FactResellerSalesByDateSubCat$EnglishProductSubcategoryName=="Road Bikes",]
FactResellerSalesByDateSubCat[FactResellerSalesByDateSubCat$EnglishProductSubcategoryName %in% c("Road Bikes", "Mountain Bikes"),]

subset(FactResellerSalesByDateSubCat, EnglishProductSubcategoryName=="Road Bikes")

FactResellerSalesByDateSubCat %>% 
  select(OrderDate, EnglishProductSubcategoryName, SalesAmount) %>% 
  arrange(SalesAmount)%>% 
  filter(EnglishProductSubcategoryName=="Road Bikes") 
  



### DISTINCT
unique(FactResellerSalesByDateSubCat)




### AGGREGATE
#install.packages("dplyr")
require(dplyr)    
df <- data.frame(A = c(1, 1, 2, 3, 3), B = c(2, 3, 3, 5, 6))
df
df %>% group_by(A) %>% summarise(B = sum(B))

FactResellerSalesByDateSubCat %>%
  group_by(EnglishProductCategoryName) %>%
  summarise(SalesAmountSum = sum(SalesAmount))

# Total & Percentage
FactResellerSalesByDateSubCat %>%
  group_by(EnglishProductCategoryName) %>%
  summarise(SalesAmountSum = sum(SalesAmount),
            SalesAmountTotal = sum(FactResellerSalesByDateSubCat$SalesAmount),
            SalesAmountPerc = sum(SalesAmount) / sum(FactResellerSalesByDateSubCat$SalesAmount) * 100
            )

### ADD CALCULATED COLUMNS
# Total & Percentage
FactResellerSalesByDateSubCat %>%
  mutate(Margin = SalesAmount - TotalProductCost)


### JOINS
df1 <- data.frame(CustomerID = c(1, 1, 2, 3, 3), 
                  SalesAmount = c(20, 30, 30, 50, 60))
df1
df2 <- data.frame(CustomerID = c(1, 2, 4), 
                  Name = c("x","y","z"))
df2

#Outer join
merge(x = df1, y = df2, by = "CustomerID", all = TRUE)

#Left outer: 
merge(x = df1, y = df2, by = "CustomerID", all.x = TRUE)

#Right outer: 
merge(x = df1, y = df2, by = "CustomerID", all.y = TRUE)

#Cross join: 
merge(x = df1, y = df2, by = NULL)




#########################
### (UN)PIVOT
#spread()

