/* Run R Sript on SQL Server
 * (c) Markus Ehrenm�ller-Jensen
 */

use AdventureWorksDW2014
go

-- Execute very simple R code on SQL Server
EXEC sp_execute_external_script  
  @language =N'R',    
  @script=N'
  OutputDataSet <- InputDataSet
  ',      
  @input_data_1 =N'
  SELECT
	[OrderDate], sum([SalesAmount]) SalesAmount  
  FROM
	[dbo] .[FactResellerSales] frs 
  GROUP BY 
	OrderDate
  ORDER BY
	OrderDate'    
  WITH RESULT SETS ((
	OrderDate date, 
	SalesAmount decimal(18,2)
));

-- make predictions
EXEC sp_execute_external_script  
  @language =N'R',    
  @script=N'
	library(prophet);
	MyProphetDF <- FactResellerSales[,c("OrderDate", "SalesAmount")]
	colnames(MyProphetDF) <- c("ds", "y")
	MyProphetDF$ds = as.Date(format(MyProphetDF$ds, "%Y-%m-01"))
	library(dplyr)
	MyProphetDF <- MyProphetDF %>%
					group_by(ds) %>%
					summarise(y = sum(y))

	MyProphetModel <- prophet(df = MyProphetDF);
	MyProphetFuture <- make_future_dataframe(MyProphetModel, periods = 6, freq = "m");
	MyProphetForecast <- predict(MyProphetModel, MyProphetFuture);
	MyProphetForecast <- merge(x = MyProphetForecast, y = MyProphetDF, by = "ds", all = TRUE)
	MyProphetForecast <- merge(x = MyProphetForecast, y = MyProphetForecast[is.na(MyProphetForecast$y) == TRUE, c("ds", "yhat")], by = "ds", all = TRUE)
	
	OutputDataSet <- data.frame(OrderDate = as.POSIXct(MyProphetForecast$ds), SalesAmount = MyProphetForecast$y, SalesAmountPredicted = MyProphetForecast$yhat.y)
  ',      
  @input_data_1 =N'
  SELECT
	[OrderDate], sum([SalesAmount]) SalesAmount  
  FROM
	[dbo] .[FactResellerSales] frs 
  GROUP BY 
	OrderDate
  ORDER BY
	OrderDate'    
  ,@input_data_1_name = N'FactResellerSales'
  WITH RESULT SETS ((
	OrderDate date, 
	SalesAmount decimal(18,2),
	SalesAmountPredicted decimal(18,2)
));

-- return chart as binary
-- https://www.mssqltips.com/sqlservertip/4127/sql-server-2016-r-services-display-r-plots-in-reporting-services/
EXEC sp_execute_external_script  
  @language =N'R',    
  @script=N'
	library(prophet);
	MyProphetDF <- InputDataSet[,c("OrderDate", "SalesAmount")]
	colnames(MyProphetDF) <- c("ds", "y")
	MyProphetDF$ds = as.Date(format(MyProphetDF$ds, "%Y-%m-01"))
	library(dplyr)
	MyProphetDF <- MyProphetDF %>%
					group_by(ds) %>%
					summarise(y = sum(y))

	MyProphetModel <- prophet(df = MyProphetDF);
	MyProphetFuture <- make_future_dataframe(MyProphetModel, periods = 6, freq = "m");
	MyProphetForecast <- predict(MyProphetModel, MyProphetFuture);
	MyProphetForecast <- merge(x = MyProphetForecast, y = MyProphetDF, by = "ds", all = TRUE)
	MyProphetForecast <- merge(x = MyProphetForecast, y = MyProphetForecast[is.na(MyProphetForecast$y) == TRUE, c("ds", "yhat")], by = "ds", all = TRUE)

	#open file to render plot
	MyImage = tempfile()
	jpeg(filename = MyImage, width=800, height=800)
					
	#plot
	library(ggplot2)
	library(scales)
	ggplot(MyProphetForecast,
		   aes(x = ds,
			   y = y,
			   color = 1)) +
	  geom_line() +
	  geom_point() +
	  theme(text = element_text(size = 18)) +
	  scale_y_continuous(limits = c(0, 5000000), labels = comma) +
	  geom_line(y = MyProphetForecast$yhat.y, color = 2) +
	  geom_point(y = MyProphetForecast$yhat.y, color = 2) +
	  theme(legend.position = "none") +
	  labs(x = "Order Date",
		   y = "Sales Amount")		

	#return image
	dev.off()
	OutputDataSet <- data.frame(data = readBin(file(MyImage,"rb"), what = raw(), n = 1e6));
  ',      
  @input_data_1 =N'
  SELECT
	[OrderDate], sum([SalesAmount]) SalesAmount  
  FROM
	[dbo] .[FactResellerSales] frs 
  GROUP BY 
	OrderDate
  ORDER BY
	OrderDate'    
  WITH RESULT SETS ((
	plot varbinary(max)
));

GO

--exec MyRTable
CREATE OR ALTER PROC MyRTable (
	@FromDate date = null,
	@UntilDate date = null,
	@debug bit = 0
	)
AS
BEGIN
SET @FromDate  = isnull(@FromDate, {d'2013-01-01'})
SET @UntilDate = isnull(@UntilDate, {d'2014-12-01'})

if @debug=1 print convert(char, @FromDate)

DECLARE @InputData nvarchar(max)
SET @InputData = N'
  SELECT
	[OrderDate], sum([SalesAmount]) SalesAmount  
  FROM
	[dbo] .[FactResellerSales] frs 
  WHERE
	OrderDate >= {d''' + convert(char, @FromDate) + '''} and
	OrderDate <= {d''' + convert(char, @UntilDate) + '''}
  GROUP BY 
	OrderDate
  ORDER BY
	OrderDate'

if @debug=1 print @InputData

EXEC sp_execute_external_script  
  @language =N'R',    
  @script=N'
	library(prophet);
	MyProphetDF <- InputDataSet[,c("OrderDate", "SalesAmount")]
	colnames(MyProphetDF) <- c("ds", "y")
	MyProphetDF$ds = as.Date(format(MyProphetDF$ds, "%Y-%m-01"))
	library(dplyr)
	MyProphetDF <- MyProphetDF %>%
					group_by(ds) %>%
					summarise(y = sum(y))

	MyProphetModel <- prophet(df = MyProphetDF);
	MyProphetFuture <- make_future_dataframe(MyProphetModel, periods = 6, freq = "m");
	MyProphetForecast <- predict(MyProphetModel, MyProphetFuture);
	MyProphetForecast <- merge(x = MyProphetForecast, y = MyProphetDF, by = "ds", all = TRUE)
	MyProphetForecast <- merge(x = MyProphetForecast, y = MyProphetForecast[is.na(MyProphetForecast$y) == TRUE, c("ds", "yhat")], by = "ds", all = TRUE)
	
	OutputDataSet <- data.frame(OrderDate = as.POSIXct(MyProphetForecast$ds), SalesAmount = MyProphetForecast$y, SalesAmountPredicted = MyProphetForecast$yhat.x)
  ',      
  @input_data_1 =N'
  SELECT
	[OrderDate], sum([SalesAmount]) SalesAmount  
  FROM
	[dbo] .[FactResellerSales] frs 
  GROUP BY 
	OrderDate
  ORDER BY
	OrderDate'    
  WITH RESULT SETS ((
	OrderDate date, 
	SalesAmount decimal(18,2),
	SalesAmountPredicted decimal(18,2)
));

END
GO

--exec MyRPlot
--exec MyRPlot {d'2012-01-01'}, {d'2014-12-01'} 
CREATE TABLE MyRPlotTable (plot varbinary(max));
GO

--exec MyRPlot
CREATE OR ALTER PROC MyRPlot (
	@FromDate date = null,
	@UntilDate date = null,
	@debug bit = 0
	)
AS
BEGIN
SET @FromDate  = isnull(@FromDate, {d'2013-01-01'})
SET @UntilDate = isnull(@UntilDate, {d'2014-12-01'})

if @debug=1 print convert(char, @FromDate)

DECLARE @InputData nvarchar(max)
SET @InputData = N'
  SELECT
	[OrderDate], sum([SalesAmount]) SalesAmount  
  FROM
	[dbo] .[FactResellerSales] frs 
  WHERE
	OrderDate >= {d''' + convert(char, @FromDate) + '''} and
	OrderDate <= {d''' + convert(char, @UntilDate) + '''}
  GROUP BY 
	OrderDate
  ORDER BY
	OrderDate'

if @debug=1 print @InputData

TRUNCATE TABLE dbo.MyRPlotTable;

INSERT INTO dbo.MyRPlotTable
EXEC sp_execute_external_script  
  @language =N'R',    
  @script=N'
	library(prophet);
	MyProphetDF <- InputDataSet[,c("OrderDate", "SalesAmount")]
	colnames(MyProphetDF) <- c("ds", "y")
	MyProphetDF$ds = as.Date(format(MyProphetDF$ds, "%Y-%m-01"))
	library(dplyr)
	MyProphetDF <- MyProphetDF %>%
					group_by(ds) %>%
					summarise(y = sum(y))

	MyProphetModel <- prophet(df = MyProphetDF);
	MyProphetFuture <- make_future_dataframe(MyProphetModel, periods = 6, freq = "m");
	MyProphetForecast <- predict(MyProphetModel, MyProphetFuture);
	MyProphetForecast <- merge(x = MyProphetForecast, y = MyProphetDF, by = "ds", all = TRUE)
	MyProphetForecast <- merge(x = MyProphetForecast, y = MyProphetForecast[is.na(MyProphetForecast$y) == TRUE, c("ds", "yhat")], by = "ds", all = TRUE)

	#open file to render plot
	MyImage = tempfile()
	jpeg(filename = MyImage, width=500, height=500)
					
	#plot
	library(ggplot2)
	library(scales)
	ggplot(MyProphetForecast,
		   aes(x = ds,
			   y = y,
			   color = 1)) +
	  geom_line() +
	  geom_point() +
	  theme(text = element_text(size = 18)) +
	  scale_y_continuous(limits = c(0, 5000000), labels = comma) +
	  geom_line(y = MyProphetForecast$yhat.y, color = 2) +
	  geom_point(y = MyProphetForecast$yhat.y, color = 2) +
	  theme(legend.position = "none") +
	  labs(x = "Order Date",
		   y = "Sales Amount")		

	#return image
	dev.off()
	OutputDataSet <- data.frame(data = readBin(file(MyImage,"rb"), what = raw(), n = 1e6));

	###
	df <- InputDataSet
				image_file = tempfile(); #create a temporary file
				jpeg(filename = image_file, width=500, height=500); #create a JPEG graphic device
				hist(df$SalesAmount); #plot the histogram
				dev.off(); #dev.off returns the number and name of the new active device (after the specified device has been shut down). (device = graphical device)
				#file() opens a file, in this case the image. rb = read binary
				#readBin() reads binary data. what = described the mode of the data. In this case, it''s raw data. n = maximum number of records to read.
				#data.frame converts the data to a data frame, which is required as output by SQL Server. The result is written to the OutputDataset variable.
				OutputDataset <- data.frame(data=readBin(file(image_file,"rb"),what=raw(),n=1e6));

  ',      
  @input_data_1 = @InputData    
--  WITH RESULT SETS ((	plot varbinary(max)))
;
SELECT top 1 plot from dbo.MyRPlotTable;
END

--SELECT top 1 plot from dbo.MyRPlotTable;