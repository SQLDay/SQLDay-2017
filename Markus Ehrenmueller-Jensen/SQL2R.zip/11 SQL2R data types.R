# data types
# (c) Markus Ehrenmüller-Jensen

### Data types

a <- 1    # numeric
mode(a)
a <- "1"  # character
mode(a)
a <- '1'  # character
mode(a)
a <- TRUE # logical
mode(a)
a <-  1i # complex
mode(a)

### Special values
3/0               # Inf = Infinity
Inf               
is.infinite(4)    # FALSE
is.infinite(3/0)  # TRUE
is.infinite(Inf)  # TRUE
-3/0              # -Inf = negative Infinity
-Inf              # -Inf = negative Infinity
is.infinite(-3/0)  # TRUE
is.infinite(-Inf) # TRUE
1 < Inf           # TRUE
1 < -Inf          # FALSE


0/0               # NaN = Not A Number
is.nan(4)         # FALSE
is.nan(0/0)       # TRUE
is.nan(NaN)       # TRUE
1/0 - 1/0         # NaN
Inf - Inf         # NaN


NA                # Not Available
is.na(4)          # FALSE
is.na(NA)         # TRUE

Inf == Inf        # TRUE

NaN == NaN        # NA
NA == NaN         # NA
NA == NA          # NA

is.finite(Inf)    # FALSE
is.finite(-Inf)   # FALSE
is.finite(NaN)    # FALSE
is.finite(NA)     # FALSE




### METADATA ABOUT OBJECTS
a <- c(1, 2, 3)
mode(a)   # numeric
class(a)  # numeric
str(a)
a <- matrix(c(1,2,3))
mode(a)   # numeric
class(a)  # matrix
str(a)
a <- list(c(1,2,3))
mode(a)   # list
class(a)  # list
str(a)
a <- data.frame(c(1,2,3))
mode(a)   # list
class(a)  # data frame
str(a)

#end of file