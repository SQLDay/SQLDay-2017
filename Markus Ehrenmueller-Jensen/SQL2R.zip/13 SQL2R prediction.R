# prediction
# (c) Markus Ehrenmüller-Jensen

### prophet
#install.packages("prophet")
library(prophet);
MyProphetDF <- FactResellerSales[, c("OrderDate", "SalesAmount")]
colnames(MyProphetDF) <- c("ds", "y")
MyProphetDF$ds <- as.POSIXct(MyProphetDF$ds)
MyProphetDF$ds = as.Date(format(MyProphetDF$ds, "%Y-%m-01"))
library(dplyr)
MyProphetDF <- MyProphetDF %>%
				group_by(ds) %>%
				summarise(y = sum(y))

MyProphetModel <- prophet(df = MyProphetDF);
MyProphetFuture <- make_future_dataframe(MyProphetModel, periods = 6, freq = "m");
MyProphetForecast <- predict(MyProphetModel, MyProphetFuture);
MyProphetForecast <- merge(x = MyProphetForecast, y = MyProphetDF, by = "ds", all = TRUE)
MyProphetForecast <- merge(x = MyProphetForecast, y = MyProphetForecast[is.na(MyProphetForecast$y) == TRUE, c("ds", "yhat")], by = "ds", all = TRUE)
tail(MyProphetForecast, 7)


### PLOT ACTUAL & PREDICTED VALUES
#install.packages("ggplot2")
library(ggplot2)
library(scales)
ggplot(MyProphetForecast,
	   aes(x = ds,
		   y = y,
           color = 1)) +
  geom_line() +
  geom_point() +
  theme(text = element_text(size = 18)) +
  scale_y_continuous(limits = c(0, 5000000), labels = comma) +
  geom_line(y = MyProphetForecast$yhat.y, color = 2) +
  geom_point(y = MyProphetForecast$yhat.y, color = 2) +
  theme(legend.position = "none") +
  labs(x = "Order Date",
	   y = "Sales Amount")




###########
#open file to render plot
MyImage = tempfile()
jpeg(filename = MyImage, width = 800, height = 800)

#plot
library(ggplot2)
library(scales)
ggplot(MyProphetForecast,
		   aes(x = ds,
			   y = y,
			   color = 1)) +
	  geom_line() +
	  geom_point() +
	  theme(text = element_text(size = 18)) +
	  scale_y_continuous(limits = c(0, 5000000), labels = comma) +
	  geom_line(y = MyProphetForecast$yhat.y, color = 2) +
	  geom_point(y = MyProphetForecast$yhat.y, color = 2) +
	  theme(legend.position = "none") +
	  labs(x = "Order Date",
		   y = "Sales Amount")

#return image
dev.off()
data.frame(data = readBin(file(MyImage, "rb"), what = raw(), n = 1e6));


##################
# LINEAR REGRESSION
MyProphetDF <- FactResellerSales[, c("OrderDate", "SalesAmount")]
colnames(MyProphetDF) <- c("ds", "y")
MyProphetDF$ds <- as.POSIXct(MyProphetDF$ds)
MyProphetDF$ds = as.Date(format(MyProphetDF$ds, "%Y-%m-01"))
library(dplyr)
MyProphetDF <- MyProphetDF %>%
                group_by(ds) %>%
                summarise(y = sum(y))

MyProphetModel <- lm(y ~ ds, MyProphetDF);
#MyProphetFuture <- make_future_dataframe(MyProphetModel, periods = 6, freq = "m");
MyProphetPrediction = data.frame(ds = as.Date('2013-12-01', '%Y-%m-%d'), y = 0)
MyProphetFuture <- rbind(MyProphetDF, MyProphetPrediction);
MyProphetForecast <- predict(MyProphetModel, MyProphetFuture);
MyProphetForecast <- data.frame(MyProphetForecast)
MyProphetForecast <- cbind(MyProphetFuture, MyProphetForecast)
MyProphetForecast
colnames(MyProphetForecast) <- c("ds", "y", "yhat")
tail(MyProphetForecast, 7)

#MyImage = tempfile()
#jpeg(filename = MyImage, width = 800, height = 800)

#plot
library(ggplot2)
library(scales)
ggplot(MyProphetForecast,
           aes(x = ds,
               y = y,
               color = 1)) +
      geom_line() +
      geom_point() +
      theme(text = element_text(size = 18)) +
      scale_y_continuous(limits = c(0, 5000000), labels = comma) +
      geom_line(y = MyProphetForecast$yhat, color = 2) +
      geom_point(y = MyProphetForecast$yhat, color = 2) +
      theme(legend.position = "none") +
      labs(x = "Order Date",
           y = "Sales Amount")

#return image
#dev.off()
#data.frame(data = readBin(file(MyImage, "rb"), what = raw(), n = 1e6));
