# Language basics
# (c) Markus Ehrenmüller-Jensen


### COMMENTS
# A comment-line starts with a hash-sign

# no multi-line comments are available



### CALCLATIONS
1 + 2
2 * 3
2^16



### ASSIGNEMENTS
a =  'SQL2R'
a <- 'SQL2R'
'SQL2R' -> a
assign('a', 'SQL2R')
a
# variable name
assign(a, 'another content')
a
SQL2R

### DYNAMICALLY TYPED
a <- 1
a
(a <- 1)
(a <- c(1, 2))

### STRONG TYPED
(a <- 1)
(b <- 'xyz')
a + b

### STRONG DYNAMICALLY TYPED
a <- 1
b <- 2
a + b

### CASE SENSIVITY
A <- 'sql2r'
A
a


### USEFUL FUNCTIONS
#q()           # quits session
help()         # help is mandatory for all functions/packages
license()
contributors()
citation()
options()
#source()
#sink()

### DESCRIPTIVE STATISTICS
mean(c(1, 2, 3, 5))
median(c(1, 2, 3, 5))
sd(c(1, 2, 3, 5))

#end of file