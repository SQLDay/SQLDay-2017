USE [TSQLTDemo];
GO



CREATE FUNCTION [dbo].[CalcSalesTaxForSale] (
    @state CHAR(2),
    @amount NUMERIC(12, 3)
    )
RETURNS NUMERIC(12, 3)
AS
BEGIN
    DECLARE @tax NUMERIC(12, 3);

    SELECT  @tax = @amount * CASE WHEN @state = 'AK' THEN 0.05
                                  WHEN @state = 'AL' THEN 0.02
                                  WHEN @state = 'AR' THEN 0.04
                                  WHEN @state = 'WA' THEN 0.04
                             END;
    RETURN @tax; 
END;
GO






CREATE PROCEDURE dbo.GetOrderDetailsWithTaxRates
  @orderId INT
AS
BEGIN
	SELECT od.OrderId, od.ProductId, od.Amount * od.UnitPrice AS TotalPrice, dbo.CalcSalesTaxForSale(od.ShippingState, od.Amount * od.UnitPrice) AS Tax
	FROM [dbo].[OrderDetail] od
	WHERE od.OrderId = @orderId
END;
GO





EXEC tsqlt.NewTestClass 'GetOrderDetailsWithTaxRates';
GO





CREATE PROCEDURE [GetOrderDetailsWithTaxRates].[test GetOrderDetailsWithTaxRates uses CalcSalesTaxForSale]
AS
BEGIN
	--Arrange

	EXEC tSQLt.FakeTable @TableName = 'dbo.OrderDetail';
	EXEC tSQLt.FakeFunction 
         @FunctionName = 'dbo.CalcSalesTaxForSale', 
         @FakeFunctionName = 'GetOrderDetailsWithTaxRates.[200 fixed tax]';

    INSERT INTO dbo.OrderDetail(OrderId,ProductId,Amount, UnitPrice, ShippingState)
    VALUES(1, 1, 10, 100,'PA');

	CREATE TABLE #Expected (
		OrderId int,
		ProductId int,
		TotalPrice money,
		Tax numeric(12,3)
	)

	INSERT INTO #Expected
    VALUES(1,1,1000, 200)

	SELECT *
	INTO #Actual
	FROM #Expected AS e
	WHERE 1 = 0

  --Act
    
	INSERT INTO #Actual
	EXEC dbo.GetOrderDetailsWithTaxRates @orderId = 1

  --Assert

    EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
END;
GO





CREATE FUNCTION [GetOrderDetailsWithTaxRates].[200 fixed tax] (
    @state CHAR(2),
    @amount NUMERIC(12, 3)
    )
RETURNS NUMERIC(12, 3)
AS
BEGIN
    DECLARE @tax NUMERIC(12, 3) = 200;
    RETURN @tax; 
END;
GO





EXEC tSQLt.Run 'GetOrderDetailsWithTaxRates'

