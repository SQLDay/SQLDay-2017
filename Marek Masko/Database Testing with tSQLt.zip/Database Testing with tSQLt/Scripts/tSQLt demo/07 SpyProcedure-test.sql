USE [TSQLTDemo];
GO

CREATE PROCEDURE dbo.SalesReport
   @customerId CHAR(3),
   @showHistory BIT = 0
AS
BEGIN
   IF(@showHistory = 0)
     EXEC dbo.CurrentReport @customerId;
   ELSE
     EXEC dbo.HistoricalReport @customerId;
   RETURN 0;
END;
GO





CREATE PROCEDURE dbo.HistoricalReport
   @customerId int
AS
BEGIN
   RETURN 0;
END;
GO





CREATE PROCEDURE dbo.CurrentReport
   @customerId CHAR(3)
AS
BEGIN
   RETURN 0;
END;
GO






EXEC tsqlt.NewTestClass 'SalesReport';
GO






CREATE PROCEDURE SalesReport.[test that SalesReport calls HistoricalReport when @showHistory = 1]
AS
BEGIN
	--Assemble
    EXEC tSQLt.SpyProcedure 'dbo.HistoricalReport';
    EXEC tSQLt.SpyProcedure 'dbo.CurrentReport';

	--Act
    EXEC dbo.SalesReport 1, @showHistory = 1;

    SELECT customerId
      INTO #Actual
      FROM dbo.HistoricalReport_SpyProcedureLog;

	--Assert HistoricalReport got called with right parameter
    SELECT customerId
      INTO #Expected
      FROM (SELECT 1) ex(customerId);

    EXEC tSQLt.assertEqualsTable '#Actual', '#Expected';
    
	--Assert CurrentReport did not get called
    IF EXISTS (SELECT 1 FROM dbo.CurrentReport_SpyProcedureLog)
       EXEC tSQLt.Fail 'SalesReport should not have called CurrentReport when @showHistory = 1';
END;
GO






CREATE PROCEDURE SalesReport.[test mocked subprocedure result set when @showHistory = 0]
AS
BEGIN
	--Assemble
    EXEC tSQLt.SpyProcedure 'dbo.HistoricalReport', 'SELECT 100';
    EXEC tSQLt.SpyProcedure 'dbo.CurrentReport', 'SELECT 200';

	CREATE TABLE #Expected (
		[value] int
	);

	INSERT INTO #Expected ([value])
	VALUES (200)

	SELECT *
	INTO #Actual
	FROM #Expected e
	WHERE 1=0

	--Act
	INSERT INTO #Actual
    EXEC dbo.SalesReport 1, @showHistory = 0;

	--Assert
 
    EXEC tSQLt.assertEqualsTable '#Actual', '#Expected';

END;
GO






EXEC tSQLt.Run 'SalesReport'




--Go back to Slides :)