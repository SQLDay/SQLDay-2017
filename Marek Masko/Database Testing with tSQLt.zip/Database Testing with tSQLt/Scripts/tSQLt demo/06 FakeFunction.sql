USE [TSQLTDemo];
GO


CREATE FUNCTION dbo.Fun1 ()
RETURNS varchar(max)
AS
BEGIN
    RETURN 'Polish SQL Server User Group';
END;
GO

CREATE FUNCTION dbo.Fun2 ()
RETURNS varchar(max)
AS
BEGIN
    RETURN 'Data Community';
END;
GO


BEGIN TRAN





SELECT dbo.Fun1();





EXEC tSQLt.FakeFunction 'dbo.Fun1', 'dbo.Fun2';





SELECT dbo.Fun1();





ROLLBACK





--Cleanup
DROP FUNCTION dbo.Fun1;
GO

DROP FUNCTION dbo.Fun2;
GO

