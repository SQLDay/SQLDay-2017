USE [TSQLTDemo];
GO





CREATE PROCEDURE dbo.Proc1(@param int)
AS
	SELECT 'Polish SQL Server User Group (param=' + CAST(@param AS varchar(max)) +')' AS Result
GO





BEGIN TRAN





EXECUTE dbo.Proc1 0;





EXEC tSQLt.SpyProcedure 'dbo.Proc1', 'SELECT ''Data Community'' AS Result'





EXECUTE dbo.Proc1 1;





SELECT * FROM dbo.Proc1_SpyProcedureLog;





EXECUTE dbo.Proc1 2017;





SELECT * FROM dbo.Proc1_SpyProcedureLog;





ROLLBACK

--Cleanup
DROP PROCEDURE dbo.Proc1;
GO
