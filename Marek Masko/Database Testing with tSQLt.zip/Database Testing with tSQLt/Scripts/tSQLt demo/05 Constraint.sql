USE [TSQLTDemo];
GO

EXEC tsqlt.NewTestClass 'table_OrderDetail';
GO

CREATE PROCEDURE [table_OrderDetail].[test PK constraint]
AS

	--Arrange
	EXEC tSQLt.FakeTable 'dbo.OrderDetail';
	EXEC tSQLt.ApplyConstraint 'dbo.OrderDetail', 'PK_OrderDetail';

	INSERT INTO [dbo].[OrderDetail] (OrderId, ProductId, UnitPrice, Amount)
	VALUES (1, 111, 10.50, 1);

	EXEC tSQLt.ExpectException @ExpectedMessagePattern = 'Violation of PRIMARY KEY constraint ''PK_OrderDetail''%', @ExpectedSeverity = 14, @ExpectedState = 1;
	
	
	--Act
	INSERT INTO [dbo].[OrderDetail] (OrderId, ProductId, UnitPrice, Amount)
	VALUES (1, 111, 10.50, 1);

	--Assert
GO






EXEC tSQLt.Run 'table_OrderDetail'
GO
