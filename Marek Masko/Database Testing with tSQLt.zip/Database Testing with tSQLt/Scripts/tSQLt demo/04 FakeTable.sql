USE [TSQLTDemo];
GO





INSERT INTO dbo.Product (Name, UnitPrice) VALUES ('SQLDay2017', 1000.00);





--#1
BEGIN TRAN





SELECT * FROM dbo.Product;
EXEC sp_help 'dbo.Product';





EXEC tSQLt.FakeTable 'dbo.Product'





SELECT * FROM dbo.Product;
EXEC sp_help 'dbo.Product';





ROLLBACK

SELECT * FROM dbo.Product;
EXEC sp_help 'dbo.Product';






--#2
BEGIN TRAN





EXEC tSQLt.FakeTable 
	@TableName = 'dbo.Product'
  , @Identity =  1
  , @ComputedColumns = 1
  , @Defaults = 1;





SELECT * FROM dbo.Product;
EXEC sp_help 'dbo.Product';





ROLLBACK

SELECT * FROM dbo.Product;
EXEC sp_help 'dbo.Product';
