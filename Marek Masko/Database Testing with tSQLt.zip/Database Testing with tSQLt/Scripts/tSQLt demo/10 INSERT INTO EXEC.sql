USE [TSQLTDemo];
GO



--DROP PROCEDURE dbo.usp_GetOrdersWithDetailsWrapper
CREATE PROCEDURE dbo.usp_GetOrdersWithDetailsWrapper
AS
	CREATE TABLE #Temp (
		OrderId   int      NOT NULL,
		OrderDate datetime NOT NULL,
		ProductId int      NOT NULL,
		UnitPrice money	   NOT NULL,
		Amount    smallint NOT NULL
	);

	INSERT INTO #Temp
	EXEC dbo.usp_GetOrdersWithDetails;

	SELECT OrderId, OrderDate, ProductId, UnitPrice, Amount FROM #Temp;
GO





EXEC tsqlt.NewTestClass 'usp_GetOrdersWithDetailsWrapper';
GO






CREATE PROCEDURE [usp_GetOrdersWithDetailsWrapper].[test procedure results]
AS

	--Arrange
	EXEC tSQLt.FakeTable 'dbo.Order';
	EXEC tSQLt.FakeTable 'dbo.OrderDetail';

	INSERT INTO [dbo].[Order] (OrderId, OrderDate) 
	VALUES (1, '2017-02-15 17:45'),
		   (2, '2017-02-15 18:00');
	
	INSERT INTO [dbo].[OrderDetail] (OrderId, ProductId, UnitPrice, Amount)
	VALUES (1, 111, 10.50, 1),
		   (1, 222, 13.50, 2),
		   (2, 333, 99.99, 3),
		   (2, 444, 15.50, 4);

	CREATE TABLE #Expected ( 
		OrderId   int,
		OrderDate datetime,
		ProductId int,
		UnitPrice money,
		Amount    smallint,
	);

	INSERT #Expected
	VALUES
	( 1, '2017-02-15 17:45', 111, 10.50, 1 ),
	( 1, '2017-02-15 17:45', 222, 13.50, 2 ),
	( 2, '2017-02-15 18:00', 333, 99.99, 3 ),
	( 2, '2017-02-15 18:00', 444, 15.50, 4 );

	SELECT *
	INTO #Actual
	FROM #Expected AS e
	WHERE 1 = 0

	--Act

	INSERT INTO #Actual
	EXEC dbo.usp_GetOrdersWithDetailsWrapper;

	--Assert

	EXEC tSQLt.AssertEqualsTable '#Expected', '#Actual';
GO







EXEC tSQLt.Run 'usp_GetOrdersWithDetailsWrapper';


/*
Deploy CLR solution
*/





EXEC tsqlt.NewTestClass 'usp_GetOrdersWithDetailsWrapper';
GO






CREATE PROCEDURE [usp_GetOrdersWithDetailsWrapper].[test procedure results]
AS

	--Arrange
	EXEC tSQLt.FakeTable 'dbo.Order';
	EXEC tSQLt.FakeTable 'dbo.OrderDetail';

	INSERT INTO [dbo].[Order] (OrderId, OrderDate) 
	VALUES (1, '2017-02-15 17:45'),
		   (2, '2017-02-15 18:00');
	
	INSERT INTO [dbo].[OrderDetail] (OrderId, ProductId, UnitPrice, Amount)
	VALUES (1, 111, 10.50, 1),
		   (1, 222, 13.50, 2),
		   (2, 333, 99.99, 3),
		   (2, 444, 15.50, 4);

	CREATE TABLE #Expected ( 
		OrderId   int,
		OrderDate datetime,
		ProductId int,
		UnitPrice money,
		Amount    smallint,
	);

	INSERT #Expected
	VALUES
	( 1, '2017-02-15 17:45', 111, 10.50, 1 ),
	( 1, '2017-02-15 17:45', 222, 13.50, 2 ),
	( 2, '2017-02-15 18:00', 333, 99.99, 3 ),
	( 2, '2017-02-15 18:00', 444, 15.50, 4 );

	--Act

	EXEC tSQLt.usp_InsertExec 'dbo.usp_GetOrdersWithDetailsWrapper', 'dbo.Actual';

	--Assert

	EXEC tSQLt.AssertEqualsTable '#Expected', 'dbo.Actual';
GO


EXEC tSQLt.Run 'usp_GetOrdersWithDetailsWrapper';

--SELECT * FROM dbo.Actual