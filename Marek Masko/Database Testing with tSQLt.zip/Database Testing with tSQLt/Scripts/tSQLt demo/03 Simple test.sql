USE [TSQLTDemo];
GO





-- Let's create new test class
EXEC tSQLt.NewTestClass 'MySimpleTests';
GO





-- Create first simple test
CREATE PROCEDURE [MySimpleTests].[test simple numeric]
AS
	
	--Arrange
    DECLARE @e int = 1;
	DECLARE @a int = 2;

	--Act

	--Assert
	EXEC tSQLt.AssertEquals
	    @Expected = @e, 
		@Actual = @a,
		@Message = 'Values are not equal!'

GO





-- Create second simple test
CREATE PROCEDURE [MySimpleTests].[test simple string]
AS
	
	--Arrange
    DECLARE @e varchar(5) = '1';
	DECLARE @a varchar(5) = '2';

	--Act

	--Assert
	EXEC tSQLt.AssertEqualsString
	    @Expected = @e, 
		@Actual = @a,
		@Message = 'Values are not equal!'

GO





-------------------------------------------------------------------------------
EXEC tSQLt.Run '[MySimpleTests].[test simple numeric]'
EXEC tSQLt.Run '[MySimpleTests].[test simple string]'





-- Lets fix it

EXEC tsqlt.NewTestClass 'MySimpleTests';
GO

CREATE PROCEDURE [MySimpleTests].[test simple numeric]
AS
	
	--Arrange
    DECLARE @e int = 2; --1;
	DECLARE @a int = 2;

	--Act

	--Assert
	EXEC tSQLt.AssertEquals
	    @Expected = @e, 
		@Actual = @a,
		@Message = 'Values are not equal!'

GO






CREATE PROCEDURE [MySimpleTests].[test simple string]
AS
	
	--Arrange
    DECLARE @e varchar(5) = '2'; --'1';
	DECLARE @a varchar(5) = '2';

	--Act

	--Assert
	EXEC tSQLt.AssertEqualsString
	    @Expected = @e, 
		@Actual = @a,
		@Message = 'Values are not equal!'

GO






EXEC tSQLt.Run '[MySimpleTests].[test simple numeric]'
EXEC tSQLt.Run '[MySimpleTests].[test simple string]'






-- Run all tests in specified class
EXEC tSQLt.Run '[MySimpleTests]'






-- Run all tests in all test classes
EXEC tSQLt.RunAll;



--Go back to Slides :)