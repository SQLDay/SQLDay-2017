USE [TSQLTDemo];
GO


-- Product table
 CREATE TABLE [dbo].[Product](
    [ProductId]    [int] IDENTITY(1,1) NOT NULL,
    [Name]         [nvarchar](40)      NOT NULL,
	[UnitPrice]    [money]             NOT NULL,
	[Discontinued] [bit]               NOT NULL,
    CONSTRAINT [PK_Product] PRIMARY KEY CLUSTERED 
    (
	    [productid] ASC
    )
);
GO

ALTER TABLE [dbo].[Product] ADD  CONSTRAINT [DF_Product_UnitPrice]  DEFAULT ((0)) FOR [UnitPrice];
GO

ALTER TABLE [dbo].[Product] ADD  CONSTRAINT [DF_Product_Discontinued]  DEFAULT ((0)) FOR [Discontinued];
GO

ALTER TABLE [dbo].[Product] WITH CHECK ADD  CONSTRAINT [CK_Product_UnitPrice] CHECK ([Unitprice] >= 0);
GO

-- Customer table
CREATE TABLE [dbo].[Customer](
	[CustomerId]   [int] IDENTITY(1,1) NOT NULL,
	[CustomerName] [nvarchar](40)      NOT NULL,
    CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED 
    (
	     [CustomerId] ASC
	)
);
GO

-- Order table
CREATE TABLE [dbo].[Order](
	[OrderId]     [int] IDENTITY(1,1) NOT NULL,
	[CustomerId]  [int] NULL,
	[OrderDate]   [datetime] NOT NULL,
	[ShippedDate] [datetime] NULL,
    CONSTRAINT [PK_Order] PRIMARY KEY CLUSTERED 
    (
		[OrderId] ASC
	)
);
GO

ALTER TABLE [dbo].[Order]  WITH CHECK ADD  CONSTRAINT [FK_Order_Customer] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customer] ([CustomerId]);
GO

-- OrderDetail table
CREATE TABLE [dbo].[OrderDetail](
	[OrderId]       [int]           NOT NULL,
	[ProductId]     [int]           NOT NULL,
	[UnitPrice]     [money]         NOT NULL,
	[Amount]        [smallint]      NOT NULL,
	[Discount]      [numeric](4, 3) NOT NULL,
	[ShippingState] [varchar](3)	NOT NULL,
    CONSTRAINT [PK_OrderDetail] PRIMARY KEY CLUSTERED 
    (
	    [OrderId] ASC,
	    [ProductId] ASC
	)
);
GO

ALTER TABLE [dbo].[OrderDetail] ADD  CONSTRAINT [DF_OrderDetail_UnitPrice]  DEFAULT (0) FOR [UnitPrice];
GO

ALTER TABLE [dbo].[OrderDetail] ADD  CONSTRAINT [DF_OrderDetail_Amount]  DEFAULT (1) FOR [Amount];
GO

ALTER TABLE [dbo].[OrderDetail] ADD  CONSTRAINT [DF_OrderDetail_Discount]  DEFAULT (0) FOR [Discount];
GO

ALTER TABLE [dbo].[OrderDetail]  WITH CHECK ADD  CONSTRAINT [FK_OrderDetail_Order] FOREIGN KEY([OrderId])
REFERENCES [dbo].[Order] ([OrderId]);
GO

ALTER TABLE [dbo].[OrderDetail]  WITH CHECK ADD  CONSTRAINT [FK_OrderDetail_Product] FOREIGN KEY([ProductId])
REFERENCES [dbo].[Product] ([ProductId]);
GO

ALTER TABLE [dbo].[OrderDetail]  WITH CHECK ADD  CONSTRAINT [CK_Discount] CHECK  ([Discount] >= 0 AND [Discount] <= 1);
GO

ALTER TABLE [dbo].[OrderDetail] WITH CHECK ADD  CONSTRAINT [CK_Amount] CHECK  ([Amount] > 0);
GO

ALTER TABLE [dbo].[OrderDetail]  WITH CHECK ADD  CONSTRAINT [CK_UnitPrice] CHECK  ([UnitPrice] >= 0 );
GO