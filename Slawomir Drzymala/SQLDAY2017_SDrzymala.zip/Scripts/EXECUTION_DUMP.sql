-- try to add an execution dump
-- check output in C:\Program Files\Microsoft SQL Server\130\Shared\ErrorDumps
DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] 
	@package_name=N'MASTER_PACKAGE.dtsx'
	, @execution_id=@execution_id OUTPUT
	, @folder_name=N'ETL'
	, @project_name=N'SQLDAY2017_SSIS_DEMO'
	, @use32bitruntime=False
	, @reference_id=3 -- environment load test (SELECT * FROM SSISDB.catalog.environment_references)

SELECT @execution_id

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
	@execution_id,  
	@object_type=50, 
	@parameter_name=N'LOGGING_LEVEL', 
	@parameter_value=1

EXEC [SSISDB].[catalog].[start_execution] 
	@execution_id

go

EXEC SSISDB.catalog.create_execution_dump @execution_id =  60084  












-- alternatively:
--- avaliable parameters:
-- DUMP_EVENT_CODE
-- DUMP_ON_ERROR
-- DUMP_ON_EVENT

DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] 
	@package_name=N'MASTER_PACKAGE.dtsx'
	, @execution_id=@execution_id OUTPUT
	, @folder_name=N'ETL'
	, @project_name=N'SQLDAY2017_SSIS_DEMO'
	, @use32bitruntime=False
	, @reference_id=3 -- environment load test (SELECT * FROM SSISDB.catalog.environment_references)

SELECT @execution_id

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
	@execution_id,  
	@object_type=50, 
	@parameter_name=N'LOGGING_LEVEL', 
	@parameter_value=1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
	@execution_id,  
	@object_type=50, 
	@parameter_name=N'DUMP_ON_ERROR', 
	@parameter_value=1 -- dump on error

EXEC [SSISDB].[catalog].[start_execution] 
	@execution_id

GO















-- alternatively:
--- avaliable parameters:
-- DUMP_EVENT_CODE
-- DUMP_ON_EVENT

DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] 
	@package_name=N'MASTER_PACKAGE.dtsx'
	, @execution_id=@execution_id OUTPUT
	, @folder_name=N'ETL'
	, @project_name=N'SQLDAY2017_SSIS_DEMO'
	, @use32bitruntime=False
	, @reference_id=3 -- environment load test (SELECT * FROM SSISDB.catalog.environment_references)

SELECT @execution_id

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
	@execution_id,  
	@object_type=50, 
	@parameter_name=N'LOGGING_LEVEL', 
	@parameter_value=1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
	@execution_id,  
	@object_type=50, 
	@parameter_name=N'DUMP_ON_EVENT', 
	@parameter_value=1 

declare @event_code nvarchar(50)
set @event_code = '0xC020801C' -- ??
set @event_code = 'OnInformation' --??


EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
	@execution_id,  
	@object_type=50, 
	@parameter_name=N'DUMP_EVENT_CODE', 
	@parameter_value=@event_code


EXEC [SSISDB].[catalog].[start_execution] 
	@execution_id

GO




