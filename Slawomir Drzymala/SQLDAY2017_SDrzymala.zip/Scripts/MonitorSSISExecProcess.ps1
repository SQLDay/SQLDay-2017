﻿
Clear-Host

while($true)
{
$ErrorOccured = $false
try 
{ 
   #Start-Sleep -Milliseconds 10
   $ErrorActionPreference = 'Stop'
   Get-Process ISServerExec > null
}
catch
{
   "Not running"
   $ErrorOccured=$true
}

if(!$ErrorOccured) {"Running"}
}