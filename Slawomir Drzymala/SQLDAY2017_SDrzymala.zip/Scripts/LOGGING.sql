---- 0 - none (x) 60100
---- 1 - basic (x) 60101
---- 2 - performance (x) 60102
---- 3 - verbose (x) 60103
---- 4 - runtime linage (x) 60104

---- execute for all types !

--DECLARE @execution_id BIGINT

--EXEC [SSISDB].[catalog].[create_execution] 
--	@package_name=N'MASTER_PACKAGE.dtsx', 
--	@execution_id=@execution_id OUTPUT, 
--	@folder_name=N'ETL', 
--	@project_name=N'SQLDAY2017_SSIS_DEMO', 
--	@use32bitruntime=False, 
--	@reference_id=4

--EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
--	@execution_id,  
--	@object_type=50, 
--	@parameter_name=N'LOGGING_LEVEL', 
--	@parameter_value=4
--EXEC [SSISDB].[catalog].[start_execution] @execution_id

USE SSISDB;

;WITH cte
AS
(
	SELECT 
		a.execution_id, 
		b.parameter_value AS 'LoggingID',
		CASE b.parameter_value
			WHEN 0 THEN 'none'
			WHEN 1 THEN 'basic'
			WHEN 2 THEN 'performance'
			WHEN 3 THEN 'verbose'
			WHEN 4 THEN 'runtime linage'
		END AS 'LoggingName',		
		DATEDIFF(SECOND, a.start_time, a.end_time) AS Duration,
		(SELECT COUNT(*) FROM [internal].[event_message_context] d WHERE a.execution_id = d.operation_id) AS [event_message_context],
		(SELECT COUNT(*) FROM [internal].[operation_messages] d WHERE a.execution_id = d.operation_id) AS [operation_messages],
		(SELECT COUNT(*) FROM [internal].[event_messages] d WHERE a.execution_id = d.operation_id) AS [event_messages],
		(SELECT COUNT(*) FROM [internal].[execution_parameter_values] d WHERE a.execution_id = d.execution_id) AS [execution_parameter_values],
		(SELECT COUNT(*) FROM [internal].[executable_statistics] d WHERE a.execution_id = d.execution_id) AS [executable_statistics],
		(SELECT COUNT(*) FROM [internal].[execution_component_phases] d WHERE a.execution_id = d.execution_id) AS [execution_component_phases]
	FROM catalog.executions a
	INNER JOIN internal.execution_parameter_values b
	ON b.execution_id = a.execution_id AND b.parameter_name = 'LOGGING_LEVEL'
	WHERE a.execution_id IN (60100, 60101, 60102, 60103, 60104)
)
SELECT cte.execution_id ,
       cte.LoggingID ,
       cte.LoggingName ,
       cte.Duration ,
	   cte.event_message_context+cte.operation_messages+cte.event_messages+cte.execution_parameter_values+cte.executable_statistics+cte.execution_component_phases AS TotalSum,
	   (cte.event_message_context+cte.operation_messages+cte.event_messages+cte.execution_parameter_values+cte.executable_statistics+cte.execution_component_phases) * 365 AS TotalSum_Year,
       cte.event_message_context ,
       cte.operation_messages ,
       cte.event_messages ,
       cte.execution_parameter_values ,
       cte.executable_statistics ,
       cte.execution_component_phases
FROM cte
ORDER BY 11 asc