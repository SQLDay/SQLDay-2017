-- execute project using synchonous/asynchronous method
-- default is asynchronous method

























-- execute project with the asynchonous method
	DECLARE @execution_id BIGINT

	EXEC [SSISDB].[catalog].[create_execution] 
		@package_name=N'MASTER_PACKAGE.dtsx'
		, @execution_id=@execution_id OUTPUT
		, @folder_name=N'ETL'
		, @project_name=N'SQLDAY2017_SSIS_DEMO'
		, @use32bitruntime=False
		, @reference_id=4

	EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
		@execution_id,  
		@object_type=50, 
		@parameter_name=N'LOGGING_LEVEL', 
		@parameter_value=1

	DECLARE @synchronized bit = 0

	EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
	  @execution_id 
	, @object_type=50 
	, @parameter_name=N'SYNCHRONIZED' 
	, @parameter_value=@synchronized

	EXEC [SSISDB].[catalog].[start_execution] 
		@execution_id



























-- execute project with the synchonous method
-- change to 1 and run again
DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] 
	@package_name=N'MASTER_PACKAGE.dtsx'
	, @execution_id=@execution_id OUTPUT
	, @folder_name=N'ETL'
	, @project_name=N'SQLDAY2017_SSIS_DEMO'
	, @use32bitruntime=False
	, @reference_id=4

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
	@execution_id,  
	@object_type=50, 
	@parameter_name=N'LOGGING_LEVEL', 
	@parameter_value=1

DECLARE @synchronized bit = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
	@execution_id 
, @object_type=50 
, @parameter_name=N'SYNCHRONIZED' 
, @parameter_value=@synchronized

EXEC [SSISDB].[catalog].[start_execution] 
	@execution_id




























-- running the package in using synchonous method with DTEXEC
--DTEXEC /ISSERVER "\"\SSISDB\ETL\SQLDAY2017_SSIS_DEMO\MASTER_PACKAGE.dtsx\"" 
--/SERVER "\".\sql2016\"" 
--/ENVREFERENCE 4 
--/Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 
--/Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True 
--/CALLERINFO SQLAGENT 
--/REPORTING E

-- example, synchronous method
DTEXEC /ISSERVER "\"\SSISDB\ETL\SQLDAY2017_SSIS_DEMO\MASTER_PACKAGE.dtsx\"" /SERVER "\".\sql2016\"" /ENVREFERENCE 4 /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E
-- example, asynchronous method
DTEXEC /ISSERVER "\"\SSISDB\ETL\SQLDAY2017_SSIS_DEMO\MASTER_PACKAGE.dtsx\"" /SERVER "\".\sql2016\"" /ENVREFERENCE 4 /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E


































-- using "Start Job as Step" in SQL Server Agent 
-- it overrides the settings
-- and runs in synchornous way