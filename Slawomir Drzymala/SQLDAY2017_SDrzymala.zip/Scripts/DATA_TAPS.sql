-- try to add a data tap
-- show package with a scenario
-- see execution log
-- check error
DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] 
	@package_name=N'MASTER_PACKAGE.dtsx'
	, @execution_id=@execution_id OUTPUT
	, @folder_name=N'ETL'
	, @project_name=N'SQLDAY2017_SSIS_DEMO'
	, @use32bitruntime=False
	, @reference_id=4

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
	@execution_id,  
	@object_type=50, 
	@parameter_name=N'LOGGING_LEVEL', 
	@parameter_value=1

EXEC [catalog].[add_data_tap]   
@execution_id = @execution_id  
, @task_package_path = N'\Package\LOAD DATA\DFT_LOAD_CUSTOMERS'  
, @dataflow_path_id_string     = 'Paths[ODS_GET_DATA_FROM_SOURCE.OLE DB Source Output]'
, @data_filename = 'Customers.csv'

EXEC [catalog].[add_data_tap]   
@execution_id = @execution_id  
, @task_package_path = N'\Package\LOAD DATA\DFT_LOAD_CUSTOMERS'  
, @dataflow_path_id_string     = 'Paths[CS_SPLIT_BY_TYPE.Private]'
, @data_filename = 'PrivateCustomers.csv'

EXEC [SSISDB].[catalog].[start_execution] 
	@execution_id


















-- data taps doesn't work with a master package, you need to execute a package directly
-- check results in C:\Program Files\Microsoft SQL Server\130\DTS\DataDumps\
go

DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] 
	@package_name=N'LOAD_DATA.dtsx'
	, @execution_id=@execution_id OUTPUT
	, @folder_name=N'ETL'
	, @project_name=N'SQLDAY2017_SSIS_DEMO'
	, @use32bitruntime=False
	, @reference_id=4

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
	@execution_id,  
	@object_type=50, 
	@parameter_name=N'LOGGING_LEVEL', 
	@parameter_value=1

EXEC [catalog].[add_data_tap]   
@execution_id = @execution_id  
, @task_package_path = N'\Package\LOAD DATA\DFT_LOAD_CUSTOMERS'  
, @dataflow_path_id_string     = 'Paths[ODS_GET_DATA_FROM_SOURCE.OLE DB Source Output]'
, @data_filename = 'Customers.csv'

EXEC [catalog].[add_data_tap]   
@execution_id = @execution_id  
, @task_package_path = N'\Package\LOAD DATA\DFT_LOAD_CUSTOMERS'  
, @dataflow_path_id_string     = 'Paths[CS_SPLIT_BY_TYPE.Private]'
, @data_filename = 'PrivateCustomers.csv'

EXEC [SSISDB].[catalog].[start_execution] 
	@execution_id








