﻿Clear-Host

$ServiceName = 'MsDtsServer130'

while ($true)
{
    Start-Sleep -Milliseconds 500
    $arrService = Get-Service -Name $ServiceName
    $arrService.status
}

