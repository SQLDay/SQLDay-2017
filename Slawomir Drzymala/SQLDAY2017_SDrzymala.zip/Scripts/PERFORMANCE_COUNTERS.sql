

-- execute project with the asynchonous method
	DECLARE @execution_id BIGINT

	EXEC [SSISDB].[catalog].[create_execution] 
		@package_name=N'MASTER_PACKAGE.dtsx'
		, @execution_id=@execution_id OUTPUT
		, @folder_name=N'ETL'
		, @project_name=N'SQLDAY2017_SSIS_DEMO'
		, @use32bitruntime=False
		, @reference_id=3 -- load test environment

	SELECT @execution_id

	EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
		@execution_id,  
		@object_type=50, 
		@parameter_name=N'LOGGING_LEVEL', 
		@parameter_value=1

	EXEC [SSISDB].[catalog].[start_execution] 
		@execution_id













SELECT execution_id, counter_name, counter_value, GETDATE() AS execution_time 
FROM catalog.dm_execution_performance_counters(null)















		
IF OBJECT_ID('tempdb..#output') IS NOT NULL DROP TABLE #output

CREATE TABLE #output
(
	[execution_id] [BIGINT] NULL,
	[counter_name] [sysname] NOT NULL,
	[counter_value] [BIGINT] NULL,
	[execution_time] [DATETIME] NOT NULL
) ON [PRIMARY]

WHILE (1=1)
BEGIN 
	INSERT INTO #output 
	(   
		execution_id,
	    counter_name,
	    counter_value,
		execution_time
	)
	SELECT execution_id, counter_name, counter_value, GETDATE() AS execution_time 
	FROM catalog.dm_execution_performance_counters(null)

	WAITFOR DELAY '00:00:01'

END  



SELECT * 
FROM #output






