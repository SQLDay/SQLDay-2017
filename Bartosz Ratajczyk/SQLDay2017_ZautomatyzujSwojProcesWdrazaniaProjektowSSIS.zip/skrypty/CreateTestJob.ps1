#http://microsoft-ssis.blogspot.com/2016/10/using-powershell-to-create-sql-agent.html

[CmdletBinding()]
Param(
    # SsisServer is required
    [Parameter(Mandatory=$True,Position=1)]
    [string]$SsisServer,
     
    # EnvironmentFolderName is required 
    [Parameter(Mandatory=$True,Position=2)]
    [string]$EnvironmentFolderName,
     
    # Project name is required
    [Parameter(Mandatory=$True,Position=3)]
    [string]$ProjectName,

    # Job name is required
    [Parameter(Mandatory=$True,Position=4)]
    [string]$JobName,

    # (Master) Package name is required
    [Parameter(Mandatory=$True,Position=5)]
    [string]$MasterPackage
)
 
Clear-Host
Write-Host "========================================================================================="
Write-Host "==                                 Used parameters                                     =="
Write-Host "========================================================================================="
Write-Host "SSIS Server            : " $SsisServer
Write-Host "EnvironmentFolderName  : " $EnvironmentFolderName
Write-Host "ProjectName            : " $ProjectName
Write-Host "Job name               : " $JobName
Write-Host "MasterPackage          : " $MasterPackage
Write-Host "========================================================================================="
Write-Host ""

$SQLJobExists = $false 
 
# Reference SMO assembly and connect to the SQL Sever Instance 
# Check the number in the path which is different for each version
Add-Type -Path 'C:\Program Files\Microsoft SQL Server\120\SDK\Assemblies\Microsoft.SqlServer.Smo.dll'
$SQLSvr = New-Object -TypeName  Microsoft.SQLServer.Management.Smo.Server($SsisServer) 
 
# Check if job already exists. Then fail, rename or drop
$SQLJob = $SQLSvr.JobServer.Jobs[$JobName]
if ($SQLJob)
{
  # Use one of these 3 options to handle existing jobs
 
  # Fail:
  #Throw [System.Exception] "Job with name '$JobName' already exists."
 
  # Rename:
  #Write-Host "Job with name '$JobName' found, renaming and disabling it"
  #$SQLJob.Rename($SQLJob.Name +"_OLD_" + (Get-Date -f MM-dd-yyyy_HH_mm_ss))
  #$SQLJob.IsEnabled = $false
  #$SQLJob.Alter()
 
  # Drop:
  #Write-Host "Job with name $JobName found, removing it"
  #$SQLJob.Drop()
  $SQLJobExists = $true
}
else
{ 
    #Create new (empty) job 
    $SQLJob = New-Object -TypeName Microsoft.SqlServer.Management.SMO.Agent.Job -argumentlist $SQLSvr.JobServer, $JobName
    $SQLJob.OwnerLoginName = "sa"
    $SQLJob.Create() 
    Write-Host "Job '$JobName' created"
}
 
# Command of jobstep
# This string is copied from T-SQL, by scripting a job(step) in SSMS
# Then replace the hardcode strings with [NAME] to replace them with variables
$Command = @'
/ISSERVER "\"\SSISDB\[FOLDER]\[PROJECT]\[PACKAGE]\"" /SERVER "\"[INSTANCE]\"" /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E
'@
$Command = $Command.Replace("[FOLDER]", $EnvironmentFolderName)
$Command = $Command.Replace("[PROJECT]", $ProjectName)
$Command = $Command.Replace("[PACKAGE]", $MasterPackage)
$Command = $Command.Replace("[INSTANCE]", $SsisServer)
 
 
# Create new SSIS job step with command from previous block 
$SQLJobStep = $SQLJob.JobSteps["$ProjectName - $MasterPackage"]

if(!$SQLJobStep)
{
    $SQLJobStep = New-Object -TypeName Microsoft.SqlServer.Management.SMO.Agent.JobStep -argumentlist $SQLJob, "$ProjectName - $MasterPackage"
    $SQLJobStep.OnSuccessAction = [Microsoft.SqlServer.Management.Smo.Agent.StepCompletionAction]::QuitWithSuccess
    $SQLJobStep.OnFailAction = [Microsoft.SqlServer.Management.Smo.Agent.StepCompletionAction]::QuitWithFailure
    $SQLJobStep.SubSystem = "SSIS"
    $SQLJobStep.DatabaseName = $SsisServer
    #$SQLJobStep.ProxyName = 'SSIS_Proxy'
    $SQLJobStep.Command = $Command
    $SQLJobStep.Create() 
    Write-Host "Jobstep $SQLJobStep created"
}
else
{
    Write-Host "Jobstep already exists. Skipping step"
}
 
 
# Apply to target server which can only be done after the job is created
if($SQLJobExists -eq $false)
{
    $SQLJob.ApplyToTargetServer("(local)")
    $SQLJob.Alter()
}
Write-Host "Job '$JobName' saved"
$SQLJob.Start("$ProjectName - $MasterPackage")
Write-Host "Job '$JobName' started"
Write-Host '. == 4s'
do
{
    Write-Host '.' -NoNewline
    #Write-Host ". $($SQLJob.CurrentRunStatus)"
    $SQLJob.Refresh()
    Start-Sleep 4
} while ($SQLJob.CurrentRunStatus -eq 'Executing')


Write-Host ""
Write-Host "LastRunOutcome: $($SQLJob.LastRunOutcome)"