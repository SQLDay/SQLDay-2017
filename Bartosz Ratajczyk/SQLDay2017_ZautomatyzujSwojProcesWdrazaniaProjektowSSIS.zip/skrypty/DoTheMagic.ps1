[CmdletBinding()]
Param(
    # SsisServer is required
    [Parameter(Mandatory=$True,Position=1)]
    [string]$SsisServer,
     
    # EnvironmentFolderName is required 
    [Parameter(Mandatory=$True,Position=2)]
    [string]$EnvironmentFolderName,
     
    # EnvironmentName is required
    [Parameter(Mandatory=$True,Position=3)]
    [string]$EnvironmentName,
     
    # Project name is required
    [Parameter(Mandatory=$True,Position=4)]
    [string]$ProjectName,

    # Filepath name is required
    [Parameter(Mandatory=$True,Position=5)]
    [string]$Filepath,

    # Job name is required
    [Parameter(Mandatory=$True,Position=6)]
    [string]$JobName,

    # MasterPackage name is required
    [Parameter(Mandatory=$True,Position=7)]
    [string]$MasterPackage
)

$environmentFile = $Filepath + '\Environment-' + $EnvironmentName + '.csv'
$configFile = $Filepath + '\Environment-' + $EnvironmentName + '-Configuration.csv'

msbuild C:\TFS\SSIS\DEV\SSIS_SQLDay2017\Build.proj
msbuild C:\TFS\SSIS\DEV\SSIS_SQLDay2017\Deploy.proj
.\CreateEnvironment.ps1 -SsisServer $SsisServer -EnvironmentFolderName $EnvironmentFolderName -EnvironmentName $EnvironmentName -FilepathCsv $environmentFile
.\ReferenceEnvironment.ps1 -SsisServer $SsisServer -EnvironmentFolderName $EnvironmentFolderName -EnvironmentName $EnvironmentName -ProjectName $ProjectName
.\ConfigureProject.ps1 -SsisServer $SsisServer -EnvironmentFolderName $EnvironmentFolderName -EnvironmentName $EnvironmentName -FilepathCsv $configFile -ProjectName $ProjectName
.\ValidateProject -SsisServer $SsisServer -EnvironmentFolderName $EnvironmentFolderName -EnvironmentName $EnvironmentName -ProjectName $ProjectName
.\CreateTestJob -SsisServer $SsisServer -EnvironmentFolderName $EnvironmentFolderName -ProjectName $ProjectName -JobName $JobName -MasterPackage $MasterPackage