[CmdletBinding()]
Param(
    # SsisServer is required
    [Parameter(Mandatory=$True,Position=1)]
    [string]$SsisServer = '.',
     
    # EnvironmentFolderName is required 
    [Parameter(Mandatory=$True,Position=2)]
    [string]$EnvironmentFolderName = 'DWH_ETL',
     
    # EnvironmentName is required
    [Parameter(Mandatory=$True,Position=3)]
    [string]$EnvironmentName = 'DEV',
     
    # FilepathCsv is required
    [Parameter(Mandatory=$True,Position=4)]
    [string]$FilepathCsv,

    # Project name is required
    [Parameter(Mandatory=$True,Position=5)]
    [string]$ProjectName = 'SSIS_SQLDay2017'
)

# Load the Integration Services Assembly
Write-Host "Connecting to SSIS server $SsisServer "
$SsisNamespace = "Microsoft.SqlServer.Management.IntegrationServices"
[System.Reflection.Assembly]::LoadWithPartialName($SsisNamespace) | Out-Null;
 
# Create a connection to the server
$SqlConnectionstring = "Data Source=" + $SsisServer + ";Initial Catalog=master;Integrated Security=SSPI;"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection $SqlConnectionstring
 
# Create the Integration Services object
$IntegrationServices = New-Object $SsisNamespace".IntegrationServices" $SqlConnection
 
# Check if connection succeeded
if (-not $IntegrationServices)
{
  Throw  [System.Exception] "Failed to connect to SSIS server $SsisServer "
}
else
{
   Write-Host "Connected to SSIS server" $SsisServer
}
 
$Catalog = $IntegrationServices.Catalogs["SSISDB"]
 
# Check if the SSISDB Catalog exists
if (-not $Catalog)
{
    # Catalog doesn't exists. The user should create it manually.
    # It is possible to create it, but that shouldn't be part of
    # deployment of packages or environments.
    Throw  [System.Exception] "SSISDB catalog doesn't exist. Create it manually!"
}
else
{
    Write-Host "Catalog SSISDB found"
}
 
$Folder = $Catalog.Folders[$EnvironmentFolderName]
 
# Check if folder already exists
if (-not $Folder)
{
    # Folder doesn't exist
    Write-Host "Folder" $EnvironmentFolderName " not found"
}
else
{
    Write-Host "Folder" $EnvironmentFolderName "found"
}
 
$Environment = $Catalog.Folders[$EnvironmentFolderName].Environments[$EnvironmentName]

$project = $Folder.Projects[$ProjectName]

if($project.References.Contains($EnvironmentName, $Folder.Name))
{
     Write-Host "Reference for environment $EnvironmentName already exists"
}

# Check if configuration file exists
if (-Not (Test-Path $FilepathCsv))
{
    Throw  [System.IO.FileNotFoundException] "CSV file $FilepathCsv doesn't exist!"
}
else
{
    $FileNameCsv = split-path $FilepathCsv -leaf
    Write-Host "CSV file" $FileNameCsv "found"
}

Import-CSV $FilepathCsv -Header Source,ReferenceType,ParameterName,ParameterValue -Delimiter ';' | Foreach-Object {
    
    # package parameters
    if($_.Source.EndsWith('.dtsx'))
    {
        $ssisPackage = $project.Packages.Item($_.Source)

        if($_.ReferenceType -eq 'R')
        {
            Write-Host "Setting environment variable reference for parameter" $_.ParameterName "on package" $_.Source
            $ssisPackage.Parameters[$_.ParameterName].Set('Referenced', $_.ParameterValue)
        }

        if($_.ReferenceType -eq 'V')
        {
            Write-Host "Setting value for parameter" $_.ParameterName "on package" $_.Source
            $ssisPackage.Parameters[$_.ParameterName].Set('Literal', $_.ParameterValue)
        }

        $ssisPackage.Alter()
    }

    # project parameters
    if($_.Source -eq 'Project')
    {
        if($_.ReferenceType -eq 'R')
        {
            Write-Host "Setting environment variable reference on project parameter " $_.ParameterName
            $project.Parameters[$_.ParameterName].Set('Referenced', $_.ParameterValue)
        }

        if($_.ReferenceType -eq 'V')
        {
            Write-Host "Setting value on project parameter " $_.ParameterName
            $project.Parameters[$_.ParameterName].Set('Literal', $_.ParameterValue)
        }

        $project.Alter()   
    }

    # connection managers
    if($_.Source.StartsWith('CM.'))
    {
        $element = $_.Source + '.' + $_.ParameterName
        if($_.ReferenceType -eq 'R')
        {
            Write-Host "Setting environment variable reference on connection manager" $_.Source "parameter " $_.ParameterName
            $project.Parameters[$element].Set('Referenced', $_.ParameterValue)
        }

        if($_.ReferenceType -eq 'V')
        {
            Write-Host "Setting value on connection manager" $_.Source "parameter " $_.ParameterName
            $project.Parameters[$element].Set('Literal', $_.ParameterValue)
        }

        $project.Alter() 
    }

}