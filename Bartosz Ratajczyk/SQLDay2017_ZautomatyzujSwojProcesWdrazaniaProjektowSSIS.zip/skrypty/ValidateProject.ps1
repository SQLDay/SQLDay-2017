[CmdletBinding()]
Param(
    # SsisServer is required
    [Parameter(Mandatory=$True,Position=1)]
    [string]$SsisServer,
     
    # EnvironmentFolderName is required 
    [Parameter(Mandatory=$True,Position=2)]
    [string]$EnvironmentFolderName,
     
    # EnvironmentName is required
    [Parameter(Mandatory=$True,Position=3)]
    [string]$EnvironmentName,
     
    # Project name is required
    [Parameter(Mandatory=$True,Position=4)]
    [string]$ProjectName
)

function Get-ValidationStatus($validation)
{
    do
    {
        Write-Host '.' -NoNewline
        Start-Sleep 5
        $validation.Refresh()
    } while ($validation.Completed -eq $false)

    return $validation.Status
}

function Get-ValidationSummary($validation)
{
    [System.Int32] $errors = 0;
    [System.Int32] $warnings = 0;
    [System.Int32] $taskFails = 0;

    #$validation.Messages | Out-GridView

    $errorList = New-Object System.Collections.ArrayList

    foreach($message in $validation.Messages)
    {
        
        #110 == Warning, 120 == Error, 130 == TaskFailed

        if($message.MessageType -eq 110)
        {
            $warnings++
        }

        if($message.MessageType -eq 120)
        {
            $errors++
            $errorList.Add($message.Message)
        }

        if($message.MessageType -eq 130)
        {
            $taskFails++
        }
    }

    Write-Host "Validation summary"
    Write-Host "    Status:       $validationStatus"
    Write-Host "    Errors:       $errors"
    Write-Host "    Warnings:     $warnings"
    Write-Host "    TaskFails:    $taskFails"

    if(-not($suppressValidationErrors -eq $true) -and $errorList.Count -gt 0)
    {
        Write-Host ""
        Write-Host "Errors:"
        foreach($error in $errorList)
        {
            Write-Host "   $error"
        }
    }
}

# sprawdzenie poprawności 
function Invoke-SSISProjectValidation($project)
{

    Write-Host "Starting project validation..."
    if($EnvironmentName.Length -gt 0)
    {
        $referencesFound = $False

        Write-Host "  Validation using selected environment ($EnvironmentName), checking references ... " -NoNewline
        $environmentReferences = $project.References

        foreach($reference in $environmentReferences)
        {
            if(($reference.Name -eq $EnvironmentName) -and (($reference.EnvironmentFolderName -eq '.') -or ($reference.EnvironmentFolderName -eq $EnvironmentFolderName)))
            {
                $referencesFound = $True
                Write-Host "OK"
                $projectValidationProcess = $project.Validate($false, [Microsoft.SqlServer.Management.IntegrationServices.ProjectInfo+ReferenceUsage]::SpecifyReference, $reference)
            }
        }

        If($referencesFound -eq $false)
        {
            Write-Warning "Environment $EnvironmentName not found"
            $projectValidationProcess = -1
        }

    }
    else
    {
        Write-Host "  Validate using all environments"
        $projectValidationProcess = $project.Validate($false, [Microsoft.SqlServer.Management.IntegrationServices.ProjectInfo+ReferenceUsage]::UseAllReferences, $null)
    }

    if($projectValidationProcess -gt 0)
    {
        Write-Host "     validation process id: $projectValidationProcess"

        $validation = $project.Parent.Parent.Validations[$projectValidationProcess]
        $validationStatus = Get-ValidationStatus($validation)

        Write-Host "Validation end"

        Get-ValidationSummary $validation
    }
    else
    {
        Write-Warning "Validation process did not start"
    }

    return $validationStatus

}

# ===================================================

# Load the Integration Services Assembly
Write-Host "Connecting to SSIS server $SsisServer "
$SsisNamespace = "Microsoft.SqlServer.Management.IntegrationServices"
[System.Reflection.Assembly]::LoadWithPartialName($SsisNamespace) | Out-Null;
 
# Create a connection to the server
$SqlConnectionstring = "Data Source=" + $SsisServer + ";Initial Catalog=master;Integrated Security=SSPI;"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection $SqlConnectionstring
 
# Create the Integration Services object
$IntegrationServices = New-Object $SsisNamespace".IntegrationServices" $SqlConnection
 
# Check if connection succeeded
if (-not $IntegrationServices)
{
  Throw  [System.Exception] "Failed to connect to SSIS server $SsisServer "
}
else
{
   Write-Host "Connected to SSIS server" $SsisServer
}
 
$Catalog = $IntegrationServices.Catalogs["SSISDB"]
 
# Check if the SSISDB Catalog exists
if (-not $Catalog)
{
    # Catalog doesn't exists. The user should create it manually.
    # It is possible to create it, but that shouldn't be part of
    # deployment of packages or environments.
    Throw  [System.Exception] "SSISDB catalog doesn't exist. Create it manually!"
}
else
{
    Write-Host "Catalog SSISDB found"
}

$Folder = $Catalog.Folders[$EnvironmentFolderName]
 
# Check if folder already exists
if (-not $Folder)
{
    # Folder doesn't exist
    Write-Host "Folder" $EnvironmentFolderName " not found"
}
else
{
    Write-Host "Folder" $EnvironmentFolderName "found"
}
 
$Environment = $Catalog.Folders[$EnvironmentFolderName].Environments[$EnvironmentName]

$project = $Folder.Projects[$ProjectName]

Invoke-SSISProjectValidation $project