# Setup -------------------------------------------------------------------
library(RevoScaleR)
library(MicrosoftML)

# MicrosoftM package provides state-of-the-art machine learning algorithms for R
help(package = MicrosoftML)

# Define helper functions -------------------------------------------------

# Classification model evaluation metrics
evaluateClassifier <- function (actual, predicted, data, ...) {
  varInfo <- rxGetVarInfo(data)
  if (varInfo[[actual]]$varType != "factor") {
    actual <- paste0("F(",actual,")")
  }
  if (varInfo[[predicted]]$varType != "factor") {
    actual <- paste0("F(",predicted,")")
  }
  myForm <- as.formula(paste("~",paste(actual,predicted, sep = ":")))
  confusion <- rxCrossTabs(myForm,data = data, returnXtabs = TRUE, ...)
  names(dimnames(confusion)) <- c("actual","predicted")
  print(confusion)
  print(prop.table(confusion))
  tp <- confusion[1, 1]
  fn <- confusion[1, 2]
  fp <- confusion[2, 1]
  tn <- confusion[2, 2]
  accuracy <- (tp + tn) / (tp + fn + fp + tn)
  precision <- tp / (tp + fp)
  recall <- tp / (tp + fn)
  fscore <- 2 * (precision * recall) / (precision + recall)
  metrics <- c("Accuracy" = accuracy,
               "Precision" = precision,
               "Recall" = recall,
               "F-Score" = fscore)
  return(metrics)
  
}

# Regression model evaluation metrics
evaluateRegressor <- function(observed, predicted) {
  mean_observed <- mean(observed)
  se <- (observed - predicted)^2
  ae <- abs(observed - predicted)
  sem <- (observed - mean_observed)^2
  aem <- abs(observed - mean_observed)
  mae <- mean(ae)
  rmse <- sqrt(mean(se))
  rae <- sum(ae) / sum(aem)
  rse <- sum(se) / sum(sem)
  rsq <- 1 - rse
  metrics <- c("Mean Absolute Error" = mae,
               "Root Mean Squared Error" = rmse,
               "Relative Absolute Error" = rae,
               "Relative Squared Error" = rse,
               "Coefficient of Determination" = rsq)
  return(metrics)
}

# Source data -------------------------------------------------------------

# Connection string and compute context
connectionString <- "Driver=SQL Server; Server=.; Database=IOT; UID=R_User; PWD=P@ssw0rd"
#sqlShareDirectory <- paste("c:\\RShare\\", Sys.getenv("USERNAME"), sep = "")
#dir.create(sqlShareDirectory, recursive = TRUE, showWarnings = FALSE)
#sql <- RxInSqlServer(connectionString = connectionString, shareDir = sqlShareDirectory)
#rxSetComputeContext(sql)
local <- RxLocalParallel()
rxSetComputeContext(local)

# Import train and test into data frame for faster prediction and model evaluation
trainTableName <- "train_Features"
trainTable <- RxSqlServerData(table = trainTableName, 
                              connectionString = connectionString)
trainDF <- rxImport(trainTable)

testTableName <- "test_Features"
testTable <- RxSqlServerData(table = testTableName,
                             connectionString = connectionString)
predictionDF <- rxImport(inData = testTable)

# Regression models -------------------------------------------------------

# Find top 35 variables most correlated with RUL
trainVars <- rxGetVarNames(trainDF)
trainVars <- trainVars[!trainVars  %in% c("label1", "label2", "id", "cycle_orig")]
formula <- as.formula(paste("~", paste(trainVars, collapse = "+")))
correlation <- rxCor(formula = formula, 
                     data = trainDF)
correlation <- correlation[, "RUL"]
correlation <- abs(correlation)
correlation <- correlation[order(correlation, decreasing = TRUE)]
correlation <- correlation[-1]
correlation <- correlation[1:35]
formula <- as.formula(paste(paste("RUL~"), paste(names(correlation), collapse = "+")))
formula

# Linear regression
?MicrosoftML::rxFastLinear

linearModel <- MicrosoftML::rxFastLinear(formula = formula,
                                         data = trainDF,
                                         lossFunction = squaredLoss(),
                                         type = "regression",
                                         convergenceTolerance = 0.01,
                                         #maxIterations = 50,
                                         shuffle = TRUE,
                                         normalize = "auto",
                                         l1Weight = NULL,
                                         l2Weight = NULL)

summary(linearModel)
linearModelScore <- rxPredict(modelObject = linearModel,
                              data = predictionDF,
                              extraVarsToWrite = "cycle_orig",
                              overwrite = TRUE)
head(linearModelScore)

#Neural Net

# NNet visualisation
concrete <- read.csv2("concrete.csv")
colnames(concrete) <- c("Cement","Blast","Fly","Water","Superplasticizer","Coarse","Concrete","Age","Strength")

normalize <- function(x) {
  return((x - min(x)) / (max(x) - min(x)))
}

concreteNorm <- as.data.frame(lapply(concrete, normalize))
concreteTrain <- concreteNorm[1:773, ]
concreteTest <- concreteNorm[774:1030, ]

#install.packages("neuralnet")
library(neuralnet)

names(concreteTest <- concreteNorm[774:1030, ])

modelConcrete <- neuralnet(Strength ~ Cement + Blast +
                             Fly + Water + Superplasticizer +
                             Coarse + Concrete + Age,
                           data = concreteTrain, hidden = 1)

plot(modelConcrete)

# Microsoft NNet
?MicrosoftML::rxNeuralNet

nnModel <- MicrosoftML::rxNeuralNet(formula, 
                                    data = trainDF, 
                                    type = "regression",
                                    normalize = "auto",
                                    numIterations = 50,
                                    numHiddenNodes = 40,
                                    optimizer = sgd(learningRate = 0.0001, 
                                                    momentum = 0, 
                                                    nag = FALSE, 
                                                    weightDecay = 0,
                                                    lRateRedRatio = 0.9, 
                                                    lRateRedFreq = 100, 
                                                    lRateRedErrorRatio = 0),
                                    #netDefinition = netDefinition,
                                    initWtsDiameter = 0.5,
                                    acceleration = "gpu")

summary(nnModel)
nnModelScore <- rxPredict(modelObject = nnModel,
                              data = predictionDF,
                              extraVarsToWrite = "cycle_orig",
                              overwrite = TRUE)
# Evaluation metrics for regression models -------------------------------------------------------------------
evaluateRegressor

linearModelMetrics <- evaluateRegressor (observed = linearModelScore$RLU, predicted = linearModelScore$lm.prediction)
linearModelMetrics

nnModelMetrics <- evaluateRegressor (observed = nnModelScore$cycle_orig, predicted = linearModelScore$Score)
nnModelMetrics

metricsDF <- rbind(linearModelMetrics, nnModelMetrics)
metricsDF <- as.data.frame(metricsDF)
rownames(metricsDF) <- NULL
Algorithms <- c("Linear Regression",
                "Neural Network")
metricsDF <- cbind(Algorithms, metricsDF)
metricsDF

# Classification models -------------------------------------------------------

# Find top 35 variables most correlated with label1
trainVars <- rxGetVarNames(trainDF)
trainVars <- trainVars[!trainVars  %in% c("RUL", "label2", "id", "cycle_orig")]
formula <- as.formula(paste("~", paste(trainVars, collapse = "+")))
correlation <- rxCor(formula = formula, 
                     data = trainDF,
                     transforms = list(label1 = as.numeric(label1)))
correlation <- correlation[, "label1"]
correlation <- abs(correlation)
correlation <- correlation[order(correlation, decreasing = TRUE)]
correlation <- correlation[-1]
correlation <- correlation[1:35]
formula <- as.formula(paste(paste("label1~"),
                            paste(names(correlation), collapse = "+")))
formula

# Logistic Regression - binary classification using L-BFGS
?MicrosoftML::rxLogisticRegression

logitModel <- MicrosoftML::rxLogisticRegression(formula = formula,
                                                data = trainDF,
                                                type = "binary",
                                                l1Weight = 1,
                                                l2Weight = 1,
                                                optTol = 1e-07,
                                                normalize = "auto")

summary(logitModel)

logitModelScore <- rxPredict(modelObject = logitModel,
                             data = predictionDF,
                             extraVarsToWrite = "label1",
                             overwrite = TRUE)
head(logitModelScore)

# Net
netDefinition <- ("input Data auto;
                  hidden Hidden1 auto from Data all;
                  hidden Hidden2 [20] tanh from Hidden1 all;
                  output Result auto from Hidden2 all;") 
nnModel <- MicrosoftML::rxNeuralNet(formula, 
                                    data = trainDF, 
                                    type = "binary",
                                    normalize = "auto",
                                    numIterations = 100,
                                    #numHiddenNodes = 50,
                                    optimizer = sgd(learningRate = 0.001, momentum = 0, nag = FALSE, weightDecay = 0,
                                                    lRateRedRatio = 1, lRateRedFreq = 100, lRateRedErrorRatio = 0),
                                    netDefinition = netDefinition,
                                    initWtsDiameter = 0.5,
                                    acceleration = "gpu")

summary(nnModel)
nnModelScore <- rxPredict(modelObject = nnModel,
                          data = predictionDF,
                          extraVarsToWrite = "label1",
                          overwrite = TRUE)

# Evaluation metrics for classification models -------------------------------------------------------------------

logitModelMetrics <- evaluateClassifier(actual = "label1", predicted = "PredictedLabel",
                                        data = logitModelScore)

nnModelMetrics <- evaluateClassifier(actual = "label1", predicted = "PredictedLabel",
                                        data = nnModelScore)

metricsDF <- rbind(logitModelMetrics, nnModelMetrics)
metricsDF <- as.data.frame(metricsDF)
rownames(metricsDF) <- NULL
Algorithms <- c("Logistic Regression",
                "Neural Network")
metricsDF <- cbind(Algorithms, metricsDF)
metricsDF
