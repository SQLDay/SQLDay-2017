# Setup -------------------------------------------------------------------
library(RevoScaleR)
library(MicrosoftML)
library(RColorBrewer)
library(SDMTools)
library(maps)
library(mrsdeploy)

# Sample data is available at http://packages.revolutionanalytics.com/datasets/
dataPath <- 'C:/data/MRS'
setwd('C:/data/MRS')
ccFraudCsv <- file.path(dataPath,'ccFraud.csv')
ccFraudXdf <- file.path(dataPath,'ccFraud.xdf')
censusXdf <-file.path(dataPath,'CensusUS5Pct2000.xdf')
nnModelFile <- file.path(dataPath,'nnModel100.RData')
ftModelFile <- file.path(dataPath,'ftModel.RData')
StatesCustom <- sort(c(state.name,'District of Columbia'))

# R Server options --------------------------------------------------------
# the rxOptions() function provides a set of additional parameters/defaults used by MRS
rxOptions()

# NumCoresToUse defines the number of cores that MRS functions will use by 
# default to process parallelisable functions.  Defaults to total number of
# cores in the system.
rxOptions()[["numCoresToUse"]]  

# rxSetComputeContext set the active compute context for RevoScaleR computations
rxGetComputeContext()
rxSetComputeContext(computeContext = "RxLocalParallel")
rxGetComputeContext()

# The package containing the main MRS user functionality is RevoScaleR.
? RevoScaleR

# MicrosoftM package provides state-of-the-art machine learning algorithms for R
help(package = MicrosoftML)

# Define helper functions -------------------------------------------------

# Chloro Plot
chloroPlot <- function (plot_data, states, nbins = 7, pallete ="Blues"){
  map_states <- data.frame(state = sapply(strsplit(map("state")$names, ":"), "[",1))
  map_colors <- data.frame(state = tolower(states),
                           col = brewer.pal(n = nbins, name = pallete)[cut(plot_data, breaks = nbins, labels = FALSE)],
                           stringsAsFactors = FALSE)
  map_colors <-merge (map_states,map_colors, all.x = TRUE)
  
  map("state", col = map_colors$col, fill = TRUE, resolution = 0,
      lty = 0, projection = "polyconic")
  map("state", col = "white", fill = FALSE, add = TRUE, lty =1, lwd = 1,
      projection = "polyconic")
  map("usa", col = "grey70", fill = FALSE, resolution = 0, add = TRUE,
      projection = "polyconic")
  legend.gradient(cbind(x = c(.4,.45,.45,.4),
                        y = c(.55,.8,.8,.55)),
                  cols = brewer.pal(n = nbins, name = pallete),
                  title = "", limits = range(plot_data))
}

# Classification model evaluation metrics
evaluateClassifier <- function (actual, predicted, data, ...) {
  varInfo <- rxGetVarInfo(data)
  if (varInfo[[actual]]$varType != "factor") {
    actual <- paste0("F(",actual,")")
  }
  if (varInfo[[predicted]]$varType != "factor") {
    actual <- paste0("F(",predicted,")")
  }
  myForm <- as.formula(paste("~",paste(actual,predicted, sep = ":")))
  confusion <- rxCrossTabs(myForm,data = data, returnXtabs = TRUE, ...)
  names(dimnames(confusion)) <- c("actual","predicted")
  print(confusion)
  print(prop.table(confusion))
  tp <- confusion[1, 1]
  fn <- confusion[2, 1]
  fp <- confusion[1, 2]
  tn <- confusion[2, 2]
  accuracy <- (tp + tn) / (tp + fn + fp + tn)
  precision <- tp / (tp + fp)
  recall <- tp / (tp + fn)
  fscore <- 2 * (precision * recall) / (precision + recall)
  metrics <- c("Accuracy" = accuracy,
               "Precision" = precision,
               "Recall" = recall,
               "F-Score" = fscore)
  return(metrics)
  
}

# Import data -------------------------------------------------------------

# Define variables
fraudColInfo <- list(
  V1 = list(newName = "CustID", type = "character"),
  V2 = list(newName = "gender", type = "factor", 
            levels = c("1","2"), newLevels = c("Male","Female")),
  V3 = list(newName = "state", type = "factor", 
            levels = as.character(1:51), newLevels = StatesCustom),
  V4 = list(newName = "cardHolder", type = "factor", 
            levels = c("1","2"), newLevels = c("Primary","Secondary")),
  V5 = list(newName = "balance", type = "float32"),
  V6 = list(newName = "numTrans", type = "integer"), 
  V7 = list(newName = "numIntlTrans", type = "integer"), 
  V8 = list(newName = "creditLine", type = "integer"), 
  V9 = list(newName = "fraudScore", type = "integer")
)

#Create a Data Source
ccFraudDS <- RxTextData(file = ccFraudCsv,
                        delimiter = ",",
                        firstRowIsColNames = FALSE,
                        rowsToSkip = 1,
                        colInfo = fraudColInfo)
ccFraudDS

#Bring the data into XDF file
ccFraudData <- rxImport(inData = ccFraudDS, outFile = ccFraudXdf,
                        rowsPerRead = 2000000, overwrite = TRUE)

# Best Practices for Import
# -------------------------
# Import performance will vary depending on the data types
# Character data is more "expensive" to import.
# Importing categorical data can be accelerated by providing colInfo describing
# the categorical levels in the data
# Aim for approx 10M cells per block (rows x columns)

#After a series of data import or row selection steps, you may find that you have an .xdf file with very uneven block sizes
#This may make it difficult to efficiently perform computations by �chunk�
rxGetInfo(ccFraudData, getBlockSizes = TRUE)

# Compare CSV with XDF ----------------------------------------------------

# Define ccFraudCsvData as a RxTextData object
ccFraudCsvData <- RxTextData(ccFraudCsv)
object.size(ccFraudCsvData)
object.size(ccFraudData)
# The data is not stored in memory 
# They areobjects of Rx...Data type

file.size(file.path(ccFraudCsv)) 
file.size(file.path(ccFraudXdf))
file.size(file.path(ccFraudCsv)) / file.size(file.path(ccFraudXdf))
# The XDF file is giving us approx 3x saving in space and I/O

# We can now run some basic R commands on both data sources  
# through functionality included in RevoScaleR
names(ccFraudCsvData)
dim(ccFraudData)
nrow(ccFraudData)

# Read and display some rows from the file
rxReadXdf(ccFraudXdf, numRows = 3)
head(ccFraudDS)

# We can read from different points in the file
rxReadXdf(ccFraudXdf, startRow = 9999997, numRows = 3)

# Get some information about the file and data ----------------------------
rxGetInfo(ccFraudData)

# Get some information about the columns and data in the xdf 
rxGetInfo(ccFraudData, getVarInfo = TRUE, n = 5)

# Load census data --------------------------------------------------------
file.size(file.path(censusXdf))
censusData <- RxXdfData(censusXdf)
rxGetInfo(censusData,getVarInfo = FALSE)
rxGetVarInfo(data = censusData)

# Aggregate data ---------------------------------------------------
colnames(ccFraudData)

# Get mean incwage, age, famsize by state for a specyfic year
# The result is small, so we can keep it in memory
# note the spped of xdf
aggCensus <- rxCube(cbind(incwage, age, famsize) ~ stateicp,
                    data = censusData, rowSelection = year == 2000,
                    returnDataFrame = TRUE)
head(aggCensus)

# Clean up this data for proper matching
colnames(aggCensus)[1] <- "state"
aggCensus <- subset(aggCensus, state %in% StatesCustom)
aggCensus$state <- factor(aggCensus$state, levels = StatesCustom)

# Merge data sets ---------------------------------------------------------
ccFraudData <- rxMerge(inData1 = ccFraudData, inData2 = aggCensus,
                       outFile = ccFraudData, overwrite = TRUE,
                       matchVars = "state", type = "left",
                       rowsPerOutputBlock = 2000000, autoSort = TRUE)

# Create new variables ----------------------------------------------------

# rxDataStep processes data in blocks and applies the transforms to each block
ccFraudData <- rxDataStep(inData = ccFraudData, outFile = ccFraudData,
                          overwrite = TRUE, transforms = list(
                            pctIntl = round(100 * numIntlTrans / numTrans)
                          ))

# Have a look at the data
rxGetInfo(ccFraudData, getVarInfo = TRUE, n=5)

# How to use variable information
info <- rxGetVarInfo(ccFraudData)
names(info)

# Drill down to examine the age component
names(info$age)
info$age$high

# Determine data types
sapply(rxGetVarInfo(ccFraudData), "[[","varType")

# Use transform function
# get the min and max incwage
rxGetVarInfo(ccFraudData)[["incwage"]][["low"]]
minInc <- rxGetVarInfo(ccFraudData)[["incwage"]][["low"]]
maxInc <- rxGetVarInfo(ccFraudData)[["incwage"]][["high"]]

# transformFunc to normalize
simplyNormalize <- function(lst) {
  lst[["normIncwage"]] <- as.numeric(
    (lst[["incwage"]] - minIncWage) / (maxIncWage - minIncWage)
  )
  return(lst)
}

rxDataStep(inData = ccFraudData, 
           outFile = ccFraudData,
           transformFunc = simplyNormalize,
           transformObjects = list(minIncWage = minInc ,
                                   maxIncWage = maxInc),
           append = "cols",
           overwrite = TRUE)

rxGetVarInfo(data = ccFraudData)

# Examine data ------------------------------------------------------------

# Compute descriptive statistics using rxSummary()
rxSummary( ~ fraudScore + gender + cardHolder + balance,
           data = ccFraudData)

rxSummary( ~ F(fraudScore) + balance,
           data = ccFraudData)

# MRS uses R's formula interface to enable a subset of columns to be analysed
# For all numeric and factor columns you can use 
rxSummary( ~ ., ccFraudData, reportProgress = 1)

# Interaction between a numeric variable and a factor variable
rxSummary (~F(age):fraudScore, 
           data = ccFraudData)

info <- rxSummary (~F(age):fraudScore + F(age):fraudScore:gender, 
           data = ccFraudData, 
           summaryStats = c("Mean", "StdDev"))
info

# R summary works for RxXdfData
summary(ccFraudData)

# Aggregate fraud data
aggFraud <- rxCube(cbind(balance, numTrans, numIntlTrans, creditLine) ~ state,
                   data = ccFraudData, returnDataFrame = TRUE)

rxSummary(~ balance+numTrans+numIntlTrans+creditLine, aggFraud,  reportProgress = 1)

# Plot some histograms
rxHistogram(~ F(pctIntl), data = ccFraudData,xAxisMinMax = c(-1, 101))

# We can remove outliers by restricting the x Axis min and max
rxHistogram(~ F(pctIntl), data = ccFraudData, reportProgress = 1,
            xAxisMinMax = c(10, 90), numBreaks = 100,
            yAxisMinMax = c(0, 100000), 
            xNumTicks = 10)

# Visualize data on a map
chloroPlot(plot_data = aggFraud$balance, states = aggFraud$state, pallete = "Reds")
title ("balance by state")

chloroPlot(plot_data = aggCensus$incwage, states = aggCensus$state, pallete = "BuPu")
title ("incwage by state")

# Correct pctIntl variable ----------------------------------------------------------
ccFraudData <- rxDataStep(inData = ccFraudData, outFile = ccFraudData,
                          overwrite = TRUE, transforms = list(
                            pctIntl = ifelse(is.na(pctIntl),0,pmin(pctIntl,100)),
                            pctIntl2 = round(100 * (numIntlTrans +1) / (numIntlTrans + numTrans +2))
                          ))

# Check the new variables
rxSummary(~pctIntl + pctIntl2, data = ccFraudData)

# pctIntl2 looks better
rxHistogram(~ F(pctIntl2), data = ccFraudData,
            fillColor = rgb(241,93,34, maxColorValue = 255),
            plotAreaColor = rgb(109,110,113, maxColorValue = 255),
            gridColor = "grey70")

# Relationships between variables
cube <- rxCube(formula = fraudScore ~ F(age), data = ccFraudData)
cube
cubeDF <- rxResultsDF(cube)
rxLinePlot(fraudScore ~ age, data = cubeDF)

crossTab <- rxCrossTabs(fraudScore ~ F(age):gender, data = ccFraudData,
                        returnXtabs = TRUE)
crossTab
rxKendallCor(crossTab)

# Split data into train and test datasets ---------------------------------
rxGetVarInfo(ccFraudData)

rxSplit(inData = ccFraudData, 
        varsToKeep = c("gender", "cardHolder", "balance", "numTrans","numIntlTrans","creditLine","fraudScore","age","famsize","Counts","normIncwage","pctIntl2"),
        outFilesBase = file.path(dataPath, "frauds"),
        splitByFactor = "trainValidate",
        transforms = list(
          trainValidate = factor(
            sample(0:1, size = .rxNumRows, replace = TRUE, prob = c(.9, .1)),
            levels=0:1,
            labels = c("Train", "Validate"))),
        overwrite=TRUE)

fraudsTrain <- file.path(dataPath, "frauds.TrainValidate.Train.xdf")
fraudsValid <- file.path(dataPath, "frauds.TrainValidate.Validate.xdf")
rxGetInfo(fraudsValid, getVarInfo = TRUE, n=5)


# Balance train data set ---------------------------------------------------
rxSummary( ~F(fraudScore), data = fraudsTrain)
fraudsTrainBalanced <- file.path(dataPath, "frauds.TrainValidate.Train.Balanced.xdf")
fraudsTrainBalanced <- rxDataStep(inData = fraudsTrain, outFile = fraudsTrainBalanced,
                          overwrite = TRUE, transforms = list(
                            toRemove = factor(
                              rbinom(n=.rxNumRows, size=1, prob=0.8),
                              levels=0:1,
                              labels = c("No", "Yes"))
                          ),
                          rowSelection = (fraudScore==1) | ((toRemove == "No") & (fraudScore==0))
)

rxSummary( ~F(fraudScore), data = fraudsTrainBalanced)

# Find variables strongly correlated with label --------------------------
formulaFull <- as.formula("fraudScore~balance+creditLine+numTrans+pctIntl2+gender+Counts+normIncwage+numIntlTrans+famsize+age+cardHolder")

trainVars <- rxGetVarNames(fraudsTrain)
trainVars <- trainVars[!trainVars  %in% c("toRemove")]
formula <- as.formula(paste("~", paste(trainVars, collapse = "+")))
correlation <- rxCor(formula = formula, 
                     data = fraudsTrain,
                     transforms = list(label = as.numeric(fraudScore)))
colnames(correlation)
correlation <- correlation[, "fraudScore"]
correlation <- abs(correlation)
correlation <- correlation[order(correlation, decreasing = TRUE)]
correlation <- correlation[-1]
correlation
formula <- as.formula("fraudScore~balance+creditLine+numTrans+pctIntl2+numIntlTrans+gender+Counts+normIncwage")

# Build some models -------------------------------------------------------

#Load train and test data into memory
trainDF <- rxImport(inData = fraudsTrainBalanced)
predictionDF <- rxImport(inData = fraudsValid)
dim(trainDF)
dim(predictionDF)

# Logistic Regression - binary classification using L-BFGS
logitModel <- rxLogisticRegression(formulaFull, data = trainDF)

summary(logitModel)

logitModelScore <- rxPredict(modelObject = logitModel,
                             data = predictionDF,
                             extraVarsToWrite = "fraudScore",
                             overwrite = TRUE)

names(logitModelScore) <- c("fraudScore","logit.prediction","logit.score", "logit.prob")
head(logitModelScore)
logitModelMetrics <- evaluateClassifier(actual = "fraudScore", predicted = "logit.prediction",
                                        data = logitModelScore)

#Linear binary classification
?MicrosoftML::rxFastLinear

linearModel <- MicrosoftML::rxFastLinear(formula = formula,
                                         data = trainDF,
                                         type = "binary",
                                         l1Weight = NULL,
                                         l2Weight = NULL)

summary(linearModel)
linearModelScore <- rxPredict(modelObject = linearModel,
                              data = predictionDF,
                              extraVarsToWrite = "fraudScore",
                              overwrite = TRUE)
names(linearModelScore) <- c("fraudScore","lm.prediction","lm.score", "lm.prob")
linearModelMetrics <- evaluateClassifier(actual = "fraudScore", predicted = "lm.prediction",
                                              data = linearModelScore)

# Neural network
nnModel <- MicrosoftML::rxNeuralNet(formula, data = trainDF, 
                                  type = "binary",
                                  numIterations = 3,
                                  optimizer = sgd(),
                                  numHiddenNodes = 10,
                                  acceleration = "gpu")

#for (hiddenNodes in c(5,10,50,100)) {
#  nnModel[[hiddenNodes]] <- MicrosoftML::rxNeuralNet(formula, data = trainDF, 
#                                      type = "binary",
#                                      numIterations = 30,
#                                      optimizer = sgd(),
#                                      numHiddenNodes = hiddenNodes,
#                                      acceleration = "gpu")
#  }

#nnModel <- nnModel[[100]]
#save(nnModel, file = nnModel)
load(file = nnModelFile)

nnModelScore <- rxPredict(modelObject = nnModel1,
                          data = predictionDF,
                          extraVarsToWrite = "fraudScore",
                          overwrite = TRUE)
names(nnModelScore) <- c("fraudScore","nn.prediction","nn.score", "nn.prob")

nnModelMetrics <- evaluateClassifier(actual = "fraudScore", predicted = "nn.prediction",
                                     data = nnModelScore)

# Gradient Boosting Tree
ftModel <- MicrosoftML::rxFastTrees(formula, data = fraudsTrain, 
                                    type = "binary",
                                    numTrees = 70,
                                    unbalancedSets = FALSE)

ftModelScore <- rxPredict(modelObject = ftModel,
                          data = predictionDF,
                          extraVarsToWrite = "fraudScore",
                          overwrite = TRUE)

names(ftModelScore) <- c("fraudScore","ft.prediction","ft.score", "ft.prob")

ftModelMetrics <- evaluateClassifier(actual = "fraudScore", predicted = "ft.prediction",
                                     data = ftModelScore)

# One Class Support Vector Machines
#svmModel <- MicrosoftML::rxOneClassSvm(formula, data = trainDF, 
#                                       cacheSize = 500, reportProgress = 3)

svmModelScore <- rxPredict(modelObject = svmModel,
                           data = predictionDF,
                           extraVarsToWrite = "fraudScore",
                           overwrite = TRUE)

names(svmModelScore) <- c("fraudScore","svm.prediction","svm.score", "svm.prob")

svmModelMetrics <- evaluateClassifier(actual = "fraudScore", predicted = "svm.prediction",
                                      data = score)

# Combine metrics 
metrics <- rbind(logitModelMetrics, linearModelMetrics, nnModelMetrics,ftModelMetrics)
metrics <- as.data.frame(metrics)
metrics

roc <- rxRoc(actualVarName = "fraudScore", predVarNames = "logit.prob", data = logitModelScore)
plot(roc)
roc <- rxRoc(actualVarName = "fraudScore", predVarNames = "lm.prob", data = linearModelScore)
plot(roc)
roc <- rxRoc(actualVarName = "fraudScore", predVarNames = "nn.prob", data = nnModelScore)
plot(roc)
roc <- rxRoc(actualVarName = "fraudScore", predVarNames = "ft.prob", data = ftModelScore)
plot(roc)

# Operationalization ------------------------------------------------------

# Configuring R Server for Operationalization
# cd C:\Program Files\Microsoft\R Server\R_SERVER\DeployR
# dotnet Microsoft.DeployR.Utils.AdminUtil\Microsoft.DeployR.Utils.AdminUtil.dll

#Save model
save(ftModel, file = ftModelFile)

# Wrap prediction in a function
predictFraud <- function(balance, creditLine, numTrans, numIntlTrans, gender, Counts, normIncwage, fraudScore ) {
  inputData <- data.frame(balance = as.numeric(balance), 
                          creditLine = as.integer(creditLine), 
                          numTrans = as.integer(numTrans),
                          numIntlTrans = as.integer(numIntlTrans), 
                          pctIntl2 = round(100 * (numIntlTrans +1) / (numIntlTrans + numTrans +2)),
                          gender = as.factor(gender), 
                          Counts = as.numeric(Counts),
                          normIncwage = as.numeric(normIncwage),
                          fraudScore = as.integer(fraudScore))
  out <- rxPredict(modelObject = ftModel,
            data = inputData)
  return(as.integer(out$PredictedLabel))
}

# Test function by printing results
print(predictFraud(10000, 9, 2, 3, "Female", 175367, 0.1991033, 2))

# Log into Microsoft R Server  
remoteLogin(
  "http://localhost:12800", 
  session = FALSE )

# Publish Model as a Service   
# deleteService("fraudScore","v1.0.0")


publishService(
  name = "fraudScore",
  code = predictFraud,
  model = "ftModel.RData",
  inputs = list(balance = "numeric", creditLine = "integer", 
                numTrans = "integer", numIntlTrans = "integer", 
                gender = "character", Counts = "numeric", normIncwage = "numeric",
                fraudScore = "integer"),
  outputs = list(answer = "integer"),
  v = "v1.0.0"
)

# Consume Service in R  ---------------------------------------------------

# Print capabilities that define the service holdings
api <- getService("fraudScore", "v1.0.0")

print(api)
print(api$capabilities())

# Consume service by calling function contained in this service
api$predictFraud(10000, 9L, 2L, 3L, "Female", 175367, 0.1991033, 2L)

result <- api$predictFraud(10000, 9L, 2L, 3L, "Female", 175367, 0.1991033, 2L)

# Print response output 
print(result)
