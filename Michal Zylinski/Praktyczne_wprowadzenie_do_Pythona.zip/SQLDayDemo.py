# -*- coding: UTF-8 -*-

class Hello:
    def __init__(self):
        print("Hello world!")

o = Hello()

#Rozne typy danych - obejrzyjmy sobie ich wlasciwosci
dobra_lista = [1,2,3,4,5,6]
zla_lista = [1, "a", True]

#zabawa z listami
dobra_lista[0]
dobra_lista[4]
dobra_lista[1:3]
dobra_lista[-2:]
dobra_lista.reverse()
dobra_lista

slownik = {"a":1, "b":2, "c":3}

#krotka. Tak, krotka - nie krótka
krotka = ("Michal", 25, True)
imie, wiek, mezczyzna = krotka

#ciag znakow jest podobny do listy
imie[-3:]

# Warunki i petle

if 20 < wiek < 40:
    print("Senior executive")
elif wiek <=20:
    print("Student")
else:
    print("CEO")

if wiek in range(20,40):
    print("Senior executive")

for i in range(1,10):
    if i % 2 == 0:
        print(i*2)

[i*2 for i in range(1,10) if i % 2 ==0]


# funkcje vs klasy

def kalkulacja(lista_liczb):
    return [i*2 for i in lista_liczb if i % 2 ==0]

kalkulacja(range(10))

class Kalkulator:
    def __init__(self, lista_liczb):
        self.lista = lista_liczb

    def pomnoz(self):
        return [l*2 for l in self.lista]

    def podziel(self):
        return [l/2 for l in self.lista]

k = Kalkulator([1,2,3,4,5])
k.pomnoz()
k.podziel()

#dekoratory

def moja_bulka(funkcja):
    def wrapper(name):
        print("górna część bułki")
        funkcja(name)
        print("dolna część bułki")
    return wrapper

def mieso(zawartosc): print (zawartosc)
mieso('parowka')    

@moja_bulka
def mieso(zawartosc): print(zawartosc)
mieso('kielbaska')

# baterie - własny serwer WWW
import SimpleHTTPServer
import SocketServer

PORT = 8000

Handler = SimpleHTTPServer.SimpleHTTPRequestHandler
httpd = SocketServer.TCPServer(("", PORT), Handler)
print "serving at port", PORT
httpd.serve_forever()

# baterie - microframework
from flask import Flask
app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello World!"

if __name__ == "__main__":
    app.run()

# baterie - pobieranie strony WWW
import urllib2
url = urllib2.urlopen("http://www.sqlday.pl")

#dodatkowe zasilanie:
from bs4 import BeautifulSoup
soup = BeautifulSoup(''.join(url.readlines()), 'html.parser')

#wyświetlamy wszystkie linki sponsorów:
for link in soup.find_all('a'):
    href =link.get('href') 
    if href.startswith("http") and href.find("sponsor") != -1:
        print(href)

#numpy kontra zwykłe listy
import numpy as np

np_lista = np.array(dobra_lista)
dobra_lista*2
np_lista*2

np_lista.reshape(3,2)
np_lista.reshape(3,2)[1:3,]

# losowanie i rozkłady
from numpy import random
rozklad_normalny = random.normal(size=1000)
random.choice(rozklad_normalny, size=10)

# pandas

import pandas as pd
df = pd.read_csv("test.csv")

df.info()
df.head()
df.describe()

df.sort_values(["avgopsperday"], ascending=False).head()

df.groupby(["cluster"])["ipcnt"].count()
df["cluster"].hist()

#scikit
from sklearn import cluster, datasets
iris = datasets.load_iris()
X_iris = iris.data
X_iris.shape
y_iris = iris.target
k_means_model = cluster.KMeans(n_clusters=3)
k_means_model.fit(X_iris)
k_means_model.labels_
