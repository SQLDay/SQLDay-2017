/*============================================================================
	File:		0060 - pitfalls of CDC when agent is not running.sql

	Summary:	This script demonstrates the influence of the log reader
				process to the transaction log of the CDC activated database.
				THIS SCRIPT IS PART OF THE TRACK: "CDC - Change Data Capturing"

	Date:		October 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE us_english;
SET NOCOUNT ON;

USE CustomerOrders;
GO

-- in the first step we check the recovery model of the
-- demo database and make sure it is running in SIMPEL
-- recovery modus
SELECT	[name],
		[recovery_model_desc]
FROM	sys.databases
WHERE	database_id = DB_ID();
GO[syspolicy_purge_history]

-- Now flush the transaction log
CHECKPOINT;
GO

SELECT * FROM sys.fn_dblog(NULL, NULL);
GO

SELECT * FROM sys.fn_dblog(NULL, NULL);
GO

-- NOW stop the agent job which captures the data from the
-- transaction log and run another update
EXEC msdb.dbo.sp_update_job @job_name=N'cdc.CustomerOrders_capture', @enabled=1;
GO

CHECKPOINT;
GO

SELECT * FROM sys.fn_dblog(NULL, NULL)
WHERE	Operation = N'LOP_MODIFY_ROW';
GO

-- enable the capture job to release the open transactions
EXEC msdb.dbo.sp_update_job @job_name=N'cdc.CustomerOrders_capture', @enabled=1;
GO

CHECKPOINT;
GO

SELECT * FROM sys.fn_dblog(NULL, NULL)
WHERE	Operation = N'LOP_MODIFY_ROW';
GO
