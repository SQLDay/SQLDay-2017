/*============================================================================
	File:		0080 - demonstration of DDL commands.sql

	Summary:	This script demonstrates the workload of CDC and
				the depending Log Reader functionality!
				THIS SCRIPT IS PART OF THE TRACK: "CDC - Change Data Capturing"

	Date:		February 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE = us_english;
SET NOCOUNT ON;

USE CustomerOrders;
GO

/*
	DDL commands...

    New columns that are not identified for capture will be IGNORED
    NULL will be recorded for tracked column which are dropped
    Change of data type will automatically be assigned to capture table
*/

-- new columns in a captured table
SELECT * FROM cdc.fn_cdc_get_all_changes_Employees
(
	sys.fn_cdc_get_min_lsn('Employees'),
	sys.fn_cdc_get_max_lsn(),
	'all'
);
GO

-- now we create a new column for the birthday of our employees
ALTER TABLE dbo.Employees ADD [Birthday] DATE NOT NULL DEFAULT ('19000101');
GO

-- new columns in a captured table
SELECT * FROM cdc.fn_cdc_get_all_changes_Employees
(
	sys.fn_cdc_get_min_lsn('Employees'),
	sys.fn_cdc_get_max_lsn(),
	'all'
);
GO

-- now a tracked column will be dropped!
ALTER TABLE dbo.Employees DROP COLUMN [HireDate];
GO

-- Check the DDL-changes in INVOICES
EXEC sys.sp_cdc_get_ddl_history 'Employees'
GO

-- new columns in a captured table
SELECT * FROM cdc.fn_cdc_get_all_changes_Employees
(
	sys.fn_cdc_get_min_lsn('Employees'),
	sys.fn_cdc_get_max_lsn(),
	'all'
);
GO
