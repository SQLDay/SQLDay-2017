/*============================================================================
	File:		0012 - Deadlock situations in old style version.sql

	Summary:	This script demonstrates the storage of changes to source tables
				before CDC has been implemented in SQL Server

				THIS SCRIPT IS PART OF THE TRACK: "CDC - Change Data Capturing"

	Date:		October 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

-- Transaction 1 edits the record with the ID = 2
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

BEGIN TRANSACTION
GO

	SELECT	*
	FROM	dbo.fn_GetCustomerData
			(2,'20151030', GETDATE()) AS FGCD
	ORDER BY
			Id,
			TimeStamp ASC,
			ActionId;

	SELECT	resource_type,
			CASE WHEN resource_type = N'OBJECT'
				 THEN OBJECT_NAME(resource_associated_entity_id)
				 ELSE NULL
			END						AS resource_name,
			resource_description,
			request_mode,
			request_type,
			request_status
	FROM	sys.dm_tran_locks
	WHERE	resource_database_id = DB_ID() AND
			request_session_id = @@SPID;

	-- Now run the marked transaction in a second SSMS-Window!

	SELECT * FROM dbo.CustomerData AS C WHERE Id = 2;
	GO

ROLLBACK TRANSACTION;
GO

/*
-- Take the following transaction into a second transaction and check the deadlock!
BEGIN TRANSACTION;
GO

	UPDATE	dbo.CustomerData
	SET		CustomerName = 'db Berater GmbH'
	WHERE	Id = 2;
	GO

ROLLBACK TRANSACTION;
GO
*/


-- Clean the kitchen!
DROP FUNCTION dbo.fn_GetCustomerData;
DROP TABLE history.CustomerData;
DROP TABLE dbo.CustomerData;
DROP SCHEMA [History];
GO
