/*============================================================================
	File:		0090 - recordsources for compliance report.sql

	Summary:	This script demonstrates the workload of CDC and
				the depending Log Reader functionality!
				THIS SCRIPT IS PART OF THE TRACK: "CDC - Change Data Capturing"

	Date:		February 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

IF OBJECT_ID('cdc.if_CustomerNames_List', 'IF') IS NOT NULL
	DROP FUNCTION cdc.if_CustomerNames_List;
	GO

CREATE FUNCTION cdc.if_CustomerNames_List ()
RETURNS TABLE
AS
RETURN
(
	WITH AvailableChanges
	AS
	(
		SELECT	CT.Id
		FROM	cdc.lsn_time_mapping AS LSN INNER JOIN cdc.Customer_CT AS CT
				ON (LSN.start_lsn = CT.__$start_lsn)
		WHERE	LSN.tran_begin_time >= CAST(DATEADD(DAY, -90, GETDATE()) AS DATE)
	)
	SELECT	C.Id,
			C.CustomerName
	FROM	dbo.Customer AS C
	WHERE	C.Id IN (SELECT Id FROM AvailableChanges)
);
GO

IF OBJECT_ID('cdc.proc_ChangeReport', 'P') IS NOT NULL
	DROP PROCEDURE cdc.proc_ChangeReport;
	GO

CREATE PROCEDURE cdc.proc_ChangeReport
	@Customer_Id	int,
	@StartTime		datetime
AS
	SET NOCOUNT ON

	-- Select the changes for the dedicated record
	SELECT	sys.fn_cdc_map_lsn_to_time(__$start_lsn)	as 'lsn datetime',
			CASE __$operation
				WHEN 2 THEN 'insert'
				WHEN 3 THEN 'pre update'
				WHEN 4 THEN 'post update'
			end											AS 'operation',
			Id,
			CustomerName,
			CustomerStreet,
			CustomerCCode,
			CustomerZIP,
			CustomerCity,
			sys.fn_cdc_is_bit_set
			(
				sys.fn_cdc_get_column_ordinal('Customer','CustomerName'),
				__$update_mask
			)	AS	[CustomerName_Update],
			sys.fn_cdc_is_bit_set
			(
				sys.fn_cdc_get_column_ordinal('Customer','CustomerStreet'),
				__$update_mask
			)	AS	[CustomerStreet_Update],
			sys.fn_cdc_is_bit_set
			(
				sys.fn_cdc_get_column_ordinal('Customer','CustomerCCode'),
				__$update_mask
			)	AS	[CustomerCCode_Update],
			sys.fn_cdc_is_bit_set
			(
				sys.fn_cdc_get_column_ordinal('Customer','CustomerZIP'),
				__$update_mask
			)	AS	[CustomerZIP_Update],
			sys.fn_cdc_is_bit_set
			(
				sys.fn_cdc_get_column_ordinal('Customer','CustomerCity'),
				__$update_mask
			)	AS	[CustomerCity_Update]
	FROM	cdc.fn_cdc_get_all_changes_Customer
			(
				sys.fn_cdc_get_min_lsn('Customer'), 
				sys.fn_cdc_get_max_lsn(),
				N'all'
			)
	WHERE	Id = @Customer_Id AND
			sys.fn_cdc_map_lsn_to_time(__$start_lsn) >= @StartTime AND
			sys.fn_cdc_map_lsn_to_time(__$start_lsn) <= CAST(DATEADD(DAY, 1, @StartTime) AS DATE);

	SET NOCOUNT OFF;
GO

-- Demo-Time :)
EXEC	cdc.proc_ChangeReport
		@Customer_Id = 0,
		@StartTime = '20151030';