/*============================================================================
	File:		0020 - enabling CDC for demo_db.sql

	Summary:	This script activates the CDC functionality for the
				demo database!
				THIS SCRIPT IS PART OF THE TRACK: "CDC - Change Data Capturing"

	Date:		February 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

USE demo_db;
GO

RAISERROR ('Creation of additional filegroup for the storage of CDC data from tables', 0, 1) WITH NOWAIT;
IF NOT EXISTS (SELECT * FROM sys.filegroups AS F WHERE F.name = 'CDC')
BEGIN
	ALTER DATABASE demo_db ADD FILEGROUP CDC;

	ALTER DATABASE demo_db ADD FILE
	(
		NAME = 'CDC_DATA',
		FILENAME = 'F:\MSSQL13.SQL_2016\MSSQL\DATA\cdc_data.ndf',
		SIZE = 100MB,
		MAXSIZE = 1000MB,
		FILEGROWTH = 100MB
	)
	TO FILEGROUP CDC;
END
GO

-- for security reasons a database role for dedicated
-- access to the temporal data need to be implemented!
RAISERROR ('Creation of database role [CDC_Admin] for administrative access to CDC data', 0, 1) WITH NOWAIT;
IF NOT EXISTS (SELECT * FROM sys.database_principals AS DP WHERE name = 'CDC_Admin' AND type = 'R')
	CREATE ROLE [CDC_Admin] AUTHORIZATION [dbo];
GO

RAISERROR ('Activating database for CDC', 0, 1) WITH NOWAIT;
IF NOT EXISTS
(
	SELECT	*
	FROM	sys.databases
	WHERE	database_id = DB_ID()
			AND is_cdc_enabled = 1
)
BEGIN
	BEGIN TRANSACTION EnableDB;
		DECLARE	@ReturnValue	INT;
		EXEC	@ReturnValue = sys.sp_cdc_enable_db;
	COMMIT TRANSACTION EnableDB;
END
GO

-- Check the status of the database
SELECT	[name],
		[state_desc],
		[is_cdc_enabled]
FROM	sys.databases
WHERE	database_id = DB_ID()
GO

-- See all relevant objects (user, schema, database objects) for CDC
-- what is the relevant CDC account for 
-- internal management of CDC?
SELECT	principal_id,
		name,
		type_desc,
		default_schema_name,
		authentication_type
FROM	sys.database_principals
WHERE	name = 'CDC';
GO

-- what schemas have been created when CDC has been activated?
SELECT	S.[schema_id],
		S.[name]			AS	[Schema_name],
		DP.[name]			AS	[Schema_owner]
FROM	sys.schemas AS S INNER JOIN sys.database_principals AS DP
		ON (S.principal_id = DP.principal_id)
WHERE	S.name = 'CDC'
GO

-- What objects do we have in the CDC schema:
SELECT	DISTINCT
		O.[name],
		O.[type_desc],
		O.[is_ms_shipped]
FROM	sys.objects AS O INNER JOIN sys.schemas AS S
		ON	(O.schema_id = S.schema_id)
WHERE	S.name = 'CDC' AND
		O.parent_object_id = 0;
GO
