/*============================================================================
	File:		0030 - enabling tables in demo_db for CDC.sql

	Summary:	This script activates the CDC functionality for the
				demo tables!
				THIS SCRIPT IS PART OF THE TRACK: "CDC - Change Data Capturing"

	Date:		February 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE us_english;
SET NOCOUNT ON;

USE demo_db;
GO

-- activation of table [dbo].[Customer] for CDC!
EXEC	sys.sp_cdc_enable_table
		@source_schema			= 'dbo',
		@source_name			= 'CustomerData',
		@role_name				= 'CDC_Admin',
		@capture_instance		= 'CustomerData',
		@supports_net_changes	= 1,
		@index_name				= 'pk_CustomerData',
		@captured_column_list	= NULL,
		@filegroup_name			= 'CDC',
		@allow_partition_switch	= 1;
GO

---- activation of table [dbo].[Invoices] for CDC!
--IF NOT EXISTS (SELECT * FROM sys.tables WHERE object_id = OBJECT_ID('dbo.Invoices', 'U') AND is_tracked_by_cdc = 1)
--EXEC sys.sp_cdc_enable_table
--	@source_schema				= 'dbo',
--	@source_name				= 'Invoices',
--	@role_name					= 'CDC_Admin',
--	@capture_instance			= 'Invoices',
--	@supports_net_changes		= 0,
--	@Index_name					= NULL,
--	@captured_column_list		= NULL,
--	@filegroup_name				= 'CDC',
--	@allow_partition_switch		= 1;
--GO

-- what tables have been enabled for CDC?
SELECT	S.[name]		AS	'schema_name',
		T.[name],
		T.[type],
		T.[type_desc],
		T.[is_tracked_by_cdc]
FROM	sys.schemas AS S INNER JOIN sys.tables AS T
		ON (S.[schema_id] = T.[schema_id])
WHERE	T.[is_tracked_by_cdc] = 1;
GO

-- configuration of jobs
EXEC sys.sp_cdc_help_jobs;
GO

-- set the retention time to 90 days
EXEC sys.sp_cdc_change_job
	@job_type = 'cleanup',
    @retention = 129600;		-- Minutes
GO

-- check the configuration of the tables for CDC
EXEC sys.sp_cdc_help_change_data_capture;
GO

-- What objects do we have in the CDC schema:
SELECT	O.name,
		O.type_desc,
		O.is_ms_shipped
FROM	sys.objects AS O INNER JOIN sys.schemas AS S
		ON	(O.schema_id = S.schema_id)
WHERE	S.name = 'CDC' AND
		O.parent_object_id = 0;
GO

-- disable CDC for demo database because another process is updating
-- the database CustomerOrders!
EXEC sys.sp_cdc_disable_db;
GO
