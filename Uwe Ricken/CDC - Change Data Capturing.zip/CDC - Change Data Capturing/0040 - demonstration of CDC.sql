/*============================================================================
	File:		0040 - demonstration of CDC.sql

	Summary:	This script demonstrates the workload of CDC and
				the depending Log Reader functionality!
				THIS SCRIPT IS PART OF THE TRACK: "CDC - Change Data Capturing"

	Date:		September 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

-- MAKE SURE THAT SCRIPT 0011 - background update process for dbo.employees.sql
-- did run for a while!!!!

-- what information has been stored in the CDC table now?
SELECT * FROM cdc.Employees_CT;
GO

-- at what time did the changes happen?
select	MAX(__$start_lsn)								as 'max lsn',
		sys.fn_cdc_map_lsn_to_time(MAX(__$start_lsn))	as 'max datetime'
from	cdc.Employees_CT;
GO

SELECT	sys.fn_cdc_map_lsn_to_time(__$start_lsn) AS 'datetime',
		*
FROM	cdc.Employees_CT
WHERE	Id = 51;
GO

-- how to gain corresponding LSN based on dates?
-- you can use sys.fn_cdc_map_time_to_lsn for retrieval of dates
DECLARE	@starttime	DATETIME	=	DATEADD(MINUTE, -60, GETDATE()),
		@endtime	DATETIME	=	GETDATE();

SELECT	sys.fn_cdc_map_time_to_lsn('smallest greater than', @starttime) AS 'smallest greater than',
		sys.fn_cdc_map_time_to_lsn('largest less than or equal', @endtime) AS 'largest less than or equal';

-- now get the changed data based on the given LSN
SELECT * FROM cdc.Employees_CT
WHERE	[__$start_lsn] >= sys.fn_cdc_map_time_to_lsn('smallest greater than', @starttime) AND
		[__$start_lsn] <= sys.fn_cdc_map_time_to_lsn('largest less than or equal', @endtime);
GO

-- how to evaluate changes in the CDC tables
-- based on min_lsn and max_lsn
SELECT	__$start_lsn,
		__$update_mask,
		CAST (__$update_mask AS INT)	AS	DecimalValue,
		Id,
		FirstName,
		LastName,
		EMailAddress,
		HireDate,
		Active,
		InsertUser,
		InsertDate
FROM	cdc.Employees_CT
WHERE	__$start_lsn BETWEEN
		sys.fn_cdc_get_min_lsn('Employees') AND
		sys.fn_cdc_get_max_lsn()
ORDER BY
		ID,
		sys.fn_cdc_map_lsn_to_time(__$start_lsn);
GO

-- return only the update results but not the old values
SELECT	*
FROM	cdc.fn_cdc_get_all_changes_Employees
		(
			sys.fn_cdc_get_min_lsn('Employees'),
			sys.fn_cdc_get_max_lsn(),
			N'all'
		);
GO

-- return only the update results including the old values
SELECT	*
FROM	cdc.fn_cdc_get_all_changes_Employees
		(
			sys.fn_cdc_get_min_lsn('Employees'),
			sys.fn_cdc_get_max_lsn(),
			N'all update old'
		);
GO