/*============================================================================
	File:		0050 - demonstration of CDC functions.sql

	Summary:	This script demonstrates the workload of CDC and
				the depending Log Reader functionality!
				THIS SCRIPT IS PART OF THE TRACK: "CDC - Change Data Capturing"

	Date:		February 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE us_english;
SET NOCOUNT ON;

USE CustomerOrders;
GO

-- what was the time when the changes occured?
/*
	Update Mask:	0x01FF	= 511
	256	128	64	32	16	8	4	2	1
	1	1	1	1	1	1	1	1	1
*/
SELECT	sys.fn_cdc_map_lsn_to_time(__$start_lsn)	as 'lsn datetime',
		CASE __$operation
			WHEN 2 THEN 'insert'
			WHEN 3 THEN 'pre update'
			WHEN 4 THEN 'post update'
		end											AS 'operation',
		__$update_mask,
		CAST(__$update_mask AS INT)					AS	update_mask_decimal,
		Id,
		FirstName,
		LastName,
		EMailAddress,
		HireDate,
		Active,
		InsertUser,
		InsertDate,
		sys.fn_cdc_get_column_ordinal('Employees','FirstName')		AS	Employees_FirstName_ColOffset,
		sys.fn_cdc_get_column_ordinal('Employees','LastName')		AS	Employees_LastName_ColOffset,
		sys.fn_cdc_get_column_ordinal('Employees','EMailAddress')	AS	Employees_EMailAddress_ColOffset,
		sys.fn_cdc_get_column_ordinal('Employees','HireDate')		AS	Employees_HireDate_ColOffset,
		sys.fn_cdc_get_column_ordinal('Employees','Active')			AS	Employees_Active_ColOffset,
		sys.fn_cdc_get_column_ordinal('Employees','InsertUser')		AS	Employees_InsertUser_ColOffset,
		sys.fn_cdc_get_column_ordinal('Employees','InsertDate')		AS	Employees_InsertDate_ColOffset
FROM	cdc.fn_cdc_get_all_changes_Employees
		(
			sys.fn_cdc_get_min_lsn('Employees'), 
			sys.fn_cdc_get_max_lsn(),
			N'all'
		);
GO

-- now check whether the columns have been updated
SELECT	sys.fn_cdc_map_lsn_to_time(__$start_lsn)	as 'lsn datetime',
		CASE __$operation
			WHEN 2 THEN 'insert'
			WHEN 3 THEN 'pre update'
			WHEN 4 THEN 'post update'
		end											AS 'operation',
		__$update_mask,
		CAST(__$update_mask AS INT)					AS	update_mask_decimal,
		Id,
		FirstName,
		LastName,
		EMailAddress,
		HireDate,
		Active,
		InsertUser,
		InsertDate,
		sys.fn_cdc_is_bit_set
		(
			sys.fn_cdc_get_column_ordinal('Employees','FirstName'),
			__$update_mask
		)	AS	[Val = 2],
		sys.fn_cdc_is_bit_set
		(
			sys.fn_cdc_get_column_ordinal('Employees','LastName'),
			__$update_mask
		)	AS	[Val = 4],
		sys.fn_cdc_is_bit_set
		(
			sys.fn_cdc_get_column_ordinal('Employees','EMailAddress'),
			__$update_mask
		)	AS	[Val = 8],
		sys.fn_cdc_is_bit_set
		(
			sys.fn_cdc_get_column_ordinal('Employees','HireDate'),
			__$update_mask
		)	AS	[Val = 16],
		sys.fn_cdc_is_bit_set
		(
			sys.fn_cdc_get_column_ordinal('Employees','Active'),
			__$update_mask
		)	AS	[Val = 32],
		sys.fn_cdc_is_bit_set
		(
			sys.fn_cdc_get_column_ordinal('Employees','InsertUser'),
			__$update_mask
		)	AS	[Val = 64],
		sys.fn_cdc_is_bit_set
		(
			sys.fn_cdc_get_column_ordinal('Employees','InsertDate'),
			__$update_mask
		)	AS	[Val = 128]
FROM	cdc.fn_cdc_get_all_changes_Employees
		(
			sys.fn_cdc_get_min_lsn('Employees'), 
			sys.fn_cdc_get_max_lsn(),
			N'all'
		);
GO
