/*============================================================================
	File:		0011 - Old Style temporal data.sql

	Summary:	This script demonstrates the storage of changes to source tables
				before CDC has been implemented in SQL Server

				THIS SCRIPT IS PART OF THE TRACK: "CDC - Change Data Capturing"

	Date:		October 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

IF DB_ID(N'demo_db') IS NOT NULL
BEGIN
	ALTER DATABASE demo_db SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE demo_db;
END
GO

CREATE DATABASE demo_db;
GO

USE demo_db;
GO

-- Now a customer table will be created
IF OBJECT_ID('dbo.CustomerData', 'U') IS NOT NULL
	DROP TABLE dbo.CustomerData;
	GO

CREATE TABLE dbo.CustomerData
(
	Id				INT				NOT NULL	IDENTITY (1, 1),
	CustomerName	VARCHAR(200)	NOT NULL,
	Street			VARCHAR(200)	NOT NULL,
	ZIP				VARCHAR(200)	NOT NULL,
	City			VARCHAR(200)	NOT NULL,
	[TimeStamp]		DATETIME		NOT NULL	DEFAULT (GETDATE()),

	CONSTRAINT pk_CustomerData PRIMARY KEY CLUSTERED (Id)
);
GO

-- Create a dedicated schema for the storage of temporal data
-- No standard user is allowed to access this schema!
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'History')
	EXEC sp_executesql N'CREATE SCHEMA [History] AUTHORIZATION dbo;';
	GO

-- A table for the storage of changed data will be created in the [HISTORY]-schema
IF OBJECT_ID('History.CustomerData', 'U') IS NOT NULL
	DROP TABLE History.CustomerData;
	GO

CREATE TABLE [History].CustomerData
(
	Id				INT				NOT NULL,
	CustomerName	VARCHAR(200)	NOT NULL,
	Street			VARCHAR(200)	NOT NULL,
	ZIP				VARCHAR(200)	NOT NULL,
	City			VARCHAR(200)	NOT NULL,
	ActionId		TINYINT			NOT NULL	DEFAULT (2) CHECK (ActionId IN (1, 2, 3, 4)),
	InsertUser		sysname			NOT NULL	DEFAULT (ORIGINAL_LOGIN()),
	[TimeStamp]		DATETIME		NOT NULL	DEFAULT (GETDATE()),

	CONSTRAINT pk_History_CustomerData PRIMARY KEY CLUSTERED
	(
		Id,
		[TimeStamp],
		ActionId
	)
);
GO



-- When the "infrastructure" has been created the technology behind can be implemented
CREATE TRIGGER dbo.trg_CustomerData_Insert
ON dbo.CustomerData
FOR INSERT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE	@ActionId	TINYINT = 2;

	INSERT INTO History.CustomerData
	(Id, CustomerName, Street, ZIP, City, ActionId)
	SELECT	Id, CustomerName, Street, ZIP, City, @ActionId
	FROM	inserted;

	SET NOCOUNT OFF;
END
GO

CREATE TRIGGER dbo.trg_CustomerData_Update
ON dbo.CustomerData
FOR UPDATE
AS
BEGIN
	SET NOCOUNT ON;

	-- Now we insert the data from the deleted table (trigger only)
	-- into the history table
	UPDATE	c
	SET		c.[TimeStamp] = GETDATE()
	FROM	dbo.CustomerData AS C INNER JOIN inserted AS I
			ON (C.Id = I.Id);

	INSERT INTO History.CustomerData
	(Id, CustomerName, Street, ZIP, City, ActionId)
	SELECT	Id, CustomerName, Street, ZIP, City, 3
	FROM	deleted
	
	UNION ALL
	
	SELECT	Id, CustomerName, Street, ZIP, City, 4
	FROM	inserted;

	SET NOCOUNT OFF;
END
GO

CREATE TRIGGER dbo.trg_CustomerData_Delete
ON dbo.CustomerData
FOR DELETE
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE	@ActionId	TINYINT = 1;

	-- Now we insert the data from the deleted table (trigger only)
	-- into the history table
	INSERT INTO History.CustomerData
	(Id, CustomerName, Street, ZIP, City, ActionId)
	SELECT Id, CustomerName, Street, ZIP, City, @ActionId
	FROM	deleted;

	SET NOCOUNT OFF;
END
GO

-- for the temporal check we create a function which retrieves
-- the status for the record at a specific time
IF OBJECT_ID('dbo.fn_GetCustomerData', 'IF') IS NOT NULL
	DROP FUNCTION dbo.fn_GetCustomerData
	GO

CREATE FUNCTION dbo.fn_GetCustomerData
(
	@Id INT,
	@StartDate DATETIME,
	@EndDate DATETIME
)
RETURNS TABLE
AS
RETURN
(
	SELECT	Id, CustomerName, Street, ZIP, City, [TimeStamp], ActionId,
			CASE ActionId
				WHEN 1 THEN 'DELETE Statement'
				WHEN 2 THEN 'INSERT Statement'
				WHEN 3 THEN 'Before UPDATE Statement'
				ELSE 'After UPDATE Statement'
			END AS Action
	FROM	History.CustomerData
	WHERE	Id = @Id AND
			[TimeStamp] BETWEEN @StartDate AND @EndDate
);
GO

-- Now we insert 2 Records in the dbo.CustomerData-table
INSERT INTO dbo.CustomerData
(CustomerName, Street, ZIP, City)
VALUES
('Customer A', 'Mountain View 10', '12345', 'Somewhere'),
('Customer B', 'Another Way 11', '2345', 'Anywhere');
GO

SELECT * FROM dbo.fn_GetCustomerData
(1, '20160921', GETDATE()) AS FGCD
ORDER BY
	Id,
	[TimeStamp] ASC,
	ActionId
GO

-- Now we change the data from record 1
UPDATE	dbo.CustomerData
SET		CustomerName = 'Microsoft Corporation'
WHERE	Id = 1;
GO

UPDATE	dbo.CustomerData
SET		Street = '1 Microsoft Way'
WHERE	Id = 1;
GO

SELECT * FROM dbo.fn_GetCustomerData
(1, '20151030', GETDATE()) AS FGCD
ORDER BY
	Id,
	[TimeStamp] ASC,
	ActionId
GO

-- Now we delete a record
DELETE	dbo.CustomerData WHERE Id = 1;
GO

SELECT * FROM dbo.fn_GetCustomerData
(1, '20151030', GETDATE()) AS FGCD
ORDER BY
	Id,
	[TimeStamp] ASC,
	ActionId
GO
