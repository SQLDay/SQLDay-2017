/*============================================================================
	File:		0011 - background update process for dbo.employees.sql

	Summary:	This script uses the existing database CustomerOrders and
				implements CDC for the table dbo.Employees.
				It will update one record every 10 seconds

	Date:		May 2017

	SQL Server Version: 2012 / 2014 / 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

-- 1. Enable CDC in the database CustomerOrders
IF EXISTS
(
	SELECT	*
	FROM	sys.databases
	WHERE	name = N'CustomerOrders'
			AND [is_cdc_enabled] = 0
)
BEGIN
	RAISERROR ('Enabling CDC for database %s', 0, 1, 'CustomerOrders');
	EXEC sys.sp_cdc_enable_db;
END
GO

-- 2. Create a dedicated filegroup for the CDC data
IF NOT EXISTS
(
	SELECT * FROM sys.filegroups AS F
	WHERE	name = 'CDC'
)
BEGIN
	RAISERROR ('Creating a dedicated filegroup CDC for storing historical data', 0, 1) WITH NOWAIT;
	ALTER DATABASE CustomerOrders ADD FILEGROUP [CDC];

	-- 3. Add a new file to the filegroup CDC
	ALTER DATABASE CustomerOrders
	ADD FILE
	(
		NAME = N'CDC_DATA',
		FILENAME = N'F:\MSSQL13.SQL_2016\MSSQL\DATA\CustomerOrders.ndf',
		SIZE = 1024MB,
		FILEGROWTH = 1024MB
	) TO FILEGROUP [CDC];
END
GO

-- 3. Create a clustered primary key on dbo.Employees
IF NOT EXISTS
(
	SELECT	* FROM sys.objects
	WHERE	parent_object_id = OBJECT_ID(N'dbo.Employees', N'U')
			AND type_desc = 'PRIMARY_KEY_CONSTRAINT'
)
BEGIN
	RAISERROR (N'Creating a PRIMARY KEY constraint on dbo.Employees...', 0, 1) WITH NOWAIT;
	ALTER TABLE dbo.Employees
	ADD CONSTRAINT pk_Employees_Id PRIMARY KEY CLUSTERED (Id);
END
GO

-- 4. Enable CDC for table dbo.Employees
IF NOT EXISTS
(
	SELECT	*
	FROM	sys.tables
	WHERE	object_id = OBJECT_ID(N'dbo.Employees')
			AND [is_tracked_by_cdc] = 1
)
BEGIN
	RAISERROR (N'Enabling CDC for table %s', 0, 1, N'dbo.Employees');

	EXEC	sys.sp_cdc_enable_table
			@source_schema			= 'dbo',
			@source_name			= 'Employees',
			@role_name				= 'CDC_Admin',
			@capture_instance		= 'Employees',
			@supports_net_changes	= 1,
			@index_name				= 'pk_Employees_Id',
			@captured_column_list	= NULL,
			@filegroup_name			= 'CDC',
			@allow_partition_switch	= 1;
END
GO

-- Now we can start the changing process of the data
SET NOCOUNT ON;
GO

DECLARE @commandlist TABLE
(
	Id		INT				NOT NULL PRIMARY KEY,
	Command	NVARCHAR(1000)	NOT NULL
);


INSERT INTO @CommandList
VALUES
(1, N'UPDATE dbo.Employees SET FirstName = newid() WHERE Id = @ID;'),
(2, N'UPDATE dbo.Employees SET LastName = newid() WHERE Id = @ID;'),
(3, N'UPDATE dbo.Employees SET HireDate = DATEADD(DAY, CAST(RAND() * 365 AS INT) * -1, GETDATE()) WHERE ID = @Id;'),
(4, N'UPDATE dbo.Employees SET EMailAddress = ''funnyaddress@gmail.com'' WHERE Id = @Id;'),
(5, N'UPDATE dbo.Employees SET InsertUser = ''Buggs Bunny'' WHERE Id = @ID;'),
(6, N'UPDATE dbo.Employees SET Active = CASE WHEN ACTIVE = 0 THEN 1 ELSE 0 END WHERE Id = @ID;'),
(7, N'DELETE dbo.Employees WHERE Id = @Id;');
 
-- Now we update the records in a random way
DECLARE @stmt	NVARCHAR(1000);
DECLARE @Command_Id INT = CAST(RAND() * 7 AS INT) + 1;
DECLARE	@Employee_Id INT = CAST(RAND() * 150 AS INT) + 1;
WHILE (1 = 1)
BEGIN
	SELECT	@stmt = C.Command
	FROM	@commandlist AS C
	WHERE	C.Id = @Command_Id;

	RAISERROR (N'Update/Delete of record [%i]...', 1, 0, @Employee_Id) WITH NOWAIT;
	EXEC sp_executesql @stmt, N'@Id INT', @Employee_Id;
	WAITFOR DELAY '00:00:05';

	SET	@Command_Id		= CAST(RAND() * 7 AS INT) + 1;
	SET	@Employee_Id	= CAST(RAND() * 150 AS INT) + 1;
END
GO